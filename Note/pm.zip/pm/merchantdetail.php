<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.investor.value.length == 0)
		{
			alert('Please input Investor Name');
			document.form_1.investor.focus();
			return false;
		}
		if(document.form_1.interest.value.length == 0 || document.form_1.interest.value == "0")
		{
			alert('Please input Interest Rate of Investor');
			document.form_1.{.focus();
			return false;
		}
		if(!IsNumeric(document.form_1.interest.value))
		{
			alert('Please input Interest Rate of Investor with numeric');
			document.form_1.interest.focus();
			return false;
		}
		if(document.form_1.email.value.length == 0)
		{
			alert('Please input Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
		if(!isValidEmail(document.form_1.email.value))
		{
			alert('Please input valid Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Overview Detail Merchant
			</div>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
			<?php
				if(isset($_GET['idMerchant']))
				{
					$idMerchant = $_GET['idMerchant'];
					
					$queryDD = "select a.mid,a.merchant,a.merchantAddr,a.merchantCity,a.kodepos,a.segment,a.cp,a.mobilePhone,a.phone,a.merchantDesc,a.regionMTI
								from merchant a
								where a.idMerchant = ".$idMerchant;
					$resultDD = mysql_query($queryDD);
					//echo $queryDD."<br>";
					$rowDD = mysql_fetch_array($resultDD);
				?>
					<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
						Merchant Info
					</div>
					<div class="col100 marginTop20 marginBottom2">
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Merchant ID</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['mid'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Merchant Name</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['merchant'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Address</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['merchantAddr'] ?>
							</div>
						</div>
						<div class="margine"></div>
						
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">City</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['merchantCity'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Kodepos</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['kodepos'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Segment</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['segment'] ?>
							</div>
						</div>
						<div class="margine"></div>
						
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Mobilephone</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['mobilePhone'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Telephone</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['phone'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Contact Person</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['cp'] ?>
							</div>
						</div>
						<div class="margine"></div>
						
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Description</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['merchantDesc'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Region</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['regionMTI'] ?>
							</div>
						</div>
						<div class="margine"></div>
					</div>
				<?php
				}
			?>
			
			</div>
			
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date3').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date4').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date5').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date6').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>