<?php
	session_start();
	if(!isset($_SESSION['userID']))
	{
		header("Location:login.php");
	}
	
		include('connect_db.php');
		$date1 = $_GET['date1'];
		$date2 = $_GET['date2'];
		$idStatus = $_GET['idStatus'];
		$vendor = $_GET['vendor'];
		
		
	
				$file_name = "Report_Log_Mapping_".$date1."_".$date2;
				
				header("Content-type: application/octet-stream");
				header('Content-Type: plain/text'); 
				header("Content-Disposition: attachment; filename=".$file_name.".xls");
				header("Pragma: no-cache");
				header("Expires: 0");
	
		
?>
						Print date : <?php echo date("d/m/Y") ?><br>
						<table border="1">
							<tr>
								<th colspan="10"><h2>Data Log Mapping</h2></th>
							</tr>
							
						<?php
							$queryD = "SELECT a.idMapping,a.uploadDT,a.uploadBy,a.idStatus,a.statusAsset,a.type,a.vendor,a.provider,a.updateDT,a.updateBy,b.username
									   FROM asset_mapping a
									   INNER JOIN asset_login b ON a.updateBy = b.userID";
										
							
							if(!empty($date1) && $date1 <> "" && !empty($date2) && $date2 <> "")
							{
								$queryD = $queryD." where a.updateDT between '".$date1."' and '".$date2."'";
							}
							
							if(!empty($idStatus) && $idStatus <> "0")
							{
								$queryD = $queryD." and a.idStatus = '".$idStatus."'";
							}
							if(!empty($vendor) && $vendor <> "0")
							{
								$queryD = $queryD." and a.vendor = '".$vendor."'";
							}
							
							
							$queryD = $queryD." order by a.idMapping desc";
							$resultD = mysql_query($queryD);
							$numrowD = mysql_num_rows($resultD);
							$mysql_query = ($queryD) or die(mysql_error());
							//echo $queryD."<br>";
							
							
							
							
						?>
							<tr>
								<th>ID Mapping</th>
								<th>Upload DT</th>
								<th>Upload By</th>
								<th>Id Status</th>
								<th>Status Asset</th>
								<th>Type</th>
								<th>Vendor</th>
								<th>Provider</th>
								<th>Update DT</th>
								<th>Update By</th>
							</tr>
							<?php
								while($rowLC = mysql_fetch_array($resultD))
								{
									$idLog = $rowLC['idLog'];
								?>
								
								<tr>
										
										<td><?php echo "'".$rowLC['idMapping'] ?></td>
										<td><?php echo "'".$rowLC['uploadDT'] ?></td>
										<td><?php echo "'".$rowLC['uploadBy'] ?></td>
										<td><?php echo "'".$rowLC['idStatus'] ?></td>
										<td><?php echo $rowLC['statusAsset'] ?></td>
										<td><?php echo $rowLC['type'] ?></td>
										<td><?php echo $rowLC['vendor'] ?></td>
										<td><?php echo $rowLC['provider'] ?></td>
										<td><?php echo $rowLC['updateDT'] ?></td>	
										<td><?php echo $rowLC['updateBy'] ?></td>
										
										
									</tr>
							<?php
								}
							?>
						</table>
    

    
								
								