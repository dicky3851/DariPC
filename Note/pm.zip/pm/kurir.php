<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.kurir.value.length == 0)
		{
			alert('Please input Courier Name');
			document.form_1.kurir.focus();
			return false;
		}
		if(document.form_1.namedetail.value.length == 0)
		{
			alert('Please input Complete Courier Name');
			document.form_1.namedetail.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Bucket List Management
			</div>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
			
				<div class="col35 floatLeft marginRight20">
					
					<?php
						if(isset($_POST['cmdSubmit']))
						{
							$kurir = $_POST['kurir'];
							$namedetail = $_POST['namedetail'];
							
							$kurir = strtoupper(str_replace("'","",$kurir));
							$namedetail = strtoupper(str_replace("'","",$namedetail));
						?>
							<div class="col100 borderGray padding10 marginBottom20">
								<div class="col95 marginAuto">
									<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
										Result Process
									</div>
								
								<?php
									//Cek Duplicate
									$queryC = "select idKurir from thermal_kurir where upper(kurir) = '".$kurir."'";
									$resultC = mysql_query($queryC);
									$numrowC = mysql_num_rows($resultC);
									
									if($numrowC == 0)
									{
										//Insert here
										$queryI = "insert into thermal_kurir
													(kurir,namedetail)
													select '".$kurir."','".$namedetail."'";
										$resultI = mysql_query($queryI);
										//echo $queryI."<br>";
										if($resultI)
										{
										?>
											<div class="col100 textBold marginBottom10">
												Register Courier successfully completed
											</div>
										<?php
										}
										else
										{
										?>
											<div class="col100 textBold colorRed marginBottom10">
												Register Courier failed completed
											</div>
										<?php
										}
									}
									else
									{
									?>
										<div class="col100 textBold colorRed marginBottom10">
											Duplicate Courier Data. Please check table list
										</div>
									<?php	
									}
								?>
								</div>
							</div>
						<?php
						}
					?>
					
					<?php
						if(isset($_POST['cmdEdit']))
						{
							$idKurir = $_POST['idKurir'];
							$kurir = $_POST['kurir'];
							$namedetail = $_POST['namedetail'];
							
							$kurir = strtoupper(str_replace("'","",$kurir));
							$namedetail = strtoupper(str_replace("'","",$namedetail));
						?>
							<div class="col100 borderGray padding10 marginBottom20">
								<div class="col95 marginAuto">
									<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
										Result Process
									</div>
								
								<?php
									//Cek Duplicate
									$queryC = "select idKurir from thermal_kurir where upper(kurir) = '".$kurir."' and idKurir <> ".$idKurir;
									$resultC = mysql_query($queryC);
									$numrowC = mysql_num_rows($resultC);
									
									if($numrowC == 0)
									{
										//Insert here
										$queryI = "update thermal_kurir
													set kurir = '".$kurir."',
													namedetail = '".$namedetail."'
													where idKurir = ".$idKurir;
										$resultI = mysql_query($queryI);
										//echo $queryI."<br>";
										if($resultI)
										{
										?>
											<div class="col100 textBold marginBottom10">
												Update Courier successfully completed
											</div>
										<?php
										}
										else
										{
										?>
											<div class="col100 textBold colorRed marginBottom10">
												Update Courier failed completed
											</div>
										<?php
										}
									}
									else
									{
									?>
										<div class="col100 textBold colorRed marginBottom10">
											Duplicate Courier Data. Please check table list
										</div>
									<?php	
									}
								?>
								</div>
							</div>
						<?php
						}
					?>
					
					<?php
						if(isset($_GET['idKurir']))
						{
							$idKurir = $_GET['idKurir'];
							
							$queryP = "select idKurir,caseid,merchant,mid,tid,sla,sn,sim,sam
										from thermal_kurir where idKurir = ".$idKurir;
							$resultP = mysql_query($queryP);
							$rowP = mysql_fetch_array($resultP);
							//echo $queryP."<br>";
							
							$caseid = $rowP['caseid'];
							$merchant = $rowP['merchant'];
							$mid = $rowP['mid'];
							$tid = $rowP['tid'];
							$sn = $rowP['sn'];
							$sim = $rowP['sim'];
							$sam = $rowP['sam'];
						}
						elseif(!isset($_GET['idKurir']))
						{
							$caseid = $rowP['caseid'];
							$merchant = $rowP['merchant'];
							$mid = $rowP['mid'];
							$tid = $rowP['tid'];
							$sn = $rowP['sn'];
							$sim = $rowP['sim'];
							$sam = $rowP['sam'];
						}
					?>
				
					<div class="col100 borderGray padding10">
						<div class="col95 marginAuto">
							<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
								Manage
							</div>
							
							<form name="form_1" action="kurir.php" method="post" onsubmit="return validate_form1()">
							<?php
								if(isset($_GET['idKurir']))
								{
								?>
									<input type="hidden" name="idKurir" value="<?php echo $idKurir ?>">
								<?php
								}
							?>
								<div class="col100 textBold paddingTop5 marginBottom10">Case Id</div>
								<div class="col100">
									<input type="text" name="namedetail" class="textinputbasic3 marginBottom20" value="<?php echo $caseid ?>">
								</div>
								
								<div class="col100 textBold paddingTop5 marginBottom10">Merchant Name </div>
								<div class="col100">
									<input type="text" name="namedetail" class="textinputbasic marginBottom20" value="<?php echo $merchant ?>">
								</div>
								
								
								<div class="col100 textBold paddingTop5 marginBottom10">MID</div>
								<div class="col100">
									<input type="text" name="namedetail" class="textinputbasic marginBottom20" value="<?php echo $mid ?>">
								</div>
								<div class="col100 textBold paddingTop5 marginBottom10">TID</div>
								<div class="col100">
									<input type="text" name="namedetail" class="textinputbasic marginBottom20" value="<?php echo $tid ?>">
								</div>
								<div class="col100 textBold paddingTop5 marginBottom10">Serial Number</div>
								<div class="col100">
									<input type="text" name="namedetail" class="textinputbasic marginBottom20" value="<?php echo $sn ?>">
								</div>
								<div class="col100 textBold paddingTop5 marginBottom10">SIM</div>
								<div class="col100">
									<input type="text" name="namedetail" class="textinputbasic marginBottom20" value="<?php echo $sim ?>">
								</div>
								<div class="col100 textBold paddingTop5 marginBottom10">SUM</div>
								<div class="col100">
									<input type="text" name="namedetail" class="textinputbasic marginBottom20" value="<?php echo $sum ?>">
								</div>
								
							<?php
								if(!isset($_GET['idKurir']))
								{
								?>
									<input type="submit" name="cmdSubmit" value="Submit Data" class="styleButtonMiddle">
								<?php
								}
								elseif(isset($_GET['idKurir']))
								{
								?>
									<input type="submit" name="cmdEdit" value="Update Data" class="styleButtonMiddle">
								<?php
								}
							?>
								
							</form>
							
						</div>
					</div>
				</div>
				
				<div class="col60 floatLeft marginRight20 borderGray padding10">
					<div class="col95 marginAuto">
						<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							List Vendor
						</div>
						
					<?php
						$queryLD = "select idKurir,caseid,merchant,mid,tid,sla
									from thermal_kurir
									order by caseid";
						$resultLD = mysql_query($queryLD);
						$no = 1;
					?>
						<table class="content">
							<tr>
								<th class="content textCenter fontSize09">No</th>
								<th class="content textCenter">Case ID</th>
								<th class="content textCenter">Merchant Name</th>
								<th class="content textCenter">MID</th>
								<th class="content textCenter">TID</th>
								<th class="content textCenter">SLA</th>
							</tr>
							<?php
								while($rowLD = mysql_fetch_array($resultLD))
								{
									$idKurir = $rowLD['idKurir'];
								?>
								<tr class="linkClick" onclick="window.location='kurir.php<?php echo "?idKurir=".$idKurir ?>'">
									<td class="viewData fontSize085 col5 textCenter"><?php echo $no ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['caseid'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['merchant'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['mid'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['tid'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['sla'] ?></td>
								</tr>
								<?php
									$no++;
								}
								?>
						</table>
					</div>
				</div>
				
				<div class="margine"></div>
				
			</div>
			
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>