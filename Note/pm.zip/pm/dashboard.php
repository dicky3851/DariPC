<!doctype html>
<html>

<head>
	<title>Dashboard Mapping Processing</title>
	<script src="src/dist/Chart.min.js"></script>
	<script src="src/utils.js"></script>
	
	<link href="css/style2.css" rel="stylesheet" type="text/css"/>
	<link href="css/style4.css" rel="stylesheet" type="text/css"/>
	
	<meta http-equiv="refresh" content="35">
	
	<!--<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>-->
	
	<style>
	canvas {
		-moz-user-select: none;
		-webkit-user-select: none;
		-ms-user-select: none;
	}
	</style>
</head>

<script>
	function validate_form1()
	{	
		if(document.form_1.date1.value.length == 0)
		{
			alert('Plesase input Interval Periode 1');
			document.form_1.date1.focus();
			return false;
		}
		
		if(document.form_1.date2.value.length == 0)
		{
			alert('Plesase input Interval Periode 1');
			document.form_1.date2.focus();
			return false;
		}
		
		if(document.form_1.date3.value.length == 0)
		{
			alert('Plesase input Interval Periode 2');
			document.form_1.date3.focus();
			return false;
		}
		
		if(document.form_1.date4.value.length == 0)
		{
			alert('Plesase input Interval Periode 2');
			document.form_1.date4.focus();
			return false;
		}
        
        return true;
    }

</script>

<?php
	include("connect_db.php");
?>

 
<body>
	
	<div class="col90 marginAuto paddingTop20">
		<div class="col15 floatLeft">
			<img src ="images/logo3.png" class="imglogo" />
		</div>
		<div class="col60 floatLeft ">
			<div class="col100 textCenter marginBottom20 fontSize12 textBold "><center>Dashboard of Deployment Processing	</center></div>
			                      
			<div class="col100 textCenter marginBottom20 fontSize11 textBold colorBlue2 "><center>						
													<?php
													$tanggal= mktime(date("m"),date("d"),date("Y"));
													echo " <b>".date("d-M-Y", $tanggal)."</b> ";
													date_default_timezone_set('Asia/Jakarta');
													$jam=date("H:i");
													echo "| <b>". $jam." "."WIB</b>";
													$a = date ("H");
													if (($a>=6) && ($a<=11)){
													}
													?> 
			</center></div>
			
		</div>
		<!-- <div class="col15 floatLeft border1">
			<img src ="images/logo3.png" class="imglogo border1" />
		</div>-->
		<div class="margine"></div>
		
		<div class="margine"></div>
		
		<?php
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Warehouse'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data1 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Ready to Mapping'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data2 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Schedule'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data3 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Vendor'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data4 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Asset'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data5 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Customer'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data6 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Vendor'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data7 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Re-mapping'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data8 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Cancel'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data9 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Close Completed'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data10 = floatval($rowD['jml']);
		?>
		
		<div class="margine"></div>
		
		<style>
			.mySlidesTop1 {display:none;}
		</style>
		
		<!--<div class="mySlidesTop1 w3-container w3-red">
			Test1
		</div>
		
		<div class="mySlidesTop1 w3-container w3-red">
			Test2
		</div>
		
		<div class="mySlidesTop1 w3-container w3-red">
			Test3
		</div>-->
		
		<div class="mySlidesTop1 w3-container w3-red">
			<div class="col80 marginAuto backgroundWhite">
				<div class="col100 textBold fontSize15 marginBottom20">Deployment Status - All Vendor</div>
					
				<div id="container" class="col100">
					<canvas id="canvas"></canvas>
				</div>
			</div>
					
			<div class="margine"></div>
		</div>
		
		<script>
		
		function tebal(){
			document.getElementById("efek").style.fontWeight = "bold";
						}
			
			var color = Chart.helpers.color;
			var barChartData = {
				labels: ['Open Warehouse','Ready to Mapping','Open Schedule','Send Back to Vendor','Send Back to Asset','Pending Customer','Pending Vendor','Re-mapping','Cancel','Close Completed'],
				
				
				
				datasets: [{
					label: '',
					backgroundColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderWidth: 1,
					data: [
						<?php
							echo $data1.",".$data2.",".$data3.",".$data4.",".$data5.",".$data6.",".$data7.",".$data8.",".$data9.",".$data10;
						?>
						]
				}]

			};

			var ctx = document.getElementById('canvas').getContext('2d');
			window.myBar = new Chart(ctx, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: false,
						text: 'Chart.js Bar Chart'
					},
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});

		</script>
		
		<?php
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Warehouse' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data1 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Ready to Mapping' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data2 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Schedule' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data3 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Vendor' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data4 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Asset' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data5 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Customer' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data6 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Vendor' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data7 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Re-mapping' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data8 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Cancel' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data9 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Close Completed' and vendor = 'VISIONET'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data10 = floatval($rowD['jml']);
		?>
		
		<div class="margine"></div>
		
		<div class="mySlidesTop1 w3-container w3-red">
			<div class="col80 marginAuto backgroundWhite marginTop20">
				<div class="col100 textBold fontSize15 marginBottom20">VISIONET</div>
					
				<div id="container" class="col100">
					<canvas id="canvas2"></canvas>
				</div>
			</div>
		</div>
				
		<div class="margine"></div>
		
		<script>
			var color = Chart.helpers.color;
			var barChartData = {
				labels: ['Open Warehouse','Ready to Mapping','Open Schedule','Send Back to Vendor','Send Back to Asset','Pending Customer','Pending Vendor','Re-mapping','Cancel','Close Completed'],
				
				datasets: [{
					label: '',
					backgroundColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderWidth: 1,
					data: [
						<?php
							echo $data1.",".$data2.",".$data3.",".$data4.",".$data5.",".$data6.",".$data7.",".$data8.",".$data9.",".$data10;
						?>
						]
				}]

			};

			var ctx = document.getElementById('canvas2').getContext('2d');
			window.myBar = new Chart(ctx, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: false,
						text: 'Chart.js Bar Chart'
					},
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});

		</script>
		
		
		
		<?php
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Warehouse' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data1 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Ready to Mapping' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data2 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Schedule' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data3 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Vendor' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data4 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Asset' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data5 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Customer' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data6 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Vendor' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data7 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Re-mapping' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data8 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Cancel' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data9 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Close Completed' and vendor = 'INDOPAY'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data10 = floatval($rowD['jml']);
		?>
		
		<div class="margine"></div>
		
		<div class="mySlidesTop1 w3-container w3-red">
			<div class="col80 marginAuto backgroundWhite marginTop20">
				<div class="col100 textBold fontSize15 marginBottom20">INDOPAY</div>
					
				<div id="container" class="col100">
					<canvas id="canvas3"></canvas>
				</div>
			</div>
		</div>
				
		<div class="margine"></div>
		
		<script>
			var color = Chart.helpers.color;
			var barChartData = {
				labels: ['Open Warehouse','Ready to Mapping','Open Schedule','Send Back to Vendor','Send Back to Asset','Pending Customer','Pending Vendor','Re-mapping','Cancel','Close Completed'],
				
				datasets: [{
					label: '',
					backgroundColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderWidth: 1,
					data: [
						<?php
							echo $data1.",".$data2.",".$data3.",".$data4.",".$data5.",".$data6.",".$data7.",".$data8.",".$data9.",".$data10;
						?>
						]
				}]

			};

			var ctx = document.getElementById('canvas3').getContext('2d');
			window.myBar = new Chart(ctx, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: false,
						text: 'Chart.js Bar Chart'
					},
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});

		</script>
		
		<?php
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Warehouse' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data1 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Ready to Mapping' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data2 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Schedule' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data3 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Vendor' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data4 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Asset' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data5 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Customer' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data6 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Vendor' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data7 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Re-mapping' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data8 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Cancel' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data9 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Close Completed' and vendor = 'INGENICO'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data10 = floatval($rowD['jml']);
		?>
		
		<div class="margine"></div>
		
		<div class="mySlidesTop1 w3-container w3-red">
			<div class="col80 marginAuto backgroundWhite marginTop20">
				<div class="col100 textBold fontSize15 marginBottom20">INGENICO</div>
					
				<div id="container" class="col100">
					<canvas id="canvas4"></canvas>
				</div>
			</div>
		</div>
				
		<div class="margine"></div>
		
		<script>
			var color = Chart.helpers.color;
			var barChartData = {
				labels: ['Open Warehouse','Ready to Mapping','Open Schedule','Send Back to Vendor','Send Back to Asset','Pending Customer','Pending Vendor','Re-mapping','Cancel','Close Completed'],
				
				datasets: [{
					label: '',
					backgroundColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderWidth: 1,
					data: [
						<?php
							echo $data1.",".$data2.",".$data3.",".$data4.",".$data5.",".$data6.",".$data7.",".$data8.",".$data9.",".$data10;
						?>
						]
				}]

			};

			var ctx = document.getElementById('canvas4').getContext('2d');
			window.myBar = new Chart(ctx, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: false,
						text: 'Chart.js Bar Chart'
					},
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});

		</script>
		
		<?php
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Warehouse' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data1 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Ready to Mapping' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data2 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Schedule' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data3 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Vendor' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data4 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Asset' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data5 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Customer' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data6 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Vendor' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data7 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Re-mapping' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data8 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Cancel' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data9 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Close Completed' and vendor = 'BRINGIN GIGANTARA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data10 = floatval($rowD['jml']);
		?>
		
		<div class="margine"></div>
		
		<div class="mySlidesTop1 w3-container w3-red">
			<div class="col80 marginAuto backgroundWhite marginTop20">
				<div class="col100 textBold fontSize15 marginBottom20">BRINGIN GIGANTARA</div>
					
				<div id="container" class="col100">
					<canvas id="canvas5"></canvas>
				</div>
			</div>
		</div>
				
		<div class="margine"></div>
		
		<script>
			var color = Chart.helpers.color;
			var barChartData = {
				labels: ['Open Warehouse','Ready to Mapping','Open Schedule','Send Back to Vendor','Send Back to Asset','Pending Customer','Pending Vendor','Re-mapping','Cancel','Close Completed'],
				
				datasets: [{
					label: '',
					backgroundColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderWidth: 1,
					data: [
						<?php
							echo $data1.",".$data2.",".$data3.",".$data4.",".$data5.",".$data6.",".$data7.",".$data8.",".$data9.",".$data10;
						?>
						]
				}]

			};

			var ctx = document.getElementById('canvas5').getContext('2d');
			window.myBar = new Chart(ctx, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: false,
						text: 'Chart.js Bar Chart'
					},
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});

		</script>
		
		<?php
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Warehouse' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data1 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Ready to Mapping' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data2 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Schedule' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data3 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Vendor' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data4 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Asset' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data5 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Customer' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data6 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Vendor' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data7 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Re-mapping' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data8 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Cancel' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data9 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Close Completed' and vendor = 'PRIMAVISTA'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data10 = floatval($rowD['jml']);
		?>
		
		<div class="margine"></div>
		
		<div class="mySlidesTop1 w3-container w3-red">
			<div class="col80 marginAuto backgroundWhite marginTop20">
				<div class="col100 textBold fontSize15 marginBottom20">PRIMAVISTA</div>
					
				<div id="container" class="col100">
					<canvas id="canvas6"></canvas>
				</div>
			</div>
		</div>
				
		<div class="margine"></div>
		
		<script>
			var color = Chart.helpers.color;
			var barChartData = {
				labels: ['Open Warehouse','Ready to Mapping','Open Schedule','Send Back to Vendor','Send Back to Asset','Pending Customer','Pending Vendor','Re-mapping','Cancel','Close Completed'],
				
				datasets: [{
					label: '',
					backgroundColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderWidth: 1,
					data: [
						<?php
							echo $data1.",".$data2.",".$data3.",".$data4.",".$data5.",".$data6.",".$data7.",".$data8.",".$data9.",".$data10;
						?>
						]
				}]

			};

			var ctx = document.getElementById('canvas6').getContext('2d');
			window.myBar = new Chart(ctx, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: false,
						text: 'Chart.js Bar Chart'
					},
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});

		</script>
		
		<?php
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Warehouse' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data1 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Ready to Mapping' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data2 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Open Schedule' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data3 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Vendor' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data4 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Send Back to Asset' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data5 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Customer' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data6 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Pending Vendor' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data7 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Re-mapping' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data8 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Cancel' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data9 = floatval($rowD['jml']);
				
			$queryD = "SELECT COUNT(*) AS 'jml'
						FROM asset_mapping
						WHERE statusAsset = 'Close Completed' and vendor = 'TELKOM'";
			$resultD = mysql_query($queryD);
			//echo $queryD."<br><br>";
			$rowD = mysql_fetch_array($resultD);
			$data10 = floatval($rowD['jml']);
		?>
		
		<div class="margine"></div>
		
		<div class="mySlidesTop1 w3-container w3-red">
			<div class="col80 marginAuto backgroundWhite marginTop20">
				<div class="col100 textBold fontSize15 marginBottom20">TELKOM</div>
					
				<div id="container" class="col100">
					<canvas id="canvas7"></canvas>
				</div>
			</div>
		</div>
				
		<div class="margine"></div>
		
		<script>
			var color = Chart.helpers.color;
			var barChartData = {
					labels: ['Open Warehouse','Ready to Mapping','Open Schedule','Send Back to Vendor','Send Back to Asset','Pending Customer','Pending Vendor','Re-mapping','Cancel','Close Completed'],
				
			   	datasets: [{
					label: '',
					backgroundColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderColor: [
						'rgba(255,99,132,1)',
						'rgba(238,180,34,1)',
						'rgba(205,0,205,1)',
						'rgba(72,61,139,1)',
						'rgba(159,182,205,1)',
						'rgba(0,197,205,1)',
						'rgba(0,199,140,1)',
						'rgba(0,201,87,1)',
						'rgba(238,238,0,1)',
						'rgba(54,162,235,1)'
						],
					borderWidth: 1,
					data: [
						<?php
							echo $data1.",".$data2.",".$data3.",".$data4.",".$data5.",".$data6.",".$data7.",".$data8.",".$data9.",".$data10;
						?>
						]
				}]

			};

			var ctx = document.getElementById('canvas7').getContext('2d');
			window.myBar = new Chart(ctx, {
				type: 'bar',
				data: barChartData,
				options: {
					responsive: true,
					legend: {
						position: 'top',
					},
					title: {
						display: false,
						text: 'Chart.js Bar Chart'
					},
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero:true
							}
						}]
					}
				}
			});
			
		</script>
		
		
		
		
		<div class="margine"></div>
		</div>
				<script>
                    var slideIndex21 = 0;
                    carousel21();

                    function carousel21() {
                        var i;
                        var x = document.getElementsByClassName("mySlidesTop1");
                        for (i = 0; i < x.length; i++) {
                            x[i].style.display = "none"; 
                        }
                        slideIndex21++;
                        if (slideIndex21 > x.length) {slideIndex21 = 1} 
                        x[slideIndex21-1].style.display = "block"; 
                        setTimeout(carousel21, 5000); 
                    }
                </script>
	
			
		
	
	<?php
		//$labels = array();
	?>

	
	
	<!--<script>
		var color = Chart.helpers.color;
		var barChartData = {
			labels: ['Periode 1','Periode 2'],
			
			datasets: [{
				label: '#Approved',
				backgroundColor: color(window.chartColors.red).alpha(1).rgbString(),
				borderColor: window.chartColors.red,
				borderWidth: 1,
				data: [
					<?php
						echo $data1a.",".$data2a;
					?>
					]
			}, {
				label: '#Rejected',
				backgroundColor: color(window.chartColors.blue).alpha(1).rgbString(),
				borderColor: window.chartColors.blue,
				borderWidth: 1,
				data: [
					<?php
						echo $data1b.",".$data2b;
					?>
					]
			}]

		};
		

		var ctx = document.getElementById('canvas2').getContext('2d');
		window.myBar = new Chart(ctx, {
			type: 'bar',
			data: barChartData,
			options: {
				responsive: true,
				legend: {
					position: 'top',
				},
				title: {
					display: false,
					text: 'Chart.js Bar Chart'
				},
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}
			}
		});

	</script>-->
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
</body>

</html>
<body>
	
	