						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							List Hasil PM
						</div>
						<div class="col100 marginTop20 marginBottom2">
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">MID</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['MID'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['TID'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Nama Merchant</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mrchnt_name'] ?>
								</div>
							</div>
							<div class="margine"></div>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant Address</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mrchnt_addr'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">City</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['city'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Status EDC</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['edc_status'] ?>
								</div>
							</div>
							<div class="margine"></div>
							
						</div>