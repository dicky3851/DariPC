<?php
session_start();
if(!isset($_SESSION['userID']))
{
	header("Location:login.php");
}

include('connect_db.php');
$date1 = $_GET['date1'];
$date2 = $_GET['date2'];
$type = $_GET['type'];
$field = $_GET['field'];
$idVendorC = $_GET['idVendorC'];

if($idVendorC <> 0)
{
		//Get Nama Vendor
	$queryGV = "select vendor from vendor where idVendor = ".$idVendorC;
	$resultGV = mysql_query($queryGV);
	$rowGV = mysql_fetch_array($resultGV);
	$vendorName = $rowGV['vendor'];
}

$file_name = "Report_Mapping_".$type."_".$date1."_".$date2;

header("Content-type: application/octet-stream");
header('Content-Type: plain/text'); 
header("Content-Disposition: attachment; filename=".$file_name.".xls");
header("Pragma: no-cache");
header("Expires: 0");

?>
Print date : <?php echo date("d/m/Y") ?><br>
<table border="1">
	<tr>
		<th colspan="28"><h2>Data Mapping - <?php echo $type ?></h2></th>
	</tr>

	<?php
	$queryLC = "select idMapping,date_format(uploadDT,'%d/%m/%Y') as 'uploadDT',date_format(updateDT,'%d/%m/%Y') as 'updateDT',
	statusAsset,type,caseID,mid,tid,tidreplace,mid_bri,tid_bri,mid_btn,tid_btn,mid_bni,tid_bni,mid_danamon,tid_danamon,mid_astrapay,tid_astrapay,mid_bsi,tid_bsi,
	note,merchant,address,city,vendor,vendorupdate,sn_edc,sn_sam,sn_sim,wr,provider_sim,produk_sam,
	remarks,date_format(datewr,'%d/%m/%Y') as 'datewr',terminaltype,dongle,provider,pendingreason,targetmaping
	CASE WHEN b.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
	WHEN b.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
	END AS 'sla',
	a.idRC,a.rc,c.username
	from asset_mapping a
	INNER JOIN asset_status b ON a.idStatus = b.idStatus
	inner join asset_login c on a.updateBy = c.userID
	where 1 > 0 ";

	if($type <> "All")
	{
		$queryLC = $queryLC." and statusAsset = '".$type."'";
	}

	if(!empty($date1) && $date1 <> "" && !empty($date2) && $date2 <> "")
	{
		$queryLC = $queryLC." and updateDT between '".$date1."' and '".$date2."'";
	}

	if($idVendorC <> 0)
	{
		$queryLC = $queryLC." and vendor = '".$vendorName."'";
	}

	if(!empty($field) || $field <> "")
	{
		$queryLC = $queryLC." and (mid like '%".$field."%' or tid like '%".$field."%' or caseID like '%".$field."%' or wr like '%".$field."%'
		or merchant like '%".$field."%')";
	}

	$queryLC = $queryLC." order by sla desc";
							//echo $queryLC."<br>";
	$resultLC = mysql_query($queryLC);
	$totalRoll = 0;
	?>
	<tr>
		<th>Case ID</th>
		<th>Open Warehouse Date</th>
		<th>Last Update Date</th>
		<th>Last Update By</th>
		<th>Status</th>
		<th>SLA (Days)</th>
		<th>MID</th>
		<th>TID</th>
		<th>TID Replace</th>
		<th>MID BRI</th>
		<th>TID BRI</th>
		<th>MID BTN</th>
		<th>TID BTN</th>
		<th>MID BNI</th>
		<th>TID BNI</th>
		<th>MID Danamon</th>
		<th>TID Danamon</th>
		<th>MID Astrapay</th>
		<th>TID Astrapay</th>
		<th>MID BSI</th>
		<th>TID BSI</th>
		<th>Note</th>
		<th>Merchant Name</th>
		<th>Address</th>
		<th>City</th>
		<th>Vendor</th>
		<th>Vendor Update</th>
		<th>Terminal Type</th>
		<th>Dongle</th>
		<th>Provider</th>
		<th>SN EDC</th>
		<th>SN SAM</th>
		<th>SN SIM</th>
		<th>WR</th>
		<th>Provider SIM Baru</th>
		<th>Produk SAM Baru</th>
		<th>Remarks</th>
		<th>Pending Root Cause</th>
		<th>Pending Reason</th>
		<th>Target Maping</th>


	</tr>
	<?php
	while($rowLC = mysql_fetch_array($resultLC))
	{
		?>
		<tr>
			<td><?php echo "'".$rowLC['caseID'] ?></td>
			<td><?php echo "'".$rowLC['datewr'] ?></td>
			<td><?php echo "'".$rowLC['updateDT'] ?></td>
			<td><?php echo $rowLC['username'] ?></td>
			<td><?php echo $rowLC['statusAsset'] ?></td>
			<td><?php echo $rowLC['sla'] ?></td>
			<td><?php echo $rowLC['mid'] ?></td>
			<td><?php echo $rowLC['tid'] ?></td>
			<td><?php echo $rowLC['tidreplace'] ?></td>
			<td><?php echo $rowLC['mid_bri'] ?></td>
			<td><?php echo $rowLC['tid_bri'] ?></td>
			<td><?php echo $rowLC['mid_btn'] ?></td>
			<td><?php echo $rowLC['tid_btn'] ?></td>
			<td><?php echo $rowLC['mid_bni'] ?></td>
			<td><?php echo $rowLC['tid_bni'] ?></td>
			<td><?php echo $rowLC['mid_danamon'] ?></td>
			<td><?php echo $rowLC['tid_danamon'] ?></td>
			<td><?php echo $rowLC['mid_astrapay'] ?></td>
			<td><?php echo $rowLC['tid_astrapay'] ?></td>
			<td><?php echo $rowLC['mid_bsi'] ?></td>
			<td><?php echo $rowLC['tid_bsi'] ?></td>
			<td><?php echo $rowLC['note'] ?></td>
			<td><?php echo $rowLC['merchant'] ?></td>
			<td><?php echo $rowLC['address'] ?></td>
			<td><?php echo $rowLC['city'] ?></td>
			<td><?php echo $rowLC['vendor'] ?></td>
			<td><?php echo $rowLC['vendorupdate'] ?></td>
			<td><?php echo $rowLC['terminaltype'] ?></td>
			<td><?php echo $rowLC['dongle'] ?></td>
			<td><?php echo $rowLC['provider'] ?></td>
			<td><?php echo "'".$rowLC['sn_edc'] ?></td>
			<td><?php echo "'".$rowLC['sn_sam'] ?></td>
			<td><?php echo "'".$rowLC['sn_sim'] ?></td>
			<td><?php echo $rowLC['wr'] ?></td>
			<td><?php echo $rowLC['provider_sim'] ?></td>
			<td><?php echo $rowLC['produk_sam'] ?></td>
			<td><?php echo $rowLC['remarks'] ?></td>
			<td><?php echo $rowLC['rc'] ?></td>
			<td><?php echo $rowLC['pendingreason'] ?></td>
			<td><?php echo $rowLC['targetmaping'] ?></td>

		</tr>
		<?php
	}
	?>
</table>

