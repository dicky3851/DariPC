<?php
	session_start();
	if(!isset($_SESSION['userID']))
	{
		header("Location:login.php");
	}
	
	include('connect_db.php');
	$idMapping = $_GET['idMapping'];
	
	$file_name = "Report_Mapping_Log_".$idMapping;
	
	header("Content-type: application/octet-stream");
	header('Content-Type: plain/text'); 
	header("Content-Disposition: attachment; filename=".$file_name.".xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	
?>
						Print date : <?php echo date("d/m/Y") ?><br>
						<table border="1">
							<tr>
								<th colspan="13"><h2>Data Log Mapping</h2></th>
							</tr>
							
						<?php
							$queryLC = "select idLog,d.mid,d.tid,d.merchant,
										date_format(logDT2,'%d/%m/%Y %H:%i') as 'logDT',b.username,c.status,a.remarks,a.idRC,a.rc,
										a.sn_edc,a.sn_sam,a.sn_sim,a.provider_sim,a.produk_sam
										from asset_log a
										inner join asset_login b on a.logBy = b.userID
										inner join asset_status c on c.idStatus = a.idStatus
										inner join asset_mapping d on d.idMapping = a.idMapping
										where a.idMapping = ".$idMapping."
										order by idLog desc";
							
							$resultLC = mysql_query($queryLC);
							//echo $queryLC."<br>";
							$totalRoll = 0;
						?>
							<tr>
								<th>MID</th>
								<th>TID</th>
								<th>Merchant Name</th>
								<th>Date & Time</th>
								<th>Status</th>
								<th>SN EDC</th>
								<th>SN SAM</th>
								<th>SN SIM</th>
								<th>Provider SIM</th>
								<th>Product SAM</th>
								<th>Pending Root Cause</th>
								<th>User</th>
								<th>Remarks</th>
							</tr>
							<?php
								while($rowLC = mysql_fetch_array($resultLC))
								{
								?>
									<tr>
										<td><?php echo $rowLC['mid'] ?></td>
										<td><?php echo $rowLC['tid'] ?></td>
										<td><?php echo $rowLC['merchant'] ?></td>
										<td><?php echo "'".$rowLC['logDT'] ?></td>
										<td><?php echo $rowLC['status'] ?></td>
										<td><?php echo "'".$rowLC['sn_edc'] ?></td>
										<td><?php echo "'".$rowLC['sn_sam'] ?></td>
										<td><?php echo "'".$rowLC['sn_sim'] ?></td>
										<td><?php echo $rowLC['provider_sim'] ?></td>
										<td><?php echo $rowLC['produk_sam'] ?></td>
										<td><?php echo $rowLC['rc'] ?></td>
										<td><?php echo $rowLC['username'] ?></td>
										<td><?php echo $rowLC['remarks'] ?></td>
										
									</tr>
							<?php
								}
							?>
						</table>
    
