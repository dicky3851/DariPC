<?php
    session_start();
    //header("Location:login.php");
    if(!isset($_SESSION['userID']))
    {
        header("Location:login.php");
    }
            
    include('connect_db.php');
    include('excel_reader2.php');
	include("terbilang.php");
    
    $userID = $_SESSION['userID'];
    $username = $_SESSION['username'];
    $usergroup = $_SESSION['usergroup'];
	$idVendorC = $_SESSION['idVendor'];
	
	if(empty($idVendorC) || $idVendorC == "")
		$idVendorC = 0;
		
	//Get Nama Vendor
	$queryGV = "select vendor from vendor where idVendor = ".$idVendorC;
	$resultGV = mysql_query($queryGV);
	$rowGV = mysql_fetch_array($resultGV);
	$vendorName = $rowGV['vendor'];
		
	//echo "Username : ".$username."<br>";
	//echo "idVendor : ".$idVendorC."<br>";
?>
    <!doctype html>
    <html>
        <head>
            <title>Monitoring PM System</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <meta name="keywords" content="Kalbis Institute" />
            <script type="application/x-javascript"> addEventListener("load", function() {setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
            <!meta charset utf="8">
            
            <!--owlcss-->
            <link href="css/owl.carousel.css" rel="stylesheet">
            <!--bootstrap-->
                <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
            <!--coustom css-->
                <link href="css/style2.css" rel="stylesheet" type="text/css"/>
				<link href="css/style4.css" rel="stylesheet" type="text/css"/>
                
            <!--default-js-->
                <script src="js/jquery-2.1.4.min.js"></script>
                <script src="js/jquery.min.js"></script>
            <!--bootstrap-js-->
                <script src="js/bootstrap.min.js"></script>
            <!--script-->
                <script type="text/javascript" src="js/move-top.js"></script>
                <script type="text/javascript" src="js/easing.js"></script>
            <!--script-->
            
            <!--<link rel="Shortcut icon" href="images/logo_url.png">-->
            
            <script src="js/jquery.js"></script>
            <script src="js/jquery-ui.js"></script>
            <link href="css/jquery-ui.css" rel="stylesheet">
        </head>
    
    
        <script>
            function Comma(Num) { //function to add commas to textboxes
                Num += '';
                Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
                Num = Num.replace(',', ''); Num = Num.replace(',', ''); Num = Num.replace(',', '');
                x = Num.split('.');
                x1 = x[0];
                x2 = x.length > 1 ? '.' + x[1] : '';
                var rgx = /(\d+)(\d{3})/;
                while (rgx.test(x1))
                    x1 = x1.replace(rgx, '$1' + ',' + '$2');
                return x1 + x2;
            }
        </script>
		
<?php
	function twoDigitPeriode($string) {
		if(strlen($string) == 1)
		{
			$stringPeriode = "0".$string;
		}
		else
		{
			$stringPeriode = $string;
		}
		
		return $stringPeriode;
	}
	
	function dateValidation ($yearIns,$monthIns,$dateIns) {
		//Check month with 30 days consist
		if(intval($monthIns) == 4 || intval($monthIns) == 6 || intval($monthIns) == 9 || intval($monthIns) == 11)
		{
			if($dateIns == 31)
			{
				$dateIns = 30;
			}
		}
		elseif(intval($monthIns) == 2)
		{
			//Check Kabisat year
			if(($yearIns % 4) == 0)
			{
				//Kabisat Year
				if($dateIns > 29)
				{
					$dateIns = 29;
				}
			}
			else
			{
				//Non Kabisat Year
				if($dateIns > 28)
				{
					$dateIns = 28;
				}
			}
		}
		
		return $yearIns."-".twoDigitPeriode($monthIns)."-".twoDigitPeriode($dateIns);
	}
	
	function GetTrxID() {
		//Get last trxID
		$queryGL = "select trxid 
					from yy_journal
					order by trxid desc
					limit 1";
		$resultGL = mysql_query($queryGL);
		$numrowGL = mysql_num_rows($resultGL);
		$rowGL = mysql_fetch_array($resultGL);
		
		if($numrowGL == 0 || empty($rowGL['trxid']) || $rowGL['trxid'] == "")
		{
			$trxid = 1;
		}
		else
		{
			$trxid = intval($rowGL['trxid']) + 1;
		}
		
		return $trxid;
	}
	
	function GetNoteNo($type) {
		//Get Last No
		$queryLN = "SELECT MAX(SUBSTRING(note_no,1,6)) as 'lastNo'
					FROM nota
					WHERE SUBSTRING(note_no,15,7) = DATE_FORMAT(NOW(),'%m/%Y')";
		$resultLN = mysql_query($queryLN);
		$numrowLN = mysql_num_rows($resultLN);
		$rowLN = mysql_fetch_array($resultLN);
		if($numrowLN == 0)
		{
			$note_no = "000001/".$type."/AMS/".date("m/Y");
		}
		else
		{
			$lastNo = $rowLN['lastNo'];
					
			$lastNoNumber = $lastNo;
			$nextNumber = floatval($lastNoNumber) + 1;
					
			if(strlen($nextNumber) == 1)
				$nextNumberString = "00000".$nextNumber;
			elseif(strlen($nextNumber) == 2)
				$nextNumberString = "0000".$nextNumber;
			elseif(strlen($nextNumber) == 3)
				$nextNumberString = "000".$nextNumber;
			elseif(strlen($nextNumber) == 4)
				$nextNumberString = "00".$nextNumber;
			elseif(strlen($nextNumber) == 5)
				$nextNumberString = "0".$nextNumber;
			else
				$nextNumberString = $nextNumber;
						
			$note_no = $nextNumberString."/".$type."/AMS/".date("m/Y");
		}
			
		return $note_no;
	}
	
	function GetVoucherNo_old($type,$voucher_date) {
		$monthYear = substr($voucher_date,5,2)."/".substr($voucher_date,0,4);
		//Get Last No
		$queryLN = "SELECT MAX(SUBSTRING(voucher_no,1,6)) as 'lastNo'
					FROM voucher
					WHERE SUBSTRING(voucher_no,15,7) = '".$monthYear."'";
		$resultLN = mysql_query($queryLN);
		$numrowLN = mysql_num_rows($resultLN);
		$rowLN = mysql_fetch_array($resultLN);
		if($numrowLN == 0)
		{
			$voucher_no = "000001/".$type."/AMS/".$monthYear;
		}
		else
		{
			$lastNo = $rowLN['lastNo'];
					
			$lastNoNumber = $lastNo;
			$nextNumber = floatval($lastNoNumber) + 1;
					
			if(strlen($nextNumber) == 1)
				$nextNumberString = "00000".$nextNumber;
			elseif(strlen($nextNumber) == 2)
				$nextNumberString = "0000".$nextNumber;
			elseif(strlen($nextNumber) == 3)
				$nextNumberString = "000".$nextNumber;
			elseif(strlen($nextNumber) == 4)
				$nextNumberString = "00".$nextNumber;
			elseif(strlen($nextNumber) == 5)
				$nextNumberString = "0".$nextNumber;
			else
				$nextNumberString = $nextNumber;
						
			$voucher_no = $nextNumberString."/".$type."/AMS/".$monthYear;
		}
				
		return $voucher_no;
	}
	
	function GetVoucherLast($voucher_type,$voucher_date,$idBank) {
		
		$monthYear = substr($voucher_date,5,2)."-".substr($voucher_date,0,4);
		
		//Get Last No
		$queryLN = "SELECT MAX(voucher_urut) as 'lastNo'
					FROM voucher
					WHERE voucher_type = '".$voucher_type."' and DATE_FORMAT(voucher_date,'%m-%Y') = '".$monthYear."' and idBank = ".$idBank;
		$resultLN = mysql_query($queryLN);
		$numrowLN = mysql_num_rows($resultLN);
		$rowLN = mysql_fetch_array($resultLN);
		$lastNo = $rowLN['lastNo'];
		if($numrowLN == 0 || empty($lastNo))
		{
			$nextNumberString = "001";
		}
		else
		{
			$lastNo = $rowLN['lastNo'];
						
			$lastNoNumber = $lastNo;
			$nextNumber = floatval($lastNoNumber) + 1;
						
			if(strlen($nextNumber) == 1)
				$nextNumberString = "00".$nextNumber;
			elseif(strlen($nextNumber) == 2)
				$nextNumberString = "0".$nextNumber;
			else
				$nextNumberString = $nextNumber;
		}
		
		return $nextNumberString;
	}
	
	function GetVoucherNo($type,$voucher_date,$idBank,$nextNumberString) {
		
		//Get Bank Profile
		//$queryTB = "select typeKas,bank,kode from bank where idBank = ".$idBank;
		$queryTB = "select a.idAccount3,a.account4,b.kode
					from account4 a
					left join bankcode b on a.idAccount4 = b.idAccount4
					where a.idAccount4 = ".$idBank;
		$resultTB = mysql_query($queryTB);
		$numrowTB = mysql_num_rows($resultTB);
		$rowTB = mysql_fetch_array($resultTB);
		$idAccount3 = $rowTB['idAccount3'];
		$account4 = $rowTB['account4'];
		$kode = $rowTB['kode'];
		
		if($numrowTB > 0)
		{
			if($idAccount3 == 1)
			{
				if(strtoupper($account4) == "KAS KECIL")
				{
					if($type == "PV")
					{
						$kodeStart = "KK";
					}
					elseif($type == "RV")
					{
						$kodeStart = "KM";
					}
				}
				elseif(strtoupper($account4) == "KAS BESAR")
				{
					if($type == "PV")
					{
						$kodeStart = "KBK";
					}
					elseif($type == "RV")
					{
						$kodeStart = "KBM";
					}
				}
			}
			elseif($idAccount3 == 2)
			{
				if($type == "PV")
				{
					$kodeStart = "BK/".$kode;
				}
				elseif($type == "RV")
				{
					$kodeStart = "BM/".$kode;
				}
			}
			
			$monthYear = substr($voucher_date,5,2)."-".substr($voucher_date,2,2);
			
			$voucher_no = $kodeStart."/".$monthYear."/".$nextNumberString;
		}
		else
		{
			$voucher_no = "00/00-00/000";
		}
				
		return $voucher_no;
	}
	
	function GetTrxLast() {
		//Get Last No
		$queryLN = "SELECT MAX(trxid) as 'lastNo'
					FROM yy_journal
					order by trxid desc";
		$resultLN = mysql_query($queryLN);
		$numrowLN = mysql_num_rows($resultLN);
		$rowLN = mysql_fetch_array($resultLN);
		$lastNo = $rowLN['lastNo'];
		if($numrowLN == 0 || empty($lastNo))
		{
			$nextNumberString = "1";
		}
		else
		{
			$lastNo = $rowLN['lastNo'];
			$nextNumberString = floatval($lastNo) + 1;
		}
		
		return $nextNumberString;
	}
	
	function GetTrxNoJurnal($trxid) {
						
			if(strlen($trxid) == 1)
				$trxno = "0000".$trxid;
			elseif(strlen($trxid) == 2)
				$trxno = "000".$trxid;
			elseif(strlen($trxid) == 3)
				$trxno = "00".$trxid;
			elseif(strlen($trxid) == 4)
				$trxno = "0".$trxid;
			else
				$trxno = $nextNumber;
		
		return $trxno;
	}
	
	function GetJournalTrxLastForBank($trxtype,$journalDT,$coaid) {
		
		$monthYear = substr($journalDT,5,2)."-".substr($journalDT,0,4);
		
		//Get Last No
		$queryLN = "SELECT MAX(bank_urut) as 'lastNo'
					FROM zz_journal
					WHERE trxtype = '".$trxtype."' and DATE_FORMAT(journalDT,'%m-%Y') = '".$monthYear."' and coaid = ".$coaid;
		$resultLN = mysql_query($queryLN);
		$numrowLN = mysql_num_rows($resultLN);
		$rowLN = mysql_fetch_array($resultLN);
		$lastNo = $rowLN['lastNo'];
		if($numrowLN == 0 || empty($lastNo))
		{
			$nextNumberString = "001";
		}
		else
		{
			$lastNo = $rowLN['lastNo'];
						
			$lastNoNumber = $lastNo;
			$nextNumber = floatval($lastNoNumber) + 1;
						
			if(strlen($nextNumber) == 1)
				$nextNumberString = "00".$nextNumber;
			elseif(strlen($nextNumber) == 2)
				$nextNumberString = "0".$nextNumber;
			else
				$nextNumberString = $nextNumber;
		}
		
		return $nextNumberString;
	}
	
	function GetTrxNoForBank($trxtype,$journalDT,$coaid,$nextNumberString) {
		
		//Get Coa Profile
		$queryTB = "select coa_parent,a.coa_name,kode
					from new_coa a
					left join bankcode b on a.idCoa = b.idCoa
					where a.idCoa = ".$coaid;
		$resultTB = mysql_query($queryTB);
		$numrowTB = mysql_num_rows($resultTB);
		$rowTB = mysql_fetch_array($resultTB);
		$coa_parent = $rowTB['coa_parent'];
		$coa_name = $rowTB['coa_name'];
		$kode = $rowTB['kode'];
		
		if($numrowTB > 0)
		{
			if($coa_parent == 1)
			{
				if(strtoupper($coa_name) == "KAS KECIL")
				{
					if($trxtype == "Penerimaan Kas/Bank")
					{
						$kodeStart = "KM";
					}
					elseif($trxtype == "Pengeluaran Kas/Bank")
					{
						$kodeStart = "KK";
					}
				}
				elseif(strtoupper($coa_name) == "KAS BESAR")
				{
					if($trxtype == "Penerimaan Kas/Bank")
					{
						$kodeStart = "KBM";
					}
					elseif($trxtype == "Pengeluaran Kas/Bank")
					{
						$kodeStart = "KBK";
					}
				}
			}
			elseif($coa_parent == 2)
			{
				if($trxtype == "Penerimaan Kas/Bank")
				{
					$kodeStart = "BM/".$kode;
				}
				elseif($trxtype == "Pengeluaran Kas/Bank")
				{
					$kodeStart = "BK/".$kode;
				}
			}
			
			$monthYear = substr($journalDT,5,2)."-".substr($journalDT,2,2);
			
			$trxno = $kodeStart."/".$monthYear."/".$nextNumberString;
		}
		else
		{
			$trxno = "00/00-00/000";
		}
				
		return $trxno;
	}
	
	function GetJournalTrxLastForNonBank($journalDT,$coaid) {
		
		$monthYear = substr($journalDT,5,2)."-".substr($journalDT,0,4);
		
		//Get Last No
		$queryLN = "SELECT MAX(bank_urut) as 'lastNo'
					FROM zz_journal
					WHERE DATE_FORMAT(journalDT,'%m-%Y') = '".$monthYear."' and substr(trxno,1,2) IN ('JM')";
		$resultLN = mysql_query($queryLN);
		$numrowLN = mysql_num_rows($resultLN);
		$rowLN = mysql_fetch_array($resultLN);
		$lastNo = $rowLN['lastNo'];
		if($numrowLN == 0 || empty($lastNo))
		{
			$nextNumberString = "001";
		}
		else
		{
			$lastNo = $rowLN['lastNo'];
						
			$lastNoNumber = $lastNo;
			$nextNumber = floatval($lastNoNumber) + 1;
						
			if(strlen($nextNumber) == 1)
				$nextNumberString = "00".$nextNumber;
			elseif(strlen($nextNumber) == 2)
				$nextNumberString = "0".$nextNumber;
			else
				$nextNumberString = $nextNumber;
		}
		
		return $nextNumberString;
	}
	
	function GetTrxNoForNonBank($journalDT,$coaid,$nextNumberString) {
		
		$kodeStart = "JM";
		
		$monthYear = substr($journalDT,5,2)."-".substr($journalDT,2,2);
			
		$trxno = $kodeStart."/".$monthYear."/".$nextNumberString;
				
		return $trxno;
	}
	
	function CekStatusPostingTrx($journalDT) {
		
		$bln = intval(substr($journalDT,5,2));
		$thn = intval(substr($journalDT,0,4));
		
		//Query to postingtrx
		$queryCP = "select statusPosting from postingtrx where bln = ".$bln." and thn = ".$thn;
		$resultCP = mysql_query($queryCP);
		$numrowCP = mysql_num_rows($resultCP);
		$rowCP = mysql_fetch_array($resultCP);
		
		if($numrowCP > 0)
		{
			$statusPosting = $rowCP['statusPosting'];
		}
		elseif($numrowCP == 0)
		{
			$statusPosting = "Unposting";
		}
		
		return $statusPosting;
	}
	
	function GetCoaCodeBankLevel3($coa_parent) {
		//Get Last No
		$queryLN = "SELECT MAX(SUBSTRING(coa_code,3,1)) as 'lastNo'
					FROM coa
					WHERE coa_parent = '".$coa_parent."'";
		$resultLN = mysql_query($queryLN);
		$numrowLN = mysql_num_rows($resultLN);
		$rowLN = mysql_fetch_array($resultLN);
		if($numrowLN == 0)
		{
			if($coa_parent == "12000000")
			{
				$coa_code = "12100000";
			}
			elseif($coa_parent == "11000000")
			{
				$coa_code = "11100000";
			}
			elseif($coa_parent == "17000000")
			{
				$coa_code = "17100000";
			}
		}
		else
		{
			$lastNo = $rowLN['lastNo'];
					
			$lastNoNumber = $lastNo;
			$nextNumber = floatval($lastNoNumber) + 1;
			
			if($coa_parent == "12000000")
			{
				$coa_code = "12".$nextNumber."00000";
			}
			elseif($coa_parent == "11000000")
			{
				$coa_code = "11".$nextNumber."00000";
			}
			elseif($coa_parent == "17000000")
			{
				$coa_code = "17".$nextNumber."00000";
			}
		}
			
		return $coa_code;
	}
	
	function createJournalBayarIuran($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			if($note_category == "Iuran Pokok")
			{
				$coa_code = "13100000";
			}
			elseif($note_category == "Iuran Wajib")
			{
				$coa_code = "13200000";
			}
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				if($note_category == "Iuran Pokok")
				{
					$coa_code = "41100000";
				}
				elseif($note_category == "Iuran Wajib")
				{
					$coa_code = "41200000";
				}
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalBayarSimpanan($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "16100000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "48100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalBayarBeban($idNote,$voucherid,$voucher_detailid,$idBank,$coa_code_delivered) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			if(substr($coa_code_delivered,0,2) == "55") //Beban Pemasaran
			{
				$coa_code = "22300000";
				$note_detail = "Biaya Pemasaran";
			}
			elseif(substr($coa_code_delivered,0,2) == "56") //Beban Pegawai
			{
				$coa_code = "22400000";
				$note_detail = "Biaya Pegawai";
			}
			elseif(substr($coa_code_delivered,0,2) == "57") //Beban Umum
			{
				$coa_code = "22100000";
				$note_detail = "Biaya Umum";
			}
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid." 
						group by category_detail,note_type";
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				if($category_detail == "Cost Amount")
				{
					$coa_code = $coa_code_delivered;
					$note_detail = "Biaya Beban";
				}
				elseif($category_detail == "PPN")
				{
					$coa_code = "59100000";
					$note_detail = "PPN";
				}
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalBayarAlokasi($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "27100000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "72100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalTerimaAlokasi($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "15200000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "49100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalTarikBayarAlokasi($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "27200000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "72200000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalTerimaTarikAlokasi($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "15300000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "49200000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalPencairanPinjaman($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "26100000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "51100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalPendapatanPokokPinjaman($idNote) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "14100000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "42100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalPendapatanBungaPinjaman($idNote) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "14200000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "43100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalBiayaAdminPinjaman($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "14300000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "44100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalPotonganNettPremi($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "15500000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "45200000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalMarginPremi($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "15400000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'DN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "45100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalPremiPayment($idNote,$voucherid,$voucher_detailid,$idBank) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting','Paid')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "24100000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Get CoA for Bank selected
			$queryCB = "select id from coa where idBank = ".$idBank;
			$resultCB = mysql_query($queryCB);
			$rowCB = mysql_fetch_array($resultCB);
			$coaidvoucher = $rowCB['id'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
						voucherid,voucher_detailid,coaidvoucher)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
						".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "58100000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount,
							voucherid,voucher_detailid,coaidvoucher)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount.",
							".$voucherid.",".$voucher_detailid.",".$coaidvoucher;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function createJournalPremiPaymentVoucher($idNote,$voucherid,$voucher_detailid,$idBank,$userID) {
		//Cleansing Data first
		$queryU = "update zz_journal
					set voucherid = null,
					voucher_detailid = null,
					coaidvoucher = null
					where noteid = ".$idNote;
		$resultU = mysql_query($queryU);
		
		$queryUN = "update nota
					set note_status = 'Paid',
					paymentDT = now(),
					paymentBy = ".$userID."
					where id = ".$idNote;
		$resultUN = mysql_query($queryUN);
				
		//Get CoA for Bank selected
		$queryCB = "select id from coa where idBank = ".$idBank;
		$resultCB = mysql_query($queryCB);
		$rowCB = mysql_fetch_array($resultCB);
		$coaidvoucher = $rowCB['id'];
		
		$queryUV = "update zz_journal
					set voucherid = ".$voucherid.",
					voucher_detailid = ".$voucher_detailid.",
					coaidvoucher = ".$coaidvoucher."
					where noteid = ".$idNote;
					
		$resultUV = mysql_query($queryUV);
	}
	
	function createJournalPembayaranPinjaman($voucherid,$idBank) {
		
		//Get CoA for Bank selected
		$queryCB = "select id from coa where idBank = ".$idBank;
		$resultCB = mysql_query($queryCB);
		$rowCB = mysql_fetch_array($resultCB);
		$coaidvoucher = $rowCB['id'];
		
		set_time_limit(0); 
		$queryUJ = "update zz_journal a,nota b,voucher_detail c,voucher d
					set a.voucherid = ".$voucherid.",
					a.voucher_detailid = c.detailid,
					a.coaidvoucher = ".$coaidvoucher." 
					where a.noteid = b.id
					and c.noteid = b.id
					and d.voucherid = c.voucherid
					and d.voucherid = ".$voucherid;
		$resultUJ = mysql_query($queryUJ);
	}
	
	function createJournalPembayaranKomisi($voucherid,$idBank) {
		
		//Get CoA for Bank selected
		$queryCB = "select id from coa where idBank = ".$idBank;
		$resultCB = mysql_query($queryCB);
		$rowCB = mysql_fetch_array($resultCB);
		$coaidvoucher = $rowCB['id'];
		
		set_time_limit(0); 
		$queryUJ = "update zz_journal a,nota b,voucher_detail c,voucher d
					set a.voucherid = ".$voucherid.",
					a.voucher_detailid = c.detailid,
					a.coaidvoucher = ".$coaidvoucher." 
					where a.noteid = b.id
					and c.noteid = b.id
					and d.voucherid = c.voucherid
					and d.voucherid = ".$voucherid;
		$resultUJ = mysql_query($queryUJ);
	}
	
	function createJournalKomisiBungaPinjaman($idNote) {
		//Cleansing Data first
		$queryDel = "delete from zz_journal
					where noteid = ".$idNote;
		$resultDel = mysql_query($queryDel);
				
		$queryD = "SELECT a.id,a.note_no,a.note_category,a.note_prod_date,a.note_type
					FROM nota a
					WHERE 1 > 0 
					AND id = ".$idNote." and note_status IN ('Posting')";
		$resultD = mysql_query($queryD);
		$numrowD = mysql_num_rows($resultD);
		$rowD = mysql_fetch_array($resultD);
				
		if($numrowD > 0)
		{
			$noteid = $rowD['id'];
			$note_no = $rowD['note_no'];
			$note_category = $rowD['note_category'];
			$note_type = $rowD['note_type'];
			$note_detail = $rowD['note_category'];
			$note_prod_date = $rowD['note_prod_date'];
			
			set_time_limit(0);
			$querySA = "select SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
			$resultSA = mysql_query($querySA);
			//echo $querySA."<br><br>";
			$rowSA = mysql_fetch_array($resultSA);
			$note_amount = $rowSA['note_amount'];
			if(empty($note_amount))
			{
				$note_amount = 0;
			}
			//echo $note_amount."<br>";
						
			if($rowD['note_type'] == "DN")
			{
				$noteType = "Debit";
			}
			elseif($rowD['note_type'] == "CN")
			{
				$noteType = "Credit";
			}
			
			$coa_code = "23300000";
			
			//Get Coa ID
			set_time_limit(0);
			$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
			$resultCD = mysql_query($queryCD);
			$rowCD = mysql_fetch_array($resultCD);
			$coaid = $rowCD['id'];
			$coa_description = $rowCD['coa_description'];
			
			//Insert Data
			set_time_limit(0);
			$queryJI = "insert into zz_journal
						(noteid,journalDT,category,catdetail,coaid,journal_type,amount)
						select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount;
						
			$resultI = mysql_query($queryJI);
			//echo $queryJI."<br><br>";
			
			set_time_limit(0);
			$querySAD = "select category_detail,note_type,SUM(IF(note_type = 'CN',note_amount,note_amount * -1)) AS 'note_amount'
						from nota_detail
						where noteid = ".$noteid;
						
			$resultSAD = mysql_query($querySAD);
			
			while($rowSAD = mysql_fetch_array($resultSAD))
			{
				$category_detail = $rowSAD['category_detail'];
				$note_type = $rowSAD['note_type'];
				$note_amount = $rowSAD['note_amount'];
				
				if($rowSAD['note_type'] == "DN")
				{
					$noteType = "Debit";
				}
				elseif($rowSAD['note_type'] == "CN")
				{
					$noteType = "Credit";
				}
				
				$coa_code = "53300000";
				
				//Get Coa ID
				set_time_limit(0);
				$queryCD = "select id,coa_description from coa where coa_code = '".$coa_code."'";
				$resultCD = mysql_query($queryCD);
				$rowCD = mysql_fetch_array($resultCD);
				$coaid = $rowCD['id'];
				$coa_description = $rowCD['coa_description'];
				
				//Insert Data
				set_time_limit(0);
				$queryJI = "insert into zz_journal
							(noteid,journalDT,category,catdetail,coaid,journal_type,amount)
							select ".$noteid.",'".$note_prod_date."','".$rowD['note_category']."','".$note_detail."',".$coaid.",'".$noteType."',".$note_amount;
							
				$resultI = mysql_query($queryJI);
				//echo $queryJI."<br><br>";
			}
		}
	}
	
	function tanggalIndo($tanggal) {
                //$tanggal : dd/mm/yyyy
                $day = substr($tanggal,0,2);
                $month = substr($tanggal,3,2);
                $year = substr($tanggal,6,4);
                
                if(intval($month) == 1)
                    $monthString = "Januari";
                elseif(intval($month) == 2)
                    $monthString = "Februari";
                elseif(intval($month) == 3)
                    $monthString = "Maret";
                elseif(intval($month) == 4)
                    $monthString = "April";
                elseif(intval($month) == 5)
                    $monthString = "Mei";
                elseif(intval($month) == 6)
                    $monthString = "Juni";
                elseif(intval($month) == 7)
                    $monthString = "Juli";
                elseif(intval($month) == 8)
                    $monthString = "Agustus";
                elseif(intval($month) == 9)
                    $monthString = "September";
                elseif(intval($month) == 10)
                    $monthString = "Oktober";
                elseif(intval($month) == 11)
                    $monthString = "November";
                elseif(intval($month) == 12)
                    $monthString = "Desember";
                    
                $tanggalString = $day." ".$monthString." ".$year;
                return $tanggalString;
	}
?>
        
