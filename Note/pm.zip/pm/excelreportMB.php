<?php
	session_start();
	if(!isset($_SESSION['userID']))
	{
		header("Location:login.php");
	}
	
	include('connect_db.php');
	$date1 = $_GET['date1'];
	$date2 = $_GET['date2'];
	$note = $_GET['note'];
	$idStatus = $_GET['idStatus'];
	$vendor = $_GET['vendor'];
	
	
	// if($idVendorC <> 0)
	// {
	// 	//Get Nama Vendor
	// 	$queryGV = "select vendor from vendor where idVendor = ".$idVendorC;
	// 	$resultGV = mysql_query($queryGV);
	// 	$rowGV = mysql_fetch_array($resultGV);
	// 	$vendorName = $rowGV['vendor'];
	// }
	
	$file_name = "Report_Mapping_".$note."_".$date1."_".$date2;
	
	header("Content-type: application/octet-stream");
	header('Content-Type: plain/text'); 
	header("Content-Disposition: attachment; filename=".$file_name.".xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	
?>
						Print date : <?php echo date("d/m/Y") ?><br>
						<table border="1">
							<tr>
								<th colspan="29"><h2>Data Mapping - <?php echo $note ?></h2></th>
							</tr>
							
						<?php
							$queryD = "select idMapping,date_format(uploadDT,'%d/%m/%Y') as 'uploadDT',date_format(updateDT,'%d/%m/%Y') as 'updateDT',
										statusAsset,type,caseID,mid,tid,tidreplace,
										type,merchant,address,city,vendor,vendorupdate,sn_edc,sn_sam,sn_sim,wr,provider_sim,produk_sam,
										remarks,date_format(datewr,'%d/%m/%Y') as 'datewr',terminaltype,dongle,provider,
										CASE WHEN b.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
										WHEN b.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
										END AS 'sla',
										a.idRC,a.rc,c.username
										from asset_mapping a
										INNER JOIN asset_status b ON a.idStatus = b.idStatus
										inner join asset_login c on a.updateBy = c.userID
										where 1 > 0 ";
										
							if(!empty($date1) && $date1 <> "" && !empty($date2) && $date2 <> "")
							{
								$queryD = $queryD." and uploadDT between '".$date1."' and '".$date2."'";
							}
							
							if(!empty($note) && $note <> "0")
							{
								$queryD = $queryD." and a.note = '".$note."'";
							}
							if(!empty($idStatus) && $idStatus <> "0")
							{
								$queryD = $queryD." and a.idStatus = '".$idStatus."'";
							}
							if(!empty($vendor) && $vendor <> "0")
							{
								$queryD = $queryD." and a.vendor = '".$vendor."'";
							}
							
							$queryD = $queryD." order by sla desc";
							$resultD = mysql_query($queryD);
							$numrowD = mysql_num_rows($resultD);
							$mysql_query = ($queryD) or die(mysql_error());
							//echo $queryD."<br>";
							$no = 1;
						?>
							<tr>
								<th>Case ID</th>
								<th>Open Warehouse Date</th>
								<th>Last Update Date</th>
								<th>Last Update By</th>
								<th>Status</th>
								<th>SLA (Days)</th>
								<th>MID</th>
								<th>TID</th>
							
								<th>TID Replace</th>
								<th>Type</th>
								<th>Merchant Name</th>
								<th>Address</th>
								<th>City</th>
								<th>Vendor</th>
								<th>Vendor Update</th>
								<th>Terminal Type</th>
								<th>Dongle</th>
								<th>Provider</th>
								<th>SN EDC</th>
								<th>SN SAM</th>
								<th>SN SIM</th>
								<th>WR</th>
								<th>Provider SIM Baru</th>
								<th>Produk SAM Baru</th>
								<th>Remarks</th>
								<th>Pending Root Cause</th>
								<th>Upload Date</th>
							</tr>
							<?php
								while($rowLC = mysql_fetch_array($resultD))
								{
								?>
									<tr>
										<td><?php echo "'".$rowLC['caseID'] ?></td>
										<td><?php echo "'".$rowLC['datewr'] ?></td>
										<td><?php echo "'".$rowLC['updateDT'] ?></td>
										<td><?php echo $rowLC['username'] ?></td>
										<td><?php echo $rowLC['statusAsset'] ?></td>
										<td><?php echo $rowLC['sla'] ?></td>
										<td><?php echo $rowLC['mid'] ?></td>
										<td><?php echo $rowLC['tid'] ?></td>
										
										<td><?php echo $rowLC['tidreplace'] ?></td>
										<td><?php echo $rowLC['type'] ?></td>
										<td><?php echo $rowLC['merchant'] ?></td>
										<td><?php echo $rowLC['address'] ?></td>
										<td><?php echo $rowLC['city'] ?></td>
										<td><?php echo $rowLC['vendor'] ?></td>
										<td><?php echo $rowLC['vendorupdate'] ?></td>
										<td><?php echo $rowLC['terminaltype'] ?></td>
										<td><?php echo $rowLC['dongle'] ?></td>
										<td><?php echo $rowLC['provider'] ?></td>
										<td><?php echo "'".$rowLC['sn_edc'] ?></td>
										<td><?php echo "'".$rowLC['sn_sam'] ?></td>
										<td><?php echo "'".$rowLC['sn_sim'] ?></td>
										<td><?php echo $rowLC['wr'] ?></td>
										<td><?php echo $rowLC['provider_sim'] ?></td>
										<td><?php echo $rowLC['produk_sam'] ?></td>
										<td><?php echo $rowLC['remarks'] ?></td>
										<td><?php echo $rowLC['rc'] ?></td>
										<td><?php echo $rowLC['uploadDT'] ?></td>
									</tr>
							<?php
								}
							?>
						</table>