<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.investor.value.length == 0)
		{
			alert('Please input Investor Name');
			document.form_1.investor.focus();
			return false;
		}
		if(document.form_1.interest.value.length == 0 || document.form_1.interest.value == "0")
		{
			alert('Please input Interest Rate of Investor');
			document.form_1.{.focus();
			return false;
		}
		if(!IsNumeric(document.form_1.interest.value))
		{
			alert('Please input Interest Rate of Investor with numeric');
			document.form_1.interest.focus();
			return false;
		}
		if(document.form_1.email.value.length == 0)
		{
			alert('Please input Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
		if(!isValidEmail(document.form_1.email.value))
		{
			alert('Please input valid Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
		
		<div class="basicFrame backgroundGray">	
			<?php
				if(1 > 0)
				{
				?>

					<div class="col100 backgroundWhite padding15">
						<div class="col98 marginAuto marginBottom20 borderBottomColorGrey2 paddingBottom10">
							<div class="floatLeft col50 marginAuto textBold marginTop5 colorBlue2 textUpper paddingBottom5">
								LIST REPORT MEMBERBANK
							</div>
							
							<div class="margine"></div>
						</div>
						
						<table class="content fontSize09">
							<tr>
								<th class="content textCenter"><center>Vendor</center></th>
								<th class="content textCenter"><center>Open Schedule</center></th>
								<th class="content textCenter"><center>Pending Customer</center></th>
								<th class="content textCenter"><center>Pending Vendor</center></th>
								<th class="content textCenter"><center>Cancel</center></th>
								<th class="content textCenter"><center>Close Completed</center></th>
								<!-- <th class="content textCenter"><center>Update Date</center></th> -->
							</tr>
							<?php		
								$queryLV = "select idVendor,vendor from vendor where vendor != 'VISIONET' order by vendor";
								$resultLV = mysql_query($queryLV);
									
							?>
							<?php while ($fetchVendor = mysql_fetch_array($resultLV)) { ?>
							<tr>
								<td class="viewData fontSize085 textCenter">
									<?php echo $fetchVendor['vendor'] ?>
								</td>
								<td class="viewData fontSize085"><center>0</center></td>
								<td class="viewData fontSize085"><center>0</center></td>
								<td class="viewData fontSize085"><center>0</center></td>
								<td class="viewData fontSize085"><center>0</center></td>
								<td class="viewData fontSize085"><center>0</center></td>
							</tr>
						<?php  } ?>
							<?php
						$sql = "SELECT vendor, (select count(*) as 'jml' from asset_mapping where 1 > 0 and vendor = 'VISIONET' and idStatus = 4) as 'open_schedule', (select count(*) as 'jml' from asset_mapping where 1 > 0 and vendor = 'VISIONET' and idStatus = 1) as 'pending_customer', (select count(*) as 'jml' from asset_mapping where 1 > 0 and vendor = 'VISIONET' and idStatus = 11) as 'pending_vendor', (select count(*) as 'jml' from asset_mapping where 1 > 0 and vendor = 'VISIONET' and idStatus = 10) as 'cancel', (select count(*) as 'jml' from asset_mapping where 1 > 0 and vendor = 'VISIONET' and idStatus = 5) as 'close_completed' from vendor where vendor = 'VISIONET'";
						
						$q1 = mysql_query($sql);
						$fetch = mysql_fetch_array($q1);
						?>
							
									<tr>	
										<td class="viewData fontSize085 textCenter">
											<?php echo $fetch['vendor'] ?>
										</td>
										<td class="viewData fontSize085 textRight"><center><?php echo number_format($fetch['open_schedule']) ?></center></td>
										<td class="viewData fontSize085 textRight"><center><?php echo number_format($fetch['pending_customer']) ?></center></td>
										<td class="viewData fontSize085 textRight"><center><?php echo number_format($fetch['pending_vendor']) ?></center></td>
										<td class="viewData fontSize085 textRight"><center><?php echo number_format($fetch['cancel']) ?></center></td>
										<td class="viewData fontSize085 textRight"><center><?php echo number_format($fetch['close_completed']) ?></center></td>
									</tr>
								<?php
								}
							?>
						</table>
					</div>
	
			<div class="margine"></div>
			
		
					
				<?php
						?>
			<div class="margine"></div>
			</div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date3').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date4').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date5').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date6').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
		
	<?php
		include('footer.php');
	?>
	</body>
</html>