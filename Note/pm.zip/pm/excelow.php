<?php
session_start();
if(!isset($_SESSION['userID']))
{
	header("Location:login.php");
}

include('connect_db.php');
$idVendorC = $_GET['idVendorC'];

if($idVendorC <> 0)
{
		//Get Nama Vendor
	$queryGV = "select vendor from vendor where idVendor = ".$idVendorC;
	$resultGV = mysql_query($queryGV);
	$rowGV = mysql_fetch_array($resultGV);
	$vendorName = $rowGV['vendor'];
}

$file_name = "Data_Upload_Belum_Terkunjungi";

header("Content-type: application/octet-stream");
header('Content-Type: plain/text'); 
header("Content-Disposition: attachment; filename=".$file_name.".xls");
header("Pragma: no-cache");
header("Expires: 0");

?>
<table border="1">
	
	<?php
	$queryLC = "select idPm,MID,TID,feature,mrchnt_name,mrchnt_official,mrchnt_addr,LOB,city,region,vendor,
	install_date,edc_status,mrchnt_type,mbr_bank,segment,sn_edc,provider,sim_sno,conn_type,aom,
	sts_kunjungan,tgl_kunjungan,kategori,sub_kategori,remark,pic_nama,pic_tlp,test_trx,tgl_test,
	paper_roll,edc_banklain,bln_pm
	from data_pm a
	INNER JOIN asset_status b ON a.idStatus = b.idStatus
	where 1 > 0 and a.idStatus IN('3')";
	
	if($idVendorC <> 0)
	{
		$queryLC = $queryLC." and vendor = '".$vendorName."'";
	}
	
	$queryLC = $queryLC." order by idPm";
	
	$resultLC = mysql_query($queryLC);
							//echo $queryLC."<br>";
	$totalRoll = 0;
	?>
	<tr>
		<th>ID PM</th>
		<th>MID</th>
		<th>TID</th>
		<th>Merchant Name</th>
		<th>Address</th>
		<th>City</th>
		<th>Vendor</th>
		<th style="background:#FFFF00;">Status Kunjungan</th>
		<th style="background:#FFFF00;">Kategori</th>
		<th style="background:#FFFF00;">Sub Kategori</th>
		<th style="background:#FFFF00;">PIC</th>
		<th style="background:#FFFF00;">Pic Telp</th>
		<th style="background:#FFFF00;">Paper Roll</th>
		<th style="background:#FFFF00;">EDC Bank Lain</th>
		<th style="background:#FFFF00;">Tanggal Kunjungan</th>
		<th style="background:#FFFF00;">Remarks</th>
		</tr>
	<?php
	while($rowLC = mysql_fetch_array($resultLC))
	{
		?>
		<tr>
			<td><?php echo $rowLC['idPm'] ?></td>
			<td><?php echo $rowLC['MID'] ?></td>
			<td><?php echo $rowLC['TID'] ?></td>
			<td><?php echo $rowLC['mrchnt_name'] ?></td>
			<td><?php echo $rowLC['mrchnt_addr'] ?></td>
			<td><?php echo $rowLC['city'] ?></td>
			<td><?php echo $rowLC['vendor'] ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			<td style="background:#FFFF00;"><?php echo "" ?></td>
			</tr>
		<?php
	}
	?>
</table>

