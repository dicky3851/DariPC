<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.investor.value.length == 0)
		{
			alert('Please input Investor Name');
			document.form_1.investor.focus();
			return false;
		}
		if(document.form_1.interest.value.length == 0 || document.form_1.interest.value == "0")
		{
			alert('Please input Interest Rate of Investor');
			document.form_1.{.focus();
			return false;
		}
		if(!IsNumeric(document.form_1.interest.value))
		{
			alert('Please input Interest Rate of Investor with numeric');
			document.form_1.interest.focus();
			return false;
		}
		if(document.form_1.email.value.length == 0)
		{
			alert('Please input Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
		if(!isValidEmail(document.form_1.email.value))
		{
			alert('Please input valid Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
        <?php
            if(isset($_POST['cmdSubmit']))
            {
                $field = $_POST['field'];
				//$date1 = $_POST['date1'];
				//$date2 = $_POST['date2'];
				
				$field = str_replace("'","",$field);
            }
			elseif(!isset($_POST['cmdSubmit']))
            {
                $field = "";
				//$date1 = "";
				//$date2 = "";
            }
        ?>
		
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Overview Last Stock Thermal
			</div>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
				<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
					Search Parameter
				</div>
				
				<div class="col100 marginTop20">
					<form name="form_1" action="datastock.php" method="post" onsubmit="return validate_form1()">
					
						<div class="col15 floatLeft textBold paddingTop5 marginBottom10">Merchant ID/Name</div>
						<div class="col40 floatLeft paddingRight20 fontSize09">
							<input type="text" name="field" class="textinputbasic marginBottom10" placeholder="Input Merchant ID or Name" value="<?php echo $field ?>">
						</div>
						<!--<div class="margine"></div>
						
						<div class="col15 floatLeft textBold paddingTop5 marginBottom10">Transaction Date</div>
						<div class="col15 floatLeft paddingRight20 fontSize09">
							<input type="text" name="date1" id="date1" class="textinputbasic textCenter" value="<?php echo $date1 ?>">
						</div>
						<div class="col15 floatLeft paddingRight20 fontSize09">
							<input type="text" name="date2" id="date2" class="textinputbasic textCenter" value="<?php echo $date2 ?>">
						</div>-->
						<div class="margine10b"></div>
						
						<div class="col15">
							<input type="submit" name="cmdSubmit" value="View Data" class="styleButtonMiddle">
						</div>
						
						<div class="margine2"></div>
					</form>
				</div>
			</div>
			
			<?php
				//if(isset($_POST['cmdSubmit']))
				if(1 > 0)
				{
				?>
					<div class="col100 backgroundWhite padding15">
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Last Stock Thermal Data
						</div>
						
						<?php
							$queryD = "select a.idStock,a.idMerchant,a.mid,b.merchant,
										a.delivery,a.trx,a.tambahan,a.laststock,a.bank
										from thermal_stock a
										left outer join merchant b on a.idMerchant = b.idMerchant
										where 1 > 0";
							
							if(!empty($field) && $field <> "")
							{
								$queryD = $queryD." and (a.mid like '%".$field."%' or b.merchant like '%".$field."%')";
							}
							
							/*if(!empty($date1) && $date1 <> "" && !empty($date2) && $date2 <> "")
							{
								$queryD = $queryD." and trxDT between '".$date1."' and '".$date2."'";
							}*/
					
							$queryD = $queryD." order by idStock";
							$resultD = mysql_query($queryD);
							//echo $queryD."<br>";
							$no = 1;
						?>
					<div style= "max-height:350px; max-width:5000px; overflow-y:scroll" >
						<table class="content fontSize09">
							<tr>
								<th class="content textCenter">MID</th>
								<th class="content textCenter">Merchant</th>
								<th class="content textCenter">Bank</th>
								<th class="content textCenter">Delivery Thermal</th>
								<th class="content textCenter">Additional Thermal</th>
								<th class="content textCenter">Transaction Thermal</th>
								<th class="content textCenter">Last Stock Thermal</th>
							</tr>
							<?php
								while($rowD = mysql_fetch_array($resultD))
								{
									$idStock = $rowD['idStock'];
								?>
								<tr>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['mid'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowD['merchant'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowD['bank'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['delivery'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['tambahan'] ?></td>
									<td class="viewData fontSize085 textRight"><?php echo $rowD['trx'] ?></td>
									<td class="viewData fontSize085 textRight"><?php echo $rowD['laststock'] ?></td>
								</tr>
								<?php
									$no++;
								}
								?>
						</table>
					</div>
				<?php
				}
			?>
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date3').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date4').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date5').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date6').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>