			<?php
				$queryFS = "select idLog,date_format(logDT2,'%d/%m/%Y %H:%i') as 'logDT',b.username,c.status,a.remarks,a.idRC,a.rc,
							sn_sam,sn_sim,provider_sim,produk_sam
							from asset_log a
							inner join asset_login b on a.logBy = b.userID
							inner join asset_status c on c.idStatus = a.idStatus
							where idPm = ".$idPm."
							order by idLog desc";
				$resultFS = mysql_query($queryFS) or die(mysql_error());
				$no = 1;
			?>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
				<div class="col98 marginAuto marginBottom20 borderBottomColorGrey2 paddingBottom10">
					<div class="floatLeft col50 marginAuto textBold marginTop5 colorBlue2 textUpper paddingBottom5">
						Historical Status
					</div>
					
					<!-- <div class="floatRight marginRight20 textRight">
						<img src="images/excel-icon.png" class="imgExport" onclick="window.open('excelmappinglog.php<?php echo "?idPm=".$idPm ?>','_blank')">
					</div> -->
								
					<div class="margine"></div>
				</div>
				
				
				<table class="content">
					<tr>
						<th class="content textCenter fontSize09">No</th>
						<th class="content textCenter fontSize09">Date & Time</th>
						<th class="content textCenter fontSize09">Status</th>
						<th class="content textCenter fontSize09">User</th>
						<th class="content textCenter fontSize09">Remarks</th>
					</tr>
					<?php
						while($rowFS = mysql_fetch_array($resultFS))
						{
							$idLog = $rowFS['idLog'];
						?>
							<tr>
								<td class="viewData fontSize08 col5 textCenter"><?php echo $no ?></td>
								<td class="viewData fontSize08"><?php echo $rowFS['logDT'] ?></td>
								<td class="viewData fontSize08"><?php echo $rowFS['status'] ?></td>
								<td class="viewData fontSize08"><?php echo $rowFS['username'] ?></td>
								<td class="viewData fontSize08"><?php echo $rowFS['remarks'] ?></td>
							</tr>
						<?php
							$no++;
						}
					?>
				</table>
			</div>
			
			<div class="margine"></div>