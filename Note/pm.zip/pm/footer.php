		<div class="footer">
			<div class="container">
				<div class="footer-text">
                    <!-- <h3>KALBIS Institute</h3> -->
                   <p>
                    	&copy; Copyright 2020. All Right Reserved. <br>
                        Develop by Enda_kytaro
                    </p>
                    <!--<p>&#169;2016 </p> -->
				</div>
			</div>
		</div>
		<a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>