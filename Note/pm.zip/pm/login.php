<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Monitoring PM System</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	
	<!--<link rel="Shortcut icon" href="images/logo_url.png">-->
        
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
	<link href="css/style4.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet">

  </head>

  <body>
  
  <?php
	include('connect_db.php');
  ?>

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->

	  <div id="login-page">
	  	<div class="container">
				
            <form class="form-login" action="login_proc.php" method="post">
			    <!-- <h2 class="form-login-heading centered" > -->
                <div class="col100 textCenter"> 
                    <img src="images/logo1.png" class="logoLogin">
                </div>
				<!--<div class="pull-right">
                    <img src="images/accounting_logo.jpg" class="logoLoginString">
                </div>-->
                <div class="margine"></div>
		        <div class="login-wrap">
		            <input type="text" class="form-control" placeholder="Username" name="username" autofocus>
		            <br>
		            <input type="password" class="form-control" name="password" placeholder="Password">
					<br>
                    
					<?php
						if(isset($_GET['flag']))
						{
							$flag = $_GET['flag'];
							if($flag == 'wrong')
							{
                            ?>
                                <label class="checkbox">
                                <div class="alert alert-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
									<strong>Alert!</strong> <br>Wrong Username or Password
                                </div>      				
								</label>
                            <?php
							}
							elseif($flag == 'inactive')
							{
							?>
                            	<label class="checkbox">
								<div class="alert alert-danger alert-dismissable">
									  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
									  <strong>Alert!</strong> Your Username inactive
								</div>      				
								</label>
                            <?php	
							}
                            elseif($flag == 'locked')
							{
							?>
                            	<label class="checkbox">
								<div class="alert alert-danger alert-dismissable">
									  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
									  <strong>Alert!</strong> Username Anda ter-locked
								</div>      				
								</label>
                            <?php	
							}
						}
					?>
					
		            <button class="btn btn-theme btn-block" href="index.php" type="submit" name="cmdLogin"><i class="fa fa-lock"></i>Login</button>
		            <!-- <a href="add_login.php" class="linkLogin1">Tambah User</a>
                    <a href="reset_login.php" class="linkLogin">Lupa Password</a> -->
                    <div class="margine"></div>
		        </div>
            </form>	  	
	  	
	  	</div>
	  </div>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
	
	<!--
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/login-bg.jpg", {speed: 500});
    </script>
	-->

  </body>
</html>
