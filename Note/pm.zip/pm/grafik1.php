<?php
session_start();
if(!isset($_SESSION['userID']))
{
	header("Location:login.php");
}
		
include('connect_db.php');

//if(!isset($_POST['asset_status'])){
//	header("Location:index.php");
//}

$getasset_status = $_POST['asset_status'];
$getdate1 = $_POST['start'];
$getdate2 = $_POST['end'];

$query = "select a.idVendor id , a.vendor from vendor a order by a.urutanGraf";
$resultD = mysql_query($query);
$status = array();
//echo $query."<br>";
while($rowD = mysql_fetch_array($resultD)){
	$status[$rowD['id']] = array($rowD['vendor'], 0);
}

$whereMonth = "";
if ($getdate1 != '' && getdate2 != ''){
	$whereMonth = "and m.uploadDT between '$getdate1' and '$getdate2'";
}
$query = "SELECT  s.idVendor , COUNT(m.vendor) total , MONTH(m.uploadDT) bulan
			FROM vendor s
			LEFT JOIN asset_mapping m ON s.vendor = m.vendor
			WHERE m.uploadDT IS NOT NULL AND statusAsset LIKE '%$getasset_status%' $whereMonth
			GROUP BY s.idVendor , m.uploadDT";
		$resultD = mysql_query($query);
		$resultRow = mysql_num_rows($resultD);
		$data = array();
		// echo $query."<br>";

while($rowD = mysql_fetch_array($resultD)){
	$vendor[$rowD['idVendor']][1] += $rowD['total'];
}
function fnsdata ($val){
		return $val[1];
	};
// echo implode(",", array_map( 'fnsdata', $status ) )
echo json_encode($vendor);


?>