<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.investor.value.length == 0)
		{
			alert('Please input Investor Name');
			document.form_1.investor.focus();
			return false;
		}
		if(document.form_1.interest.value.length == 0 || document.form_1.interest.value == "0")
		{
			alert('Please input Interest Rate of Investor');
			document.form_1.{.focus();
			return false;
		}
		if(!IsNumeric(document.form_1.interest.value))
		{
			alert('Please input Interest Rate of Investor with numeric');
			document.form_1.interest.focus();
			return false;
		}
		if(document.form_1.email.value.length == 0)
		{
			alert('Please input Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
		if(!isValidEmail(document.form_1.email.value))
		{
			alert('Please input valid Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
        <?php
            if(isset($_POST['cmdSubmit']))
            {
				$date1 = $_POST['date1'];
				$date2 = $_POST['date2'];
				$field = $_POST['field'];
            }
			elseif(!isset($_POST['cmdSubmit']))
            {
				$date1 = date('Y')."-".date('m')."-01";
				$date2 = date('Y-m-d');
				$field = "";
            }
        ?>
		
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				REPORT SLA
			</div>
			
			<?php
				if(isset($_POST['cmdUpload']))
				{
					$sukses = 0;
					$gagal = 0;
								
					$data = new Spreadsheet_Excel_Reader($_FILES['fupload']['tmp_name']);
					$baris = $data->rowcount($sheet_index=0);
				
				?>
					<div class="col100 backgroundWhite padding15 marginBottom10">
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Result Process
						</div>
						
						<div class="col100 marginTop20">
						<?php
							for ($i=2; $i<=$baris; $i++)
							{
								$idMapping = $data->val($i,1);
								$sn_edc = $data->val($i,15);
								$sn_sam = $data->val($i,16);
								$sn_sim = $data->val($i,17);
								$provider_sim = $data->val($i,18);
								$produk_sam = $data->val($i,19);
								
								$sn_edc = strtoupper(str_replace("'","",$sn_edc));
								$sn_sam = strtoupper(str_replace("'","",$sn_sam));
								$sn_sim = strtoupper(str_replace("'","",$sn_sim));
								$provider_sim = strtoupper(str_replace("'","",$provider_sim));
								$produk_sam = strtoupper(str_replace("'","",$produk_sam));
								
								//Exce here
								$queryEM = "update asset_mapping
											set sn_edc = '".$sn_edc."',
											sn_sam = '".$sn_sam."',
											sn_sim = '".$sn_sim."',
											provider_sim = '".$provider_sim."',
											produk_sam = '".$produk_sam."',
											updateBy = ".$userID.",
											updateDT = now(),
											idStatus = 8,
											statusAsset = 'Ready to Mapping',
											remarks = 'Sendback to vendor by Upload'
											where idMapping = ".$idMapping;
								$resultEM = mysql_query($queryEM);
								//echo $queryEM."<br>";
								
								if($resultEM)
								{
									$queryUS = "insert into asset_log
												(idMapping,idStatus,remarks,logDT,logDT2,logBy,sn_edc,sn_sam,sn_sim,
												provider_sim,produk_sam)
												select ".$idMapping.",8,'Sendback to vendor by Upload',now(),now(),".$userID.",'".$sn_edc."','".$sn_sam."','".$sn_sim."',
												'".$provider_sim."','".$produk_sam."'";
									$resultUS = mysql_query($queryUS);
									
									if($resultUS)
									{
										$sukses++;
									}
									else
									{
										$gagal++;
									}
								}
								else
								{
									$gagal++;
								}
							}
						?>
							<div class="col100 textBold marginBottom10">Successfully upload <?php echo $sukses ?> data</div>
							<div class="col100 textBold colorRed marginBottom10">Failed upload <?php echo $gagal ?> data</div>
						</div>
					</div>
				<?php
				
				}
			?>
			
						
			
			<?php
				if(1 > 0)
				{
				?>
					<div class="col100 backgroundWhite padding15">
						<div class="col98 marginAuto marginBottom20 borderBottomColorGrey2 paddingBottom10">
							<div class="floatLeft col50 marginAuto textBold marginTop5 colorBlue2 textUpper paddingBottom5">
								Report Status SLA Vendor
							</div>
								<?php
				if(1 > 0)
				{
				?>
				
				<div id="containerMonth" style="position: relative;">
				<div id="container" style="width: 75%;">
					<canvas id="canvas"></canvas>
				</div>
				<style>
				.list-group-item{margin-right:5px}
				</style>
				<div class="list-group" style="position: absolute;right: 185px;top: 34px;width: 70%;margin: 0 auto;height: 40px;display: flex;">
					<?php
					$getvendor = $_GET['vendor'];
					$query = "select * from vendor";
					$resultD = mysql_query($query);
					$aktif = "";
					
					//echo $query."<br>";
					if($getvendor == '0'){
						$getvendor = '';
						$aktif = "active";
					}
					echo "<a href='#' data-link='vendor=0' class='list-submit list-group-item list-group-item-action $aktif'>All Vendor</a>";
					while($rowD = mysql_fetch_array($resultD)){
						$aktif = "";
						// $monthName = date('F', mktime(0, 0, 0, $rowD['bulan'], 10));
						if($getvendor == $rowD['vendor']){
							$aktif = "active";
						}
						echo "<a href='#' data-link='vendor={$rowD['vendor']}' class='list-submit list-group-item list-group-item-action $aktif'>{$rowD['vendor']}</a>";
					}
					?>
				</div>
				<div style="position: absolute;right: 0;width: 20%;top: 0;"><?php
					$getdate1 = $_GET['start'];
					$getdate2 = $_GET['end'];
				?>
					<input type="text" name="date1" id="date1" placeholder="Start Date" style="position: absolute;right: 1096px;;top: 35px;width: 20%;margin: 0 auto;height: 34px;width: 173px; overflow-x:  class="textinputbasic textCenter form-control" value="<?php echo $getdate1 ?>">
					<input type="text" name="date2" id="date2" placeholder="End Date" style="position: absolute;right: 1096px;;top: 72px;width: 20%;margin: 0 auto;height: 34px;width: 173px; overflow-x:  class="textinputbasic textCenter form-control" value="<?php echo $getdate2 ?>">
				</div>
			</div>
			    <div class="margine"></div>
					<script src="js/bootstrap-datepicker.js"></script>
						<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
						<script type="text/javascript">
						$('#date2').datepicker({
									format: "yyyy-mm-dd",
									//endDate: "<?php echo date('d/m/Y') ?>",
									todayBtn: true,
									autoclose: true,
									todayHighlight: true
								});
						$('#date1').datepicker({
									format: "yyyy-mm-dd",
									//endDate: "<?php echo date('d/m/Y') ?>",
									todayBtn: true,
									autoclose: true,
									todayHighlight: true
								});
						$('#date2').change(function(e){
							var str = new Date($('#date1').val());
							var end = new Date($('#date2').val());
							if( Date.parse(str) >= Date.parse(end) ){
								alert('End date must be bigger than start date');
								$('#date2').val('');
								// $('#date2').focus();
							}
						})
						</script>
						<script>		
														const listSubmit = document.querySelectorAll('.list-submit');
							listSubmit.forEach(el => el.addEventListener('click', function(event) {
								event.preventDefault();
								var date1 = document.getElementById('date1').value;
								var date2 = document.getElementById('date2').value;
								var url = window.location.pathname;
								var link = event.target.dataset.link;
								if (date1 != '' && date2 != ''){
									window.location.replace(url + '?' + link + '&start=' + date1 + '&end=' + date2);
								}else{
									window.location.replace(url + '?' + link);
								}
							}));
							<?php
							$query = "select a.idStatus id , a.status from asset_status a order by a.urutanGraf";
							$resultD = mysql_query($query);
							$status = array();
							while($rowD = mysql_fetch_array($resultD)){
								$status[$rowD['id']] = array($rowD['status'], 0);
							}
							//echo $query."<br>";
							?>
							
							var fd = new FormData();
							<?php 
							echo "fd.append('vendor','$getvendor');\n";
							if ($getdate1 != '' && getdate2 != ''){
								echo "fd.append('start', '$getdate1');\n";
								echo "fd.append('end', '$getdate2');\n";
							}
							?>
							// $.post( "grafik.php", fd, function( data ) {
							  // console.log( data ); // John
							  // // console.log( data.time ); // 2pte
							// }, "json");
							var data = [];

							<?php echo "/* $query */\n" ?>
							var MONTHS = [<?php
							// 'done', 'pending', 'on process'
							function fns ($val){
									return $val[0];
								};
							echo "'".implode("', '", array_map( 'fns', $status ) )."'";
							?>];
							var color = Chart.helpers.color;
							var warna = 'rgb(255, 99, 132)';
							var barChartData = {
										labels: MONTHS,
										datasets: [{
											label: 'Label data',
											backgroundColor: color(warna).alpha(0.5).rgbString(),
											borderColor: warna,
											borderWidth: 1,
											data: data
										}]
									};
							var ctx = document.getElementById('canvas').getContext('2d');
							window.myBar = new Chart(ctx, {
											type: 'bar',
											data: barChartData,
											options: {
										scales: {
									yAxes: [{
										ticks: {
											beginAtZero: true
										}
									}]
								},
												responsive: true,
												legend: {
												  position: 'top',
												},
												title: {
													display: true,
													text: 'DASHBOARD MAPPING'
												}
											}
										});

							function getData() {
								$.ajax({
								  url: 'grafik.php',
								  data: fd,
								  processData: false,
								  contentType: false,
								  type: 'POST',
								  success: function(datagraf){
									var index = 0;
									//console.log(datagraf);
									for (const [key, value] of Object.entries(datagraf)) {
										//console.log(`key ${key} value ${value[1]}`);
									  data[index] = value[1];
									  index++;
									}
									//console.log(data);
									window.myBar.update();
								  },
								  dataType: 'json'
								});
							}
							getData();
							setInterval(getData, 60000);
							</script>			
			
			
			
							<div class="floatRight marginRight20 textRight">
								<img src="images/excel-icon.png" class="imgExport" onclick="window.open('excelreport.php<?php echo "?date1=".$date1."&date2=".$date2."&type=Send Back to Vendor&field=".$field."&idVendorC=".$idVendorC ?>','_blank')">
							</div>
							
							<div class="margine"></div>
						</div>
						
						<?php
						$filter = '';
						if ($getvendor != ''){
							$filter = "WHERE vendor = '$getvendor' ";
						}
						if ($getdate1 != '' && $getdate2){
							if ($getvendor != ''){
								$filter .= "AND datewr between '$getdate1' AND '$getdate2'";
							}else{
								$filter = "WHERE datewr between '$getdate1' AND '$getdate2' ";
							}
						}
							$queryD = " SELECT vendor,
										CASE WHEN (CASE WHEN b.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
										WHEN b.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
										END) <= 7 THEN 'Meet SLA'
										ELSE 'Miss SLA'
										END AS 'result',
										COUNT(*) as 'jml'
										FROM asset_mapping a
										INNER JOIN asset_status b ON a.idStatus = b.idStatus
										$filter
										GROUP BY vendor,result
										ORDER BY vendor,result";
							
							
							if($idVendorC <> 0)
							{
								$queryD = $queryD." and vendor = '".$vendorName."'";
							}
							
							
					
							//$queryD = $queryD." order by sla desc";
							$resultD = mysql_query($queryD);
							$numrowD = mysql_num_rows($resultD);
							// echo $queryD."<br>";
							$no = 1;
							
							echo '<div id="numrows" class="colorBlue2" style="float: right;margin-right: 131px;margin-top: -45px;">Show Data '.$numrowD.' data</div>'
						?>
						
						<table class="content fontSize09">
							<tr>
								<th class="content textCenter"><center>Vendor</center></th>
								<th class="content textCenter"><center>Result</center></th>
								<th class="content textCenter"><center>Jumlah</center></th>
							</tr>
							<?php
								while($rowD = mysql_fetch_array($resultD))
								{
									$vendor = $rowD['vendor'];
								?>
								<tr>
									
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['vendor'] ?></td>
									<td class="viewData fontSize085 textCenter"><center><?php echo $rowD['result'] ?></center></td>
									<td class="viewData fontSize085 textCenter"><center><?php echo $rowD['jml'] ?></center></td>
									
								</tr>
								<?php
									$no++;
								}
								?>
						</table>
					</div>
				<?php
				}
			?>
			<div class="margine"></div>
			
		
					<div class="col100 backgroundWhite padding15">
						<div class="col98 marginAuto marginBottom20 borderBottomColorGrey2 paddingBottom10">
							<div class="floatLeft col50 marginAuto textBold marginTop5 colorBlue2 textUpper paddingBottom5">
								Report SLA Per Day  Vendor
							</div>
							
							<div class="floatRight marginRight20 textRight">
								<img src="images/excel-icon.png" class="imgExport" onclick="window.open('excelreport1.php<?php echo "?date1=".$date1."&date2=".$date2."&type=Send Back to Vendor&field=".$field."&idVendorC=".$idVendorC ?>','_blank')">
							</div>
							
							<div class="margine"></div>
						</div>
						
						<?php
							$queryD = "SELECT vendor,statusAsset,
										CASE WHEN b.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
										WHEN b.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
										END AS 'sla',
										CASE WHEN (CASE WHEN b.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
										WHEN b.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
										END) <= 7 THEN 'Meet SLA'
										ELSE 'Miss SLA'
										END AS 'result',
										COUNT(*) as 'jml'
										FROM asset_mapping a
										INNER JOIN asset_status b ON a.idStatus = b.idStatus
										$filter
										GROUP BY vendor,statusAsset,sla,result
										ORDER BY vendor,statusAsset";
							
							
							if($idVendorC <> 0)
							{
								$queryD = $queryD." and vendor = '".$vendorName."'";
							}
							
							
					
							//$queryD = $queryD." order by sla desc";
							$resultD = mysql_query($queryD);
							$numrowD = mysql_num_rows($resultD);
							//echo $queryD."<br>";
							$no = 1;
							
							echo '<div id="numrows" class="colorBlue2" style="float: right;margin-right: 131px;margin-top: -45px;">Show Data '.$numrowD.' data</div>'
						?>
						<div id="form_container" style="max-height: 522px;overflow-y: scroll;">	
						   <table class="content fontSize09">
							<tr>
								<th class="content textCenter"><center>Vendor</center></th>
								<th class="content textCenter"><center>Status</center></th>
								<th class="content textCenter"><center>SLA</center></th>
								<th class="content textCenter"><center>Result</center></th>
								<th class="content textCenter"><center>Jumlah</center></th>
								
							</tr>
							<?php
								while($rowD = mysql_fetch_array($resultD))
								{
									$vendor = $rowD['vendor'];
								?>
								<tr>
									
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['vendor'] ?></td>
									<td class="viewData fontSize085 textCenter"><center><?php echo $rowD['statusAsset'] ?></center></td>
									<td class="viewData fontSize085 textCenter"><center><?php echo $rowD['sla'] ?></center></td>
									<td class="viewData fontSize085 textCenter"><center><?php echo $rowD['result'] ?></center></td>
									<td class="viewData fontSize085 textCenter"><center><?php echo $rowD['jml'] ?></center></td>
									
								</tr>
								<?php
									$no++;
								}
								?>
						</table>
					</div>
				<?php
				}
			?>
			<div class="margine"></div>
			
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date3').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date4').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date5').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date6').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>