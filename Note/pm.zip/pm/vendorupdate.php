<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.mid.value.length == 0 || document.form_1.tid.value.length == 0 || document.form_1.caseID.value.length == 0 || document.form_1.wr.value.length == 0)
		{
			alert('Please insert at least one field data');
			document.form_1.mid.focus();
			return false;
		}
        
        return true;
    }
	
	function validate_form2()
	{	
		if(document.form_2.account2.value.length == 0)
		{
			alert('Mohon Input Account Name');
			document.form_2.account2.focus();
			return false;
		}
        
        return true;
    }
	
	function validate_form3()
	{	
		if(document.form_3.account3.value.length == 0)
		{
			alert('Mohon Input Account Name');
			document.form_3.account3.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Vendor Assignment
			</div>
			
			<div class="col100 backgroundWhite padding20 marginBottom10">
			
			<?php
				if(isset($_POST['cmdAssign']))
				{
					$mid = $_POST["mid"];
					$tid = $_POST["tid"];
					$caseID = $_POST["caseID"];
					$wr = $_POST["wr"];
					
				?>
					<div class="col100 floatLeft padding10 marginRight20 marginBottom20 borderGray">
						<div class="col98 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Result Assignment
						</div>
					<?php
						$queryLD = "select idMapping,mid,tid,merchant,caseID,wr,vendor
									from asset_mapping
									where 1 > 0 
									and (mid like '%".$mid."%' and tid like '%".$tid."%' and caseID like '%".$caseID."%' and wr like '%".$wr."%')
									order by idMapping";
						$resultLD = mysql_query($queryLD);
						$sukses = 0;
						$gagal = 0;
						
						while($rowLD = mysql_fetch_array($resultLD))
						{
							$idMapping = $rowLD['idMapping'];
							$vendor = $_POST['vendor'.$idMapping];
							//echo $vendor."<br>";
							
							$queryEX = "update asset_mapping
										set vendor = '".$vendor."',
										datewr = now()
										where idMapping = ".$idMapping;
							
							$resultEX = mysql_query($queryEX);
							
							if($resultEX)
							{
								$sukses++;
							}
							else
							{
								$gagal++;
							}
						}
					?>
						<div class="col100 textBold marginBottom20">Successfully Assign Vendor : <?php echo $sukses ?> data</div>
						<div class="col100 textBold marginBottom20 colorRed">Failed Assign Vendor : <?php echo $gagal ?> data</div>
					</div>
				<?php
				}
			?>
			
			<?php
				if(isset($_POST['cmdSearch']))
				{
					$mid = $_POST["mid"];
					$tid = $_POST["tid"];
					$caseID = $_POST["caseID"];
					$wr = $_POST["wr"];
					
					$mid = str_replace("'","",$mid);
					$tid = str_replace("'","",$tid);
					$caseID = str_replace("'","",$caseID);
					$wr = str_replace("'","",$wr);
				}
				elseif(!isset($_POST['cmdSearch']))
				{
					$mid = "";
					$tid = "";
					$caseID = "";
					$wr = "";
				}
			?>
				
				<div class="col100 floatLeft padding10 marginRight20 marginBottom20 borderGray">
				
				<?php
					if(1 > 0)
					{
					?>
					
					<?php
				if(isset($_POST['cmdUpload']))
				{
					$sukses = 0;
					$gagal = 0;
								
					$data = new Spreadsheet_Excel_Reader($_FILES['fupload']['tmp_name']);
					$baris = $data->rowcount($sheet_index=0);
				
				?>
					<div class="col100 backgroundWhite padding15 marginBottom10">
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Result Process
						</div>
						
						<div class="col100 marginTop20">
						<?php
							for ($i=2; $i<=$baris; $i++)
							{
								$caseID = $data->val($i,1);
								$mid = $data->val($i,2);
								$tid = $data->val($i,3);
								$vendor = $data->val($i,4);
								$wr = $data->val($i,5);
								
								
								$caseID = strtoupper(str_replace("'","",$caseID));
								$mid = strtoupper(str_replace("'","",$mid));
								$tid = strtoupper(str_replace("'","",$tid));
								$vendor = strtoupper(str_replace("'","",$vendor));
								$wr = strtoupper(str_replace("'","",$wr));
								
								//Exce here
								$queryEM = "update asset_mapping
											set vendor = '".$vendor."',
											datewr = now()
											where wr = '".$wr."' and caseID = '".$caseID."' and 
											mid = '".$mid."' and tid = '".$tid."'";
								$resultEM = mysql_query($queryEM);
								//echo $queryEM."<br>";
								
								if($resultEM)
								{	
									$sukses++;
								}
								else
								{
									$gagal++;
								}
							}
						?>
							<div class="col100 textBold marginBottom10">Successfully upload <?php echo $sukses ?> data</div>
							<div class="col100 textBold colorRed marginBottom10">Failed upload <?php echo $gagal ?> data</div>
						</div>
					</div>
				<?php
				
				}
			?>
					
					
						<div class="col98 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Search Data
						</div>
						
						<div class="col95 marginAuto padding2 borderColorGrey2 marginBottom20">
							<form name="form_1" action="vendorupdate.php" method="post" enctype="multipart/form-data">
								
								<div class="col20 floatLeft marginRight2 marginBottom10 marginTop5">
									<div class="col100 textBold paddingTop5 marginBottom5">M I D</div>
									<div class="col100">
										<input type="text" name="mid" class="textinputbasic marginBottom10" value="<?php echo $mid ?>">
									</div>
								</div>
								
								<div class="col20 floatLeft marginRight2 marginBottom10 marginTop5">
									<div class="col100 textBold paddingTop5 marginBottom5">T I D</div>
									<div class="col100">
										<input type="text" name="tid" class="textinputbasic marginBottom10" value="<?php echo $tid ?>">
									</div>
								</div>
								
								<div class="col20 floatLeft marginRight2 marginBottom10 marginTop5">
									<div class="col100 textBold paddingTop5 marginBottom5">Case ID</div>
									<div class="col100">
										<input type="text" name="caseID" class="textinputbasic marginBottom10" value="<?php echo $caseID ?>">
									</div>
								</div>
								
								<div class="col20 floatLeft marginRight2 marginBottom10 marginTop5">
									<div class="col100 textBold paddingTop5 marginBottom5">WR ID</div>
									<div class="col100">
										<input type="text" name="wr" class="textinputbasic marginBottom10" value="<?php echo $wr ?>">
									</div>
								</div>
								<div class="margine"></div>
								
								<div class="col100 floatLeft marginBottom10 marginTop20">
									<input type="submit" name="cmdSearch" value="Search Data" class="styleButtonMiddle">
								</div>
								<div class="margine"></div>
							</form>
						</div>
						<div class="col98 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Upload Update Vendor
						</div>
						<div class="col95 marginAuto padding2 borderColorGrey2 marginBottom20">
							<form name="form_2" action="vendorupdate.php" method="post" onsubmit="return validate_form2()" enctype="multipart/form-data">
									
								<div class="col20 floatLeft marginRight10 marginBottom10 marginTop5 textBold">Browse File</div>
								<div class="col40 floatLeft marginRight10 marginBottom10">
									<input type="file" name="fupload" class="textinputbasic fontSize09">
								</div>
								<div class="margine"></div>
										
								<div class="col100 floatLeft marginBottom10 marginTop20">
									<input type="submit" name="cmdUpload" value="Upload Data" class="styleButtonMiddle">
								</div>
								<div class="margine"></div>
							</form>
						</div>
						
					<?php
					}
				?>
				</div>
				
				<?php
					if(isset($_POST['cmdSearch']))
					{
					?>
						<div class="col100 floatLeft padding10 marginRight20 marginBottom20 borderGray">
							<div class="col98 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
								Result Search Data
							</div>
							
							<div class="col95 marginAuto padding2 borderColorGrey2 marginBottom20">
							
							<?php
								$queryLD = "select idMapping,mid,tid,merchant,caseID,wr,vendor
											from asset_mapping
											where 1 > 0 
											and (mid like '%".$mid."%' and tid like '%".$tid."%' and caseID like '%".$caseID."%' and wr like '%".$wr."%')
											order by idMapping";
								$resultLD = mysql_query($queryLD);
							?>
								<form name="form_2" action="vendorupdate.php" method="post">
									<input type="hidden" name="mid" value="<?php echo $mid ?>">
									<input type="hidden" name="tid" value="<?php echo $tid ?>">
									<input type="hidden" name="caseID" value="<?php echo $caseID ?>">
									<input type="hidden" name="wr" value="<?php echo $wr ?>">
									<input type="hidden" name="cmdSearch" value="<?php echo $cmdSearch ?>">
									
									<table class="content fontSize09 marginBottom10">
										<tr>
											<th class="content">MID</th>
											<th class="content">TID</th>
											<th class="content">Merchant</th>
											<th class="content">Case ID</th>
											<th class="content">WR ID</th>
											<th class="content">Vendor</th>
										</tr>
										<?php
											while($rowLD = mysql_fetch_array($resultLD))
											{
												$idMapping = $rowLD['idMapping'];
												
												$queryLV = "select idVendor,vendor from vendor
															order by vendor";
												$resultLV = mysql_query($queryLV);
											?>
												<tr>
													<td class="viewData fontSize09"><?php echo $rowLD['mid'] ?></td>
													<td class="viewData fontSize09"><?php echo $rowLD['tid'] ?></td>
													<td class="viewData fontSize09"><?php echo $rowLD['merchant'] ?></td>
													<td class="viewData fontSize09"><?php echo $rowLD['caseID'] ?></td>
													<td class="viewData fontSize09"><?php echo $rowLD['wr'] ?></td>
													<td class="viewData fontSize09">
														<select name="vendor<?php echo $idMapping ?>" class="selectinputbasic paddingTop5 paddingBottom5">
														<?php
															while($rowLV = mysql_fetch_array($resultLV))
															{
															?>
																<option value="<?php echo $rowLV['vendor'] ?>" <?php echo $rowLD['vendor'] == $rowLV['vendor']?"selected":"" ?>><?php echo $rowLV['vendor'] ?></option>
															<?php
															}
														?>
														</select>
													</td>
												</tr>
											<?php
											}
										?>
									</table>
									
									<div class="col100 floatRight textRight marginBottom10 marginTop20 marginRight10">
										<input type="submit" name="cmdAssign" value="Update Vendor Assignment" class="styleButtonMiddle">
									</div>
									<div class="margine"></div>
								</form>
								<div class="col98 marginAuto padding2 borderColorGrey2 marginBottom20">
							
							</div>
								
								
								
							</div>
						</div>
					<?php
					}
				?>
				
				<div class="margine"></div>
			</div>
			
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>