<?php
    include('header.php');
?>

<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
function showItem(str,bln,thn)
{
	if (str=="none")
	{
		document.getElementById("txtHint").innerHTML="";
		return;
	}
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
		}
	}
	xmlhttp.open("GET","getEditCdt.php?idEmployee="+str+"&bulan="+bln+"&tahun="+thn,true);
	xmlhttp.send();
}
</script>

<script>
	function validate_form()
	{
		if(document.form_2.newPassword.value.length == 0)
		{
			alert('Mohon input Password Baru');
			document.form_2.newPassword.focus();
			return false;
		}
		if(document.form_2.newPassword.value.length < 8)
		{
			alert('Mohon input Password Baru dengan minimal 8 karakter');
			document.form_2.newPassword.focus();
			return false;
		}
        if(document.form_2.ConfNewPassword.value.length == 0)
		{
			alert('Mohon input Konfirmasi Password Baru');
			document.form_2.ConfNewPassword.focus();
			return false;
		}
        if(document.form_2.newPassword.value != document.form_2.ConfNewPassword.value)
        {
            alert('Mohon input Password Baru sama dengan Konfirmasi Password Baru');
			document.form_2.ConfNewPassword.focus();
			return false;
        }
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
</script>


<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<!-- <link rel="stylesheet" type="text/css" href="css/buttons.dataTables.css"/> -->

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
        <?php
            if(isset($_POST['cmdSubmit']))
            {
                $newPassword = $_POST['newPassword'];
				
				$password = md5($newPassword);
                
                $queryP = "update asset_login
                            set password = '".$password."'
                            where userID = ".$userID;
                $resultP = mysql_query($queryP);
                
                if($resultP)
                {
                ?>
                    <div class="homeLayerNotif">
                        Change Password successfully completed<br>
                    </div>
                <?php
                }
                else
                    {
                ?>
                    <div class="homeLayerNotifWrong">
                        Change Password failed completed<br>
                    </div>
                <?php
                }
            }
        ?>
        
		<div class="basicFrame">
			<div class="frameHeader">
				<h3>Change Password</h3>
                        
				<div class="margine"></div>
			</div>
			
			<?php
				$queryP = "select username,password
							from asset_login
							where userID = ".$userID;
				$resultP = mysql_query($queryP);
				$rowP = mysql_fetch_array($resultP);
				//echo $queryP."<br>";
				$no = 1;
			?>
			
			<form name="form_2" action="change_password.php" method="post" onsubmit="return validate_form()">
				<table width="100%">
					<tr>
						<td>
							<div class="fontSize09">Password Current</div>
							<input type="password" name="password" class="textinput6" value="<?php echo $rowP['password'] ?>" readonly>
						</td>
						<td>
							<div class="fontSize09">New Password</div>
							<input type="password" name="newPassword" class="textinput6">
						</td>
						<td>
							<div class="fontSize09">Confirm New Password</div>
							<input type="password" name="ConfNewPassword" class="textinput6">
						</td>
						<td>
							<input type="submit" value="Submit Password" name="cmdSubmit" class="styleButton">
						</td>
					</tr>
				</table>
                        
				<div class="margine"></div>
			</form>
            <div class="margine"></div>
        </div>
        
	</div>
	
	
	<?php
		include('footer.php');
	?>
    
    
	</body>
</html>