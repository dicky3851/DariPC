<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.investor.value.length == 0)
		{
			alert('Please input Investor Name');
			document.form_1.investor.focus();
			return false;
		}
		if(document.form_1.interest.value.length == 0 || document.form_1.interest.value == "0")
		{
			alert('Please input Interest Rate of Investor');
			document.form_1.{.focus();
			return false;
		}
		if(!IsNumeric(document.form_1.interest.value))
		{
			alert('Please input Interest Rate of Investor with numeric');
			document.form_1.interest.focus();
			return false;
		}
		if(document.form_1.email.value.length == 0)
		{
			alert('Please input Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
		if(!isValidEmail(document.form_1.email.value))
		{
			alert('Please input valid Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
        <?php
            if(isset($_POST['cmdSubmit']))
            {
				$date1 = $_POST['date1'];
				$date2 = $_POST['date2'];
				$field = $_POST['field'];
            }
			elseif(!isset($_POST['cmdSubmit']))
            {
				$date1 = date('Y')."-".date('m')."-01";
				$date2 = date('Y-m-d');
				$field = "";
            }
        ?>
		
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Send Back to Vendor
			</div>
			
			<?php
				if(isset($_POST['cmdUpload']))
				{
					$sukses = 0;
					$gagal = 0;
								
					$data = new Spreadsheet_Excel_Reader($_FILES['fupload']['tmp_name']);
					$baris = $data->rowcount($sheet_index=0);
				
				?>
					<div class="col100 backgroundWhite padding15 marginBottom10">
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Result Process
						</div>
						
						<div class="col100 marginTop20">
						<?php
							for ($i=2; $i<=$baris; $i++)
							{
								$idMapping = $data->val($i,1);
								$sn_edc = $data->val($i,15);
								$sn_sam = $data->val($i,16);
								$sn_sim = $data->val($i,17);
								$provider_sim = $data->val($i,18);
								$produk_sam = $data->val($i,19);
								
								$sn_edc = strtoupper(str_replace("'","",$sn_edc));
								$sn_sam = strtoupper(str_replace("'","",$sn_sam));
								$sn_sim = strtoupper(str_replace("'","",$sn_sim));
								$provider_sim = strtoupper(str_replace("'","",$provider_sim));
								$produk_sam = strtoupper(str_replace("'","",$produk_sam));
								
								//Exce here
								$queryEM = "update asset_mapping
											set sn_edc = '".$sn_edc."',
											sn_sam = '".$sn_sam."',
											sn_sim = '".$sn_sim."',
											provider_sim = '".$provider_sim."',
											produk_sam = '".$produk_sam."',
											updateBy = ".$userID.",
											updateDT = now(),
											idStatus = 8,
											statusAsset = 'Ready to Mapping',
											remarks = 'Sendback to vendor by Upload'
											where idMapping = ".$idMapping;
								$resultEM = mysql_query($queryEM);
								//echo $queryEM."<br>";
								
								if($resultEM)
								{
									$queryUS = "insert into asset_log
												(idMapping,idStatus,remarks,logDT,logDT2,logBy,sn_edc,sn_sam,sn_sim,
												provider_sim,produk_sam)
												select ".$idMapping.",8,'Sendback to vendor by Upload',now(),now(),".$userID.",'".$sn_edc."','".$sn_sam."','".$sn_sim."',
												'".$provider_sim."','".$produk_sam."'";
									$resultUS = mysql_query($queryUS);
									
									if($resultUS)
									{
										$sukses++;
									}
									else
									{
										$gagal++;
									}
								}
								else
								{
									$gagal++;
								}
							}
						?>
							<div class="col100 textBold marginBottom10">Successfully upload <?php echo $sukses ?> data</div>
							<div class="col100 textBold colorRed marginBottom10">Failed upload <?php echo $gagal ?> data</div>
						</div>
					</div>
				<?php
				
				}
			?>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
				<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
					Inquiry Parameter
				</div>
				
				<div class="col100 marginTop20">
					<form name="form_1" action="sendbackvendor.php" method="post" onsubmit="return validate_form1()">
					
						<div class="col15 floatLeft textBold paddingTop5 marginBottom10">Update Date</div>
						<div class="col15 floatLeft paddingRight20 fontSize09">
							<input type="text" name="date1" id="date1" class="textinputbasic textCenter" value="<?php echo $date1 ?>">
						</div>
						<div class="col15 floatLeft paddingRight20 fontSize09">
							<input type="text" name="date2" id="date2" class="textinputbasic textCenter" value="<?php echo $date2 ?>">
						</div>
						<div class="margine10b"></div>
						
						<div class="col15 floatLeft textBold paddingTop5 marginBottom10">Other Data</div>
						<div class="col40 floatLeft paddingRight20 fontSize09">
							<input type="text" name="field" class="textinputbasic" value="<?php echo $field ?>" placeholder="MID or TID or Case ID or WR ID or Merchant">
						</div>
						<div class="margine10b"></div>
						
						<div class="col15">
							<input type="submit" name="cmdSubmit" value="View Data" class="styleButtonMiddle">
						</div>
						
						<div class="margine2"></div>
					</form>
				</div>
			</div>
			<div class="col100 backgroundWhite padding15 marginBottom10">
				<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
					Upload SendBack To Vendor
				</div>
				
				<div class="col98 marginAuto padding2 borderColorGrey2 marginBottom20">
					<div class="col100 floatLeft textBold linkClick9 colorBlue" onclick="window.open('excelstv.php<?php echo "?idVendorC=".$idVendorC ?>','_blank')">Click disini untuk download excel upload Sendback To Vendor </div>
					
					<div class="margine"></div>
				</div>
				
				<div class="col98 marginAuto padding2 borderColorGrey2 marginBottom20">
					<form name="form_2" action="sendbackvendor.php" method="post" onsubmit="return validate_form2()" enctype="multipart/form-data">
							
						<div class="col20 floatLeft marginRight10 marginBottom10 marginTop5 textBold">Browse File</div>
						<div class="col40 floatLeft marginRight10 marginBottom10">
							<input type="file" name="fupload" class="textinputbasic fontSize09">
						</div>
						<div class="margine"></div>
								
						<div class="col100 floatLeft marginBottom10 marginTop20">
							<input type="submit" name="cmdUpload" value="Upload Data" class="styleButtonMiddle">
						</div>
						<div class="margine"></div>
					</form>
				</div>
			</div>					
			
			<?php
				if(1 > 0)
				{
				?>
					<div class="col100 backgroundWhite padding15">
						<div class="col98 marginAuto marginBottom20 borderBottomColorGrey2 paddingBottom10">
							<div class="floatLeft col50 marginAuto textBold marginTop5 colorBlue2 textUpper paddingBottom5">
								List Data Mapping
							</div>
							
							<div class="floatRight marginRight20 textRight">
								<img src="images/excel-icon.png" class="imgExport" onclick="window.open('excelmapping.php<?php echo "?date1=".$date1."&date2=".$date2."&type=Send Back to Vendor&field=".$field."&idVendorC=".$idVendorC ?>','_blank')">
							</div>
							
							<div class="margine"></div>
						</div>
						
						<?php
							$queryD = "select idMapping,statusAsset,type,caseID,mid,tid,wr,
										date_format(uploadDT,'%d/%m/%Y') as 'uploadDT',
										date_format(updateDT,'%d/%m/%Y') as 'updateDT',
										date_format(datewr,'%d/%m/%Y') as 'datewr',
										merchant,vendor,sn_edc,sn_sam,sn_sim,
										CASE WHEN b.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
										WHEN b.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
										END AS 'sla'
										from asset_mapping a
										INNER JOIN asset_status b ON a.idStatus = b.idStatus
										where 1 > 0 and statusAsset IN ('Send Back to Vendor')";
							
							if(!empty($date1) && $date1 <> "" && !empty($date2) && $date2 <> "")
							{
								$queryD = $queryD." and updateDT between '".$date1."' and '".$date2."'";
							}
							
							if($idVendorC <> 0)
							{
								$queryD = $queryD." and vendor = '".$vendorName."'";
							}
							
							if(!empty($field) || $field <> "")
							{
								$queryD = $queryD." and (mid like '%".$field."%' or tid like '%".$field."%' or caseID like '%".$field."%' or wr like '%".$field."%'
													or merchant like '%".$field."%')";
							}
					
							$queryD = $queryD." order by sla desc";
							$resultD = mysql_query($queryD);
							$numrowD = mysql_num_rows($resultD);
							//echo $queryD."<br>";
							$no = 1;
							
							echo '<div id="numrows" class="colorBlue2" style="float: right;margin-right: 131px;margin-top: -45px;">Show Data '.$numrowD.' data</div>'
						?>
						
						<table class="content fontSize09">
							<tr>
								<th class="content textCenter">MID</th>
								<th class="content textCenter">TID</th>
								<th class="content textCenter">Merchant</th>
								<th class="content textCenter">Upload DT</th>
								<th class="content textCenter">WR Date</th>
								<th class="content textCenter">Last Update</th>
								<th class="content textCenter">Case ID</th>
								<th class="content textCenter">WR ID</th>
								<th class="content textCenter">Vendor</th>
								<th class="content textCenter">Status</th>
								<th class="content textCenter">SLA</th>
							</tr>
							<?php
								while($rowD = mysql_fetch_array($resultD))
								{
									$idMapping = $rowD['idMapping'];
								?>
								<tr>
									<td class="viewData fontSize085 textCenter linkClick colorBlue" onclick="window.open('datadetailsendback.php<?php echo "?idMapping=".$idMapping ?>','_blank')"><?php echo $rowD['mid'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['tid'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowD['merchant'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['uploadDT'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['datewr'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['updateDT'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['caseID'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['wr'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowD['vendor'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['statusAsset'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['sla']." Days" ?></td>
								</tr>
								<?php
									$no++;
								}
								?>
						</table>
					</div>
				<?php
				}
			?>
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date3').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date4').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date5').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date6').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>