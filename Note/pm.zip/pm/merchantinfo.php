						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Merchant Info
						</div>
						<div class="col100 marginTop20 marginBottom2">
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant ID</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mid'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tid'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID BARU</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tidreplace'] ?>
								</div>
							</div>
							<div class="margine"></div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant Name</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['merchant'] ?>
								</div>
							</div>
							
							
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Address</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['address'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">City</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['city'] ?>
								</div>
							</div>
							<div class="margine"></div>
							
						</div>