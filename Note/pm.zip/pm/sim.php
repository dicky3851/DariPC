<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.vendor.value.length == 0)
		{
			alert('Please input Vendor Name');
			document.form_1.vendor.focus();
			return false;
		}
		if(document.form_1.namedetail.value.length == 0)
		{
			alert('Please input Complete Vendor Name');
			document.form_1.namedetail.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Provider SIM Library
			</div>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
			
				<div class="col35 floatLeft marginRight20">
					
					<?php
						if(isset($_POST['cmdSubmit']))
						{
							$sim = $_POST['sim'];
							
							$sim = strtoupper(str_replace("'","",$sim));
						?>
							<div class="col100 borderGray padding10 marginBottom20">
								<div class="col95 marginAuto">
									<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
										Result Process
									</div>
								
								<?php
									//Cek Duplicate
									$queryC = "select idSIM from asset_sim where upper(sim) = '".$sim."'";
									$resultC = mysql_query($queryC);
									$numrowC = mysql_num_rows($resultC);
									
									if($numrowC == 0)
									{
										//Insert here
										$queryI = "insert into asset_sim
													(sim,status)
													select '".$sim."','Active'";
										$resultI = mysql_query($queryI);
										//echo $queryI."<br>";
										if($resultI)
										{
										?>
											<div class="col100 textBold marginBottom10">
												Register Provider SIM successfully completed
											</div>
										<?php
										}
										else
										{
										?>
											<div class="col100 textBold colorRed marginBottom10">
												Register Provider SIM failed completed
											</div>
										<?php
										}
									}
									else
									{
									?>
										<div class="col100 textBold colorRed marginBottom10">
											Duplicate Provider SIM. Please check table list
										</div>
									<?php	
									}
								?>
								</div>
							</div>
						<?php
						}
					?>
					
					<?php
						if(isset($_POST['cmdEdit']))
						{
							$idSIM = $_POST['idSIM'];
							$sim = $_POST['sim'];
							$status = $_POST['status'];
							
							$sim = str_replace("'","",$sim);
						?>
							<div class="col100 borderGray padding10 marginBottom20">
								<div class="col95 marginAuto">
									<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
										Result Process
									</div>
								
								<?php
									//Cek Duplicate
									$queryC = "select idSIM from asset_sim where upper(sim) = '".$sim."' and idSIM <> ".$idSIM;
									$resultC = mysql_query($queryC);
									$numrowC = mysql_num_rows($resultC);
									
									if($numrowC == 0)
									{
										//Insert here
										$queryI = "update asset_sim
													set sim = '".$sim."',
													status = '".$status."'
													where idSIM = ".$idSIM;
										$resultI = mysql_query($queryI);
										//echo $queryI."<br>";
										if($resultI)
										{
										?>
											<div class="col100 textBold marginBottom10">
												Update Provider SIM successfully completed
											</div>
										<?php
										}
										else
										{
										?>
											<div class="col100 textBold colorRed marginBottom10">
												Update Provider SIM failed completed
											</div>
										<?php
										}
									}
									else
									{
									?>
										<div class="col100 textBold colorRed marginBottom10">
											Duplicate Provider SIM. Please check table list
										</div>
									<?php	
									}
								?>
								</div>
							</div>
						<?php
						}
					?>
					
					<?php
						if(isset($_GET['idSIM']))
						{
							$idSIM = $_GET['idSIM'];
							
							$queryP = "select idSIM,sim,status
										from asset_sim where idSIM = ".$idSIM;
							$resultP = mysql_query($queryP);
							$rowP = mysql_fetch_array($resultP);
							//echo $queryP."<br>";
							
							$sim = $rowP['sim'];
							$status = $rowP['status'];
						}
						elseif(!isset($_GET['idSIM']))
						{
							$sim = "";
							$status = "";
						}
					?>
				
					<div class="col100 borderGray padding10">
						<div class="col95 marginAuto">
							<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
								Manage
							</div>
							
							<form name="form_1" action="sim.php" method="post" onsubmit="return validate_form1()">
							<?php
								if(isset($_GET['idSIM']))
								{
								?>
									<input type="hidden" name="idSIM" value="<?php echo $idSIM ?>">
								<?php
								}
							?>
							
								<div class="col100 textBold paddingTop5 marginBottom10">Provider SIM</div>
								<div class="col100">
									<input type="text" name="sim" class="textinputbasic marginBottom20" value="<?php echo $sim ?>">
								</div>
								
							<?php
								if(isset($_GET['idSIM']))
								{
								?>
									<div class="col100 textBold paddingTop5 marginBottom10">Provider SIM Status</div>
									<div class="col100">
										<select name="status" class="selectinputbasic paddingTop5 paddingBottom5 marginBottom20">
											<option value="Active" <?php echo $status == "Active"?"selected":"" ?>>Active</option>
											<option value="Inactive" <?php echo $status == "Inactive"?"selected":"" ?>>Inactive</option>
										</select>
									</div>
								<?php
								}
							?>
							
							<?php
								if(!isset($_GET['idSIM']))
								{
								?>
									<input type="submit" name="cmdSubmit" value="Submit Data" class="styleButtonMiddle">
								<?php
								}
								elseif(isset($_GET['idSIM']))
								{
								?>
									<input type="submit" name="cmdEdit" value="Update Data" class="styleButtonMiddle">
								<?php
								}
							?>
								
							</form>
							
						</div>
					</div>
				</div>
				
				<div class="col60 floatLeft marginRight20 borderGray padding10">
					<div class="col95 marginAuto">
						<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							List Provider SIM
						</div>
						
					<?php
						$queryLD = "select idSIM,sim,status
									from asset_sim
									order by idSIM";
						$resultLD = mysql_query($queryLD);
						$no = 1;
					?>
						<table class="content">
							<tr>
								<th class="content textCenter fontSize09">No</th>
								<th class="content textCenter">Provider SIM</th>
								<th class="content textCenter">Status</th>
							</tr>
							<?php
								while($rowLD = mysql_fetch_array($resultLD))
								{
									$idSIM = $rowLD['idSIM'];
								?>
								<tr class="linkClick" onclick="window.location='sim.php<?php echo "?idSIM=".$idSIM ?>'">
									<td class="viewData fontSize085 col5 textCenter"><?php echo $no ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['sim'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['status'] ?></td>
								</tr>
								<?php
									$no++;
								}
								?>
						</table>
					</div>
				</div>
				
				<div class="margine"></div>
				
			</div>
			
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>