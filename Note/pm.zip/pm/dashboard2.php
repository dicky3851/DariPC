<!doctype html>
<html>

<head>
	<title>Dashboard Mapping Processing</title>
	<script src="src/dist/Chart.min.js"></script>
	<script src="src/utils.js"></script>
	
	<link href="css/style2.css" rel="stylesheet" type="text/css"/>
	<link href="css/style4.css" rel="stylesheet" type="text/css"/>
	
	<meta http-equiv="refresh" content="35">
	
	
	<!--<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>-->
	
	<style>
	canvas {
		-moz-user-select: none;
		-webkit-user-select: none;
		-ms-user-select: none;
	}
	</style>
</head>

<script>
	function validate_form1()
	{	
		if(document.form_1.date1.value.length == 0)
		{
			alert('Plesase input Interval Periode 1');
			document.form_1.date1.focus();
			return false;
		}
		
		if(document.form_1.date2.value.length == 0)
		{
			alert('Plesase input Interval Periode 1');
			document.form_1.date2.focus();
			return false;
		}
		
		if(document.form_1.date3.value.length == 0)
		{
			alert('Plesase input Interval Periode 2');
			document.form_1.date3.focus();
			return false;
		}
		
		if(document.form_1.date4.value.length == 0)
		{
			alert('Plesase input Interval Periode 2');
			document.form_1.date4.focus();
			return false;
		}
        
        return true;
    }

</script>

<?php
	include("connect_db.php");
?>

<body>

<div class="col90 marginAuto paddingTop20">
		<div class="col15 floatLeft">
			<img src ="images/logo3.png" class="imglogo" />
		</div>
		<div class="col90 marginAuto paddingTop20">
		<div class="col100 textCenter marginBottom10 textBold fontSize2 fontFamily13"><center>Dashboard of Vendor Monitoring</center></div>
		</div>
		<!-- <div class="col15 floatLeft border1">
			<img src ="images/logo3.png" class="imglogo border1" />
		</div>-->
		<div class="margine"></div>
		
	
		
		<?php
			$queryLV = "select idvendor,vendor from vendor order by vendor";
			$resultLV = mysql_query($queryLV);
			
			while($rowLV = mysql_fetch_array($resultLV))
			{
				$vendor = $rowLV['vendor'];
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Open Schedule' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$OpenSchedule = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Pending Customer' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$PendingCustomer = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Send Back to Vendor' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$SendBacktoVendor = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Send Back to Asset' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$SendBacktoAsset = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Pending Vendor' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$PendingVendor = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Re-mapping' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$reMapping = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Close Completed' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$CloseCompleted = floatval($rowD['jml']);
				
				$queryD =  "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Close Completed' and vendor = '".$vendor."'
							and updateDT = date_format(now(),'%Y-%m-%d')";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$CloseCompletedToday = floatval($rowD['jml']);
			?>
				<style>
					.mySlidesTop1 {display:none;}
				</style>
				
				<div class="mySlidesTop1 w3-container w3-red">
					<div class="col80 marginAuto backgroundWhite borderColorGrey">
						<div class="col100 textBold marginBottom20 textCenter fontSize2 paddingTop1 paddingBottom1 backgroundBlue3 colorWhite textSpacing5">
							<center><?php echo $vendor ?></center>
						</div>
						<div class="margine"></div>
						
						<div class="col45 marginAuto floatLeft padding20 fontSize13 fontFamily13">
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Open Schedule</div>
								<div class="col35 floatLeft textRight"><?php echo $OpenSchedule ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Send Back to Vendor</div>
								<div class="col35 floatLeft textRight"><?php echo $SendBacktoVendor ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Send Back to Asset</div>
								<div class="col35 floatLeft textRight"><?php echo $SendBacktoAsset ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Pending Customer</div>
								<div class="col35 floatLeft textRight"><?php echo $PendingCustomer ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Pending Vendor</div>
								<div class="col35 floatLeft textRight"><?php echo $PendingVendor ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Re-mapping</div>
								<div class="col35 floatLeft textRight"><?php echo $reMapping ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Close Completed</div>
								<div class="col35 floatLeft textRight"><?php echo $CloseCompleted ?></div>
								
								<div class="margine"></div>
							</div>
						</div>
						
						<div class="col45 marginAuto floatLeft padding20 textCenter">
							<div class="col100 marginBottom10">
								<div class="col100 marginBottom2 fontSize2 textBold colorBlue2 fontFamily13"><center>Today Close Completed
										<div class="margine"></div>
											
											   <?php
													$tanggal= mktime(date("m"),date("d"),date("Y"));
													echo " <b>".date("d-M-Y", $tanggal)."</b> ";
													date_default_timezone_set('Asia/Jakarta');
													$jam=date("H:i:s");
													echo "| <b>". $jam." "."WIB</b>";
													$a = date ("H");
													if (($a>=6) && ($a<=11)){
													}
													?> 
											
								</center></div>
								<?php
									if($CloseCompletedToday == 0)
										$styleColor = "colorRed";
									else
										$styleColor = "colorBlue";
								?>
								
								<div class="col100 fontSize8 textBold fontFamily3 marginBottom20 <?php echo $styleColor ?>"><center><?php echo $CloseCompletedToday ?></center></div>
								
								
							</div>
									
           
						</div>
						
						   
						
						<div class="margine"></div>
						
					</div>
							
					<div class="margine"></div>
				</div>
			<?php
			}
		?>
		
		<div class="margine"></div>
		
	</div>
	
	
				<script>
                    var slideIndex21 = 0;
                    carousel21();

                    function carousel21() {
                        var i;
                        var x = document.getElementsByClassName("mySlidesTop1");
                        for (i = 0; i < x.length; i++) {
                            x[i].style.display = "none"; 
                        }
                        slideIndex21++;
                        if (slideIndex21 > x.length) {slideIndex21 = 1} 
                        x[slideIndex21-1].style.display = "block"; 
                        setTimeout(carousel21, 5000); 
                    }
                </script>
		
	
	<?php
		//$labels = array();
	?>

	
	
	<!--<script>
		var color = Chart.helpers.color;
		var barChartData = {
			labels: ['Periode 1','Periode 2'],
			
			datasets: [{
				label: '#Approved',
				backgroundColor: color(window.chartColors.red).alpha(1).rgbString(),
				borderColor: window.chartColors.red,
				borderWidth: 1,
				data: [
					<?php
						echo $data1a.",".$data2a;
					?>
					]
			}, {
				label: '#Rejected',
				backgroundColor: color(window.chartColors.blue).alpha(1).rgbString(),
				borderColor: window.chartColors.blue,
				borderWidth: 1,
				data: [
					<?php
						echo $data1b.",".$data2b;
					?>
					]
			}]

		};

		var ctx = document.getElementById('canvas2').getContext('2d');
		window.myBar = new Chart(ctx, {
			type: 'bar',
			data: barChartData,
			options: {
				responsive: true,
				legend: {
					position: 'top',
				},
				title: {
					display: false,
					text: 'Chart.js Bar Chart'
				},
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}
			}
		});

	</script>-->
	
	
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
</body>

</html>
