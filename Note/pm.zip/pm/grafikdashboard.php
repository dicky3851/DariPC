<?php
		
include('connect_db.php');

//if(!isset($_POST['vendor'])){
//	header("Location:index.php");
//}

$getvendor = $_POST['vendor'];
$getdate1 = $_POST['start'];
$getdate2 = $_POST['end'];

$query = "select a.urutanGraf id , a.status from asset_status a order by a.urutanGraf";
$resultD = mysql_query($query);
$status = array();
while($rowD = mysql_fetch_array($resultD)){
	$status[$rowD['id']] = array($rowD['status'], 0);
}

$whereMonth = "";
if ($getdate1 != '' && getdate2 != ''){
	$whereMonth = "and m.uploadDT between '$getdate1' and '$getdate2'";
}
$query = "select  s.urutanGraf , count(m.idStatus) total, month(m.uploadDT) bulan
from asset_status s
left join data_pm m on s.idStatus = m.idStatus
where m.uploadDT is not null and vendor like '%$getvendor%' $whereMonth
group by s.idStatus, m.uploadDT";
$resultD = mysql_query($query);
$resultRow = mysql_num_rows($resultD);
$data = array();

while($rowD = mysql_fetch_array($resultD)){
	$status[$rowD['urutanGraf']][1] += $rowD['total'];
}
function fnsdata ($val){
		return $val[1];
	};
// echo implode(",", array_map( 'fnsdata', $status ) )
echo json_encode($status);


?>