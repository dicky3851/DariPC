<?php
    $server = 'localhost';
    
	// For localhost
	//mysql_connect($server,'root','hoshiko06',true,65536);
	//mysql_query('use pm');
	
	//For Hosting
      mysql_connect($server,'opef1643_pm','Hoshiko06');
	  mysql_select_db('opef1643_pm');
?>
