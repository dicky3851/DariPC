<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.investor.value.length == 0)
		{
			alert('Please input Investor Name');
			document.form_1.investor.focus();
			return false;
		}
		if(document.form_1.interest.value.length == 0 || document.form_1.interest.value == "0")
		{
			alert('Please input Interest Rate of Investor');
			document.form_1.{.focus();
			return false;
		}
		if(!IsNumeric(document.form_1.interest.value))
		{
			alert('Please input Interest Rate of Investor with numeric');
			document.form_1.interest.focus();
			return false;
		}
		if(document.form_1.email.value.length == 0)
		{
			alert('Please input Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
		if(!isValidEmail(document.form_1.email.value))
		{
			alert('Please input valid Email Address of Investor');
			document.form_1.email.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
        <?php
            if(isset($_POST['cmdSubmit']))
            {
				$date1 = $_POST['date1'];
				$date2 = $_POST['date2'];
				$note = $_POST['note'];
				$idStatus = $_POST['idStatus'];
				$vendor = $_POST['vendor'];
				
            }
			elseif(!isset($_POST['cmdSubmit']))
            {
				$date1 = date('Y')."-".date('m')."-01";
				$date2 = date('Y-m-d');
				$note = "";
				$idStatus = "";
				$vendor = "";
				
            }
        ?>
		
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				REPORT DAILY
			</div>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
				<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
					Inquiry Daily Memberbank
				</div>
				
				<div class="col200 marginTop10">
					<form name="form_1" action="memberbank.php" method="post" onsubmit="return validate_form1()">
					
						<div class="col15 floatLeft textBold paddingTop5 marginBottom10">Upload Date</div>
						<div class="col15 floatLeft paddingRight20 fontSize09">
							<input type="text" name="date1" id="date1" class="textinputbasic textCenter" value="<?php echo $date1 ?>">
						</div>
						<div class="col15 floatLeft paddingRight20 fontSize09">
							<input type="text" name="date2" id="date2" class="textinputbasic textCenter" value="<?php echo $date2 ?>">
						</div>
							
						<div class="margine10b"></div>
						
						<div class="col15 floatLeft textBold paddingTop5 marginBottom10">Note</div>
						<div class="col40 floatLeft paddingRight20 fontSize09">
							<select name="note" class="textinputbasic textCenter">
								        <option value="0">----All Note----
										<option value="REPLACE BRI">REPLACE BRI</option>
										<option value="REPLACE BTN">REPLACE BTN</option>
										<option value="PART BRI">PART BRI</option>
										<option value="PART BTN">PART BTN</option>
										<option value="NEW AQUISISI BRI">NEW AKUISISI BRI</option>
										<option value="NEW AQUISISI BTN">NEW AKUISISI BTN</option>
							    </select
						 </div>
						 </div>
						<div class="margine10b"></div>
						
						<div class="col15 floatLeft textBold ">Status</div>
						<div class="col40 floatLeft paddingRight20 fontSize09">
							<select name="idStatus" class="textinputbasic textCenter">
									<option value="0">----All Status----
									<option value="3">Open Warehouse</option value>
									<option value="4">Open Schedule</option value>
									<option value="5">Close Completed</option value>
									<option value="6">Send Back to Vendor</option value>
									<option value="7">Send Back to Asset</option value>
									<option value="8">Ready to Mapping</option value>	
									<option value="9">Pending Customer</option value>
									<option value="10">Cancel</option value>
									<option value="11">Pending Vendor</option value>
									<option value="12">Re-mapping</option value>
							
							</select
						 </div>
						 </div>
						<div class="margine10b"></div>
						
												
						<?php
								$queryLS = "select vendor from vendor";
								$resultLS = mysql_query($queryLS);
							?>
							
							<div class="col15 floatLeft textBold paddingTop5 marginBottom10">Vendor</div>
								<div class="col40 floatLeft paddingRight20 fontSize09">
									<select name="vendor" class="textinputbasic textCenter">
										<option value="0">--Select Vendor--</option>
									<?php
										while($rowLS = mysql_fetch_array($resultLS))
										{
										?>
											<option value="<?php echo $rowLS['vendor'] ?>"><?php echo $rowLS['vendor'] ?></option>
										<?php
										}
									?>
									</select>
								</div>
							</div>
						
						<div class="margine10b"></div>
						
						
						<div class="col15 floatLeft">
							<input type="submit" name="cmdSubmit" value="View Data" class="styleButtonMiddle">
						</div>
						
						<div class="margine2"></div>
					</form>
			</div>
	
			
			<?php
				if(1 > 0)
				{
				?>
					<div class="col100 backgroundWhite padding15">
						<div class="col98 marginAuto marginBottom20 borderBottomColorGrey2 paddingBottom10">
							<div class="floatLeft col50 marginAuto textBold marginTop5 colorBlue2 textUpper paddingBottom5">
								List Report MEMBERBANK
							</div>
							
							<div class="floatRight marginRight20 textRight">
								<img src="images/excel-icon.png" class="imgExport" onclick="window.open('excelreportdaily.php<?php echo "?date1=".$date1."&date2=".$date2."&note=".$note."&idStatus=".$idStatus."&vendor=".$vendor ?>','_blank')">
							</div>
							
							<div class="margine"></div>
						</div>
						
						<?php
							$queryD = "select idMapping,statusAsset,type,caseID,mid,tid,note,wr,
										date_format(uploadDT,'%d/%m/%Y') as 'uploadDT',
										date_format(updateDT,'%d/%m/%Y') as 'updateDT',
										date_format(datewr,'%d/%m/%Y') as 'datewr',
										merchant,vendor,sn_edc,sn_sam,sn_sim,
										CASE WHEN b.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
										WHEN b.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
										END AS 'sla'
										from asset_mapping a
										INNER JOIN asset_status b ON a.idStatus = b.idStatus
										where 1 > 0";
							
							if(!empty($date1) && $date1 <> "" && !empty($date2) && $date2 <> "")
							{
								$queryD = $queryD." and uploadDT between '".$date1."' and '".$date2."'";
							}
							
								if(!empty($note) && $note <> "0")
								
								
								{
									$queryD = $queryD." and a.note = in ('REPLACE BRI','REPLACE BTN')";
								}
							if(!empty($idStatus) && $idStatus <> "0")
							{
								$queryD = $queryD." and a.idStatus = '".$idStatus."'";
							}
							if(!empty($vendor) && $vendor <> "0")
							{
								$queryD = $queryD." and a.vendor = '".$vendor."'";
							}
							
					
							$queryD = $queryD." order by sla desc";
							$resultD = mysql_query($queryD);
							$numrowD = mysql_num_rows($resultD);
							$mysql_query = ($queryD) or die(mysql_error());
							//echo $queryD."<br>";
							$no = 1;
							
							echo '<div id="numrows" class="colorBlue2" style="float: right;margin-right: 131px;margin-top: -45px;">Show Data '.$numrowD.' data</div>'
							
						?>
						
						<table class="content fontSize09">
							<tr>
								<th class="content textCenter">MID</th>
								<th class="content textCenter">TID</th>
								<th class="content textCenter">Note</th>
								<th class="content textCenter">Merchant</th>
								<th class="content textCenter">WR Date</th>
								<th class="content textCenter">Last Update</th>
								<th class="content textCenter">Case ID</th>
								<th class="content textCenter">WR ID</th>
								<th class="content textCenter">Vendor</th>
								<th class="content textCenter">Status</th>
								<th class="content textCenter">SLA</th>
							</tr>
							<?php
								while($rowD = mysql_fetch_array($resultD))
								{
									$idMapping = $rowD['idMapping'];
								?>
								<tr>
									<td class="viewData fontSize085 textCenter linkClick colorBlue" onclick="window.open('datadetailall.php<?php echo "?idMapping=".$idMapping ?>','_blank')">
										<?php echo $rowD['mid'] ?>
									</td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['tid'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['note'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowD['merchant'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['datewr'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['updateDT'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['caseID'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['wr'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowD['vendor'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowD['statusAsset'] ?></td>
									<td class="viewData fontSize085 textCenter"><?php echo $rowD['sla']." Days" ?></td>
								</tr>
								<?php
									$no++;
								}
								?>
						</table>
					</div>
				<?php
				}
			?>
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date3').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date4').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date5').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date6').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>