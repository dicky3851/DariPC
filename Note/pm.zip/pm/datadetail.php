<?php
include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
		$('#employeeList')
		.dataTable({					
			"columnDefs": [
			{"orderable":false,"targets":[-1]},
			{"width":"20%","targets":[1,3]}
			],
			"language": {
				"lengthMenu": "Display _MENU_ records",
				"info": "Showing _START_ to _END_ of _TOTAL_ records",
			},
		});
	});
</script>

<script>
	function validate_form1()
	{
		if(document.form_1.sn_edc.value.length == "0")
		{
			alert('Please fullfill Serial Number EDC');
			document.form_1.sn_edc.focus();
			return false;
		}
		if(document.form_1.sn_sam.value.length == "0")
		{
			alert('Please fullfill Serial Number SAM');
			document.form_1.sn_sam.focus();
			return false;
		}
		if(document.form_1.sn_sim.value.length == "0")
		{
			alert('Please fullfill Serial Number SIM');
			document.form_1.sn_sim.focus();
			return false;
		}
		if(document.form_1.provider_sim.value == "0")
		{
			alert('Please select Provider SIM');
			document.form_1.provider_sim.focus();
			return false;
		}
		if(document.form_1.produk_sam.value == "0")
		{
			alert('Please select Product SAM');
			document.form_1.produk_sam.focus();
			return false;
		}
		if(document.form_1.idStatus.value == "0")
		{
			alert('Please select Case Status');
			document.form_1.idStatus.focus();
			return false;
		}
		
		return true;
	}
	
	function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
		validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
		/*strEmail = document.form_1.email.value;*/
		
	   // search email text for regular exp matches
	   if (strEmail.search(validRegExp) == -1) 
	   {
	   	return false;
	   }
	   else
	   { 
	   	return true;
	   } 
	}
</script>

<body>
	<div class="header" id="home">
		
		<?php
		include('menu.php');
		?>
		
	</div>
	<?php
	if(isset($_POST['cmdSubmit']))
	{
		$date1 = $_POST['date1'];
		$date2 = $_POST['date2'];
		$field = $_POST['field'];
	}
	elseif(!isset($_POST['cmdSubmit']))
	{
		$date1 = date('Y')."-".date('m')."-01";
		$date2 = date('Y-m-d');
		$field = "";
	}
	?>
	<?php
	if(isset($_GET['idPm']))
	{
		$idPm = $_GET['idPm'];
	}
	
	if(isset($_POST['idPm']))
	{
		$idPm = $_POST['idPm'];
	}
	?>
	
	<div class="basicFrame backgroundGray">
		<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
			List Data Monitoring PM
		</div>
		<?php
		if(isset($_POST['cmdSubmit']))
		{
			$idPm = $_POST['idPm'];
			$idStatus = $_POST['idStatus'];
			$kategori = $_POST['kategori'];
			$sub_kategori = $_POST['sub_kategori'];
			$pic_nama = $_POST['pic_nama'];
			$pic_tlp = $_POST['pic_tlp'];
			$remark = $_POST['remark'];
			$paper_roll = $_POST['paper_roll'];
			$edc_banklain = $_POST['edc_banklain'];
			$tgl_kunjungan = $_POST['tgl_kunjungan'];
			
			$hp_pic = strtoupper(str_replace("'","",$pic_nama));
			$remarks = str_replace("'","",$remark);
			
			$queryGS = "select status from asset_status where idStatus = '".$idStatus."'";
			$resultGS = mysql_query($queryGS);
					//echo $queryGS."<br>";
			$rowGS = mysql_fetch_array($resultGS);
			$sts_kunjungan = $rowGS['status'];
			?>
			<div class="col100 backgroundWhite padding15 marginBottom10">
				<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
					Result Process
				</div>
				<?php
						//Exce here
				$queryEM = "update data_pm
				set idStatus = '".$idStatus."',
				sts_kunjungan =  '".$sts_kunjungan."',
				kategori = '".$kategori."',
				sub_kategori = '".$sub_kategori."',
				pic_nama = '".$pic_nama."',
				pic_tlp = '".$pic_tlp."',
				remark = '".$remark."',
				paper_roll = '".$paper_roll."',
				edc_banklain = '".$edc_banklain."',
				tgl_kunjungan = '".$tgl_kunjungan."',
				updateDT = now(),
				updateBy = '".$userID."'
				where idPm = ".$idPm;

				$resultEM = mysql_query($queryEM);
						//echo $queryEM."<br>";
				
						if($resultEM)
						{
							$queryLD = "insert into asset_log
										(idPm,idStatus,remarks,logDT,logDT2,logBy)
										select ".$idPm.",".$idStatus.",'".$remark."',now(),now(),".$userID."";
							$resultLD = mysql_query($queryLD);
							//echo $queryLD."<br>";
						}
				
				if($resultEM)
				{
					?>
					<div class="col100 textBold">Update Successfully completed</div>
					<?php
				}
				else
				{
					?>
					<div class="col100 textBold colorRed">Update Data failed completed</div>
					<?php
				}
				?>
			</div>
			<?php
		}
		?>
		<div class="col100 backgroundWhite padding15 marginBottom10">
			<?php
			if(isset($_GET['idPm']) || isset($_POST['idPm']))
			{
				$queryDD = "select idPm,MID,TID,feature,mrchnt_name,mrchnt_official,mrchnt_addr,LOB,city,region,vendor,
				install_date,edc_status,mrchnt_type,mbr_bank,segment,sn_edc,provider,sim_sno,conn_type,aom,
				idStatus,tgl_kunjungan,kategori,sub_kategori,remark,pic_nama,pic_tlp,test_trx,tgl_test,
				paper_roll,edc_banklain,bln_pm,edc_type
				FROM data_pm 
				WHERE idPm";
				$resultDD = mysql_query($queryDD) or die(mysql_error());
				// echo $queryDD."<br>";
				$rowDD = mysql_fetch_array($resultDD);
				$status = $rowDD['status'];
				?>
				<form name="form_1" action="datadetail.php" method="post" onsubmit="return validate_form1()">
					<input type="hidden" name="idPm" value="<?php echo $idPm ?>">
					
					<?php
					include("caseinfo.php");
					?>
					
					
					
					
					<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
						
					</div>
					<div class="col100 marginTop20 marginBottom20">
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Region</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['region'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Vendor </div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['vendor'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Merchant Type </div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['mrchnt_type'] ?>
							</div>
						</div>
						<div class="margine"></div>
					</div>
					<div class="col100 marginTop20 marginBottom20">
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Member Bank</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['mbr_bank'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Edc Type</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['edc_type'] ?>
							</div>
						</div>
							<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Nama PIC</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['pic_nama'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Telp PIC</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['pic_tlp'] ?>
							</div>
						</div>
						
						<div class="margine"></div>
					</div>
			
							
						<div class="margine"></div>
						
						
						<?php
						$queryLS = "select status from asset_status";
						$resultLS = mysql_query($queryLS);
						?>
						
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Info Status
						</div>
						
						<div class="col100 marginTop20 marginBottom20">
							<?php
							if($idStatus == 'Terkunjungi')
							{

							?>
						
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Status Kunjungan</div>
									<input name="idStatus" class="textinputbasic marginBottom20" type="text" value="<?php echo $rowDD['idStatus'];?>" disabled/>
									<input name="idStatus" class="textinputbasic marginBottom20" type="hidden" value="<?php echo $rowDD['idStatus'];?>" disabled/>
								</div>
							</div>
							<?php
							} 
							else if($idStatus != 'Belum Terkunjungi')
							{
								?>
								<div class="col30 floatLeft padding10">
									<div class="col100 textBold marginBottom5">Status Kunjungan</div>
									<div class="col80 marginLeft20 fontSize085">
										<select name="idStatus" class="selectinputbasic paddingBottom5 paddingTop5">
											<option value="0">--- Select Status Kunjungan --</option>
											<option value="3">Belum Terkunjungi</option>
											<option value="5">Terkunjungi</option>
										</select>
									</div>
									<div class="margine"></div>
								</div>
								<?php
							}
								
							?>

							
							<div class="col100 marginTop20 marginBottom20">
								<div class="col30 floatLeft padding10">
									<div class="col100 textBold marginBottom5">Kategori</div>
									<div class="col80 marginLeft20 fontSize085">
										<select name="kategori" class="selectinputbasic paddingBottom5 paddingTop5">
											<option value="0">--- Select Kategori</option>
											<option value="Baik">Baik</option>
											<option value="Problem Teknis">Problem Teknis</option>
											<option value="Problem Non Teknis">Problem Non Teknis</option>
										</select>
									</div>
									<div class="margine"></div>
								</div>
								<div class="col30 floatLeft padding10">
									<div class="col100 textBold marginBottom5">Sub Kategori</div>
									<div class="col80 marginLeft20 fontSize085">
										<select name="sub_kategori" class="selectinputbasic paddingBottom5 paddingTop5">
											<option value="0">--- Select Sub Kategori --</option>
											<option value="Device Problem">Device Problem</option>
											<option value="EDC Disimpan">EDC Disimpan</option>
											<option value="EDC Minta Di Tarik">EDC Minta Di Tarik</option>
											<option value="EDC Sudah Di Tarik">EDC Sudah Di Tarik</option>
											<option value="EDC Tidak Digunakan">EDC Tidak Di Gunakan</option>
											<option value="Jaringan Problem">Jaringan Problem</option>
											<option value="Kondisi EDC Baik">Kondisi EDC Baik</option>
											<option value="Merchant menolak Pengecekan">Merchant menolak Pengecekan</option>
											<option value="Merchant Pindah Lokasi">Merchant Pindah Lokasi </option>
											<option value="Merchant Sedang Renovasi">Merchant Sedang Renovasi </option>
											<option value="Merchant Tutup Permanent">Merchant Tutup Permanent</option>
											<option value="Merchant Tutup Sementara">Merchant Tutup Sementara</option>
										</select>
									</div>
									<div class="margine"></div>
								</div>
								<div class="col100 marginTop20 marginBottom20">
									<div class="col30 floatLeft padding10">
										<div class="col100 textBold marginBottom5">PIC</div>
										<div class="col80 marginLeft20 fontSize085">
											<input type="text" name="pic_nama" class="textinputbasic marginBottom20">
										</div>
									</div>

									<div class="col30 floatLeft padding10">
										<div class="col100 textBold marginBottom5"> Pic Telp</div>
										<div class="col80 marginLeft20 fontSize085">
											<input type="text" name="pic_tlp" class="textinputbasic marginBottom20">
										</div>
										<div class="margine"></div>
									</div>
									<div class="col30 floatLeft padding10">
										<div class="col100 textBold marginBottom5"> Paper Roll</div>
										<div class="col80 marginLeft20 fontSize085">
											<input type="text" name="paper_roll" class="textinputbasic marginBottom20">
										</div>
										<div class="margine"></div>
									</div>
									<div class="col30 floatLeft padding10">
										<div class="col100 textBold marginBottom5"> EDC Bank Lain</div>
										<div class="col80 marginLeft20 fontSize085">
											<input type="text" name="edc_banklain" class="textinputbasic marginBottom20">
										</div>
										<div class="margine"></div>
								</div>
								<div class="col30 floatLeft padding10">
										<div class="col100 textBold marginBottom5"> Tanggal Kunjungan</div>
										<div class="col80 marginLeft20 fontSize085">
											<!-- <input type="date" name="tgl_kunjungan" class="textinputbasic marginBottom10"> -->
											<input type="text" name="tgl_kunjungan" id="date1" class="textinputbasic textCenter" value="<?php echo $date1 ?>"> 
										</div>
										<div class="margine"></div>
									</div>
								<div class="margine"></div>
								
								<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
									Remarks
								</div>
								<div class="col100 marginTop20 marginBottom20">
									<div class="col40 floatLeft padding10">
										<div class="col100 textBold marginBottom5">Remarks</div>
										<div class="col80 marginLeft20 fontSize085">
											<textarea name="remark" class="textareabasic"></textarea>
										</div>
									</div>
									
									<div class="margine"></div>
								</div>
								
								
								<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
									Action
								</div>
								<div class="col100 marginTop20 marginBottom20">
									<div class="col30 floatLeft padding10">
										<input type="submit" name="cmdSubmit" value="Submit Data" class="styleButton">
									</div>
									<div class="margine"></div>
								</div>
								
							</form>
							<?php
						}
						?>
						
					</div>
					
					<div class="margine"></div>
					
					<?php
					include("historical.php");
					?>
					
				</div>
			</div>
			
			<script src="js/chosen.jquery.min.js"></script>
			<script src="js/bootstrap-datepicker.js"></script>
			<link rel="stylesheet" href="css/chosen.css" />
			<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
			
			<script type="text/javascript">
				$('.chosen-select').chosen({allow_single_deselect:true});
				$('#date1').datepicker({
					format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
				$('#date2').datepicker({
					format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
				$('#date3').datepicker({
					format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
				$('#date4').datepicker({
					format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
				$('#date5').datepicker({
					format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
				$('#date6').datepicker({
					format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	</script>
	
	
	<?php
	include('footer.php');
	?>
</body>
</html>