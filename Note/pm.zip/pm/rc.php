<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.vendor.value.length == 0)
		{
			alert('Please input Vendor Name');
			document.form_1.vendor.focus();
			return false;
		}
		if(document.form_1.namedetail.value.length == 0)
		{
			alert('Please input Complete Vendor Name');
			document.form_1.namedetail.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Root Cause Management
			</div>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
			
				<div class="col35 floatLeft marginRight20">
					
					<?php
						if(isset($_POST['cmdSubmit']))
						{
							$idStatus = $_POST['idStatus'];
							$rc = $_POST['rc'];
							
							$rc = str_replace("'","",$rc);
						?>
							<div class="col100 borderGray padding10 marginBottom20">
								<div class="col95 marginAuto">
									<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
										Result Process
									</div>
								
								<?php
									//Cek Duplicate
									$queryC = "select idRC from asset_rc where upper(rc) = '".$rc."' and idStatus = ".$idStatus;
									$resultC = mysql_query($queryC);
									$numrowC = mysql_num_rows($resultC);
									
									if($numrowC == 0)
									{
										//Insert here
										$queryI = "insert into asset_rc
													(idStatus,rc,statusRC)
													select ".$idStatus.",'".$rc."','Active'";
										$resultI = mysql_query($queryI);
										//echo $queryI."<br>";
										if($resultI)
										{
										?>
											<div class="col100 textBold marginBottom10">
												Register Root Cause successfully completed
											</div>
										<?php
										}
										else
										{
										?>
											<div class="col100 textBold colorRed marginBottom10">
												Register Root Cause failed completed
											</div>
										<?php
										}
									}
									else
									{
									?>
										<div class="col100 textBold colorRed marginBottom10">
											Duplicate Root Cause Data. Please check table list
										</div>
									<?php	
									}
								?>
								</div>
							</div>
						<?php
						}
					?>
					
					<?php
						if(isset($_POST['cmdEdit']))
						{
							$idRC = $_POST['idRC'];
							$idStatus = $_POST['idStatus'];
							$rc = $_POST['rc'];
							$statusRC = $_POST['statusRC'];
							
							$rc = str_replace("'","",$rc);
						?>
							<div class="col100 borderGray padding10 marginBottom20">
								<div class="col95 marginAuto">
									<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
										Result Process
									</div>
								
								<?php
									//Cek Duplicate
									$queryC = "select idRC from asset_rc where upper(rc) = '".$rc."' and idStatus = ".$idStatus." and idRC <> ".$idRC;
									$resultC = mysql_query($queryC);
									$numrowC = mysql_num_rows($resultC);
									
									if($numrowC == 0)
									{
										//Insert here
										$queryI = "update asset_rc
													set idStatus = ".$idStatus.",
													rc = '".$rc."',
													statusRC = '".$statusRC."'
													where idRC = ".$idRC;
										$resultI = mysql_query($queryI);
										//echo $queryI."<br>";
										if($resultI)
										{
										?>
											<div class="col100 textBold marginBottom10">
												Update Root Cause successfully completed
											</div>
										<?php
										}
										else
										{
										?>
											<div class="col100 textBold colorRed marginBottom10">
												Update Root Cause failed completed
											</div>
										<?php
										}
									}
									else
									{
									?>
										<div class="col100 textBold colorRed marginBottom10">
											Duplicate Root Cause Data. Please check table list
										</div>
									<?php	
									}
								?>
								</div>
							</div>
						<?php
						}
					?>
					
					<?php
						if(isset($_GET['idRC']))
						{
							$idRC = $_GET['idRC'];
							
							$queryP = "select idStatus,rc,statusRC
										from asset_rc where idRC = ".$idRC;
							$resultP = mysql_query($queryP);
							$rowP = mysql_fetch_array($resultP);
							//echo $queryP."<br>";
							
							$idStatus = $rowP['idStatus'];
							$rc = $rowP['rc'];
							$statusRC = $rowP['statusRC'];
						}
						elseif(!isset($_GET['idRC']))
						{
							$idStatus = 0;
							$rc = "";
							$statusRC = "";
						}
					?>
				
					<div class="col100 borderGray padding10">
						<div class="col95 marginAuto">
							<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
								Manage
							</div>
							
							<form name="form_1" action="rc.php" method="post" onsubmit="return validate_form1()">
							<?php
								if(isset($_GET['idRC']))
								{
								?>
									<input type="hidden" name="idRC" value="<?php echo $idRC ?>">
								<?php
								}
							?>
							
							<?php
								$queryLS = "select idStatus,status from asset_status where idStatus IN (9,11)";
								$resultLS = mysql_query($queryLS);
							?>
								<div class="col100 textBold paddingTop5 marginBottom10">Case Status</div>
								<div class="col100">
									<select name="idStatus" class="selectinputbasic paddingTop5 paddingBottom5 marginBottom20">
									<?php
										while($rowLS = mysql_fetch_array($resultLS))
										{
										?>
											<option value="<?php echo $rowLS['idStatus'] ?>" <?php echo $idStatus == $rowLS['idStatus']?"selected":"" ?>><?php echo $rowLS['status'] ?></option>
										<?php
										}
									?>
									</select>
								</div>
								
								<div class="col100 textBold paddingTop5 marginBottom10">Root Casue</div>
								<div class="col100">
									<input type="text" name="rc" class="textinputbasic marginBottom20" value="<?php echo $rc ?>">
								</div>
								
							<?php
								if(isset($_GET['idRC']))
								{
								?>
									<div class="col100 textBold paddingTop5 marginBottom10">Root Cause Status</div>
									<div class="col100">
										<select name="statusRC" class="selectinputbasic paddingTop5 paddingBottom5 marginBottom20">
											<option value="Active" <?php echo $statusRC == "Active"?"selected":"" ?>>Active</option>
											<option value="Inactive" <?php echo $statusRC == "Inactive"?"selected":"" ?>>Inactive</option>
										</select>
									</div>
								<?php
								}
							?>
							
							<?php
								if(!isset($_GET['idRC']))
								{
								?>
									<input type="submit" name="cmdSubmit" value="Submit Data" class="styleButtonMiddle">
								<?php
								}
								elseif(isset($_GET['idRC']))
								{
								?>
									<input type="submit" name="cmdEdit" value="Update Data" class="styleButtonMiddle">
								<?php
								}
							?>
								
							</form>
							
						</div>
					</div>
				</div>
				
				<div class="col60 floatLeft marginRight20 borderGray padding10">
					<div class="col95 marginAuto">
						<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							List Root Cause
						</div>
						
					<?php
						$queryLD = "select idRC,rc,a.idStatus,b.status,a.statusRC
									from asset_rc a
									inner join asset_status b on a.idStatus = b.idStatus
									order by idRC";
						$resultLD = mysql_query($queryLD);
						$no = 1;
					?>
						<table class="content">
							<tr>
								<th class="content textCenter fontSize09">No</th>
								<th class="content textCenter">Status</th>
								<th class="content textCenter">Root Cause</th>
								<th class="content textCenter">Status</th>
							</tr>
							<?php
								while($rowLD = mysql_fetch_array($resultLD))
								{
									$idRC = $rowLD['idRC'];
								?>
								<tr class="linkClick" onclick="window.location='rc.php<?php echo "?idRC=".$idRC ?>'">
									<td class="viewData fontSize085 col5 textCenter"><?php echo $no ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['status'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['rc'] ?></td>
									<td class="viewData fontSize085"><?php echo $rowLD['statusRC'] ?></td>
								</tr>
								<?php
									$no++;
								}
								?>
						</table>
					</div>
				</div>
				
				<div class="margine"></div>
				
			</div>
			
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>