<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.coa_name.value.length == 0)
		{
			alert('Mohon Input Account Name');
			document.form_1.coa_name.focus();
			return false;
		}
		
		if(document.form_1.coa_code.value.length == 0)
		{
			alert('Mohon Input Account Code');
			document.form_1.coa_code.focus();
			return false;
		}
        
        return true;
    }
	
	function validate_form2()
	{	
		if(document.form_2.account2.value.length == 0)
		{
			alert('Mohon Input Account Name');
			document.form_2.account2.focus();
			return false;
		}
        
        return true;
    }
	
	function validate_form3()
	{	
		if(document.form_3.account3.value.length == 0)
		{
			alert('Mohon Input Account Name');
			document.form_3.account3.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
        
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Upload Data Monitoring PM
			</div>
			
			<div class="col100 backgroundWhite padding20 marginBottom10">
			
			<?php
				if(isset($_POST['cmdUpload']))
				{
					$bln_pm = $_POST["bln_pm"];

					//echo $_POST["bln_pm"];
					//$date = $_POST["date"];
													
					$sukses = 0;
					$gagal = 0;
								
					$data = new Spreadsheet_Excel_Reader($_FILES['fupload']['tmp_name']);
					$baris = $data->rowcount($sheet_index=0);
								
					$indexRow = 1;
					$countError = 0;
					$messageError = "";
								
				?>
					<div class="col100 floatLeft padding10 marginRight20 marginBottom20 borderGray">
						<div class="col98 marginAuto">
							<div class="col100 textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
								Result Process
							</div>
							
							<?php
								$flagAllow = 1;
							
								for ($i=2; $i<=$baris; $i++)
								{
									$MID = $data->val($i,1);
									$TID = $data->val($i,2);
									$feature = $data->val($i,3);
									$mrchnt_name = $data->val($i,4);
									$mrchnt_official = $data->val($i,5);
									$mrchnt_addr = $data->val($i,6);
									$LOB = $data->val($i,7);
									$city = $data->val($i,8);
									$region = $data->val($i,9);
									$vendor = $data->val($i,10);
									$install_date = $data->val($i,11);
									$edc_status = $data->val($i,12);
									$mrchnt_type = $data->val($i,13);
									$mbr_bank = $data->val($i,14);
									$segment = $data->val($i,15);
									$edc_type = $data->val($i,16);
									$sn_edc = $data->val($i,17);
									$provider = $data->val($i,18);
									$sim_sno = $data->val($i,19);
									$conn_type = $data->val($i,20);
									$AOM = $data->val($i,21);
									$sts_kunjungan = $data->val($i,22);
									$tgl_kunjungan = $data->val($i,23);
									$kategori = $data->val($i,24);
									$sub_kategori = $data->val($i,25);
									$remark = $data->val($i,26);
									$pic_nama = $data->val($i,27);
									$pic_tlp = $data->val($i,28);
									$tes_trx = $data->val($i,29);
									$tgl_test = $data->val($i,30);
									$paper_roll = $data->val($i,31);
									$edc_banklain = $data->val($i,32);
									//$bln_pm = $data->val($i,33);
									$type = $data->val($i,34);

									
									$MID = strtoupper(str_replace("'","",$MID));
									$TID = strtoupper(str_replace("'","",$TID));
									$feature = strtoupper(str_replace("'","",$feature));
									$mrchnt_name = strtoupper(str_replace("'","",$mrchnt_name));
									$mrchnt_official = strtoupper(str_replace("'","",$mrchnt_official));
									$mrchnt_addr = strtoupper(str_replace("'","",$mrchnt_addr));
									$LOB = strtoupper(str_replace("'","",$LOB));
									$city = strtoupper(str_replace("'","",$city));
									$region = strtoupper(str_replace("'","",$region));
									$vendor = strtoupper(str_replace("'","",$vendor));
									$install_date = strtoupper(str_replace("'","",$install_date));
									$edc_status = strtoupper(str_replace("'","",$edc_status));
									$mrchnt_type = strtoupper(str_replace("'","",$mrchnt_type));
									$mbr_bank = strtoupper(str_replace("'","",$mbr_bank));
									$segment = strtoupper(str_replace("'","",$segment));
									$edc_type = strtoupper(str_replace("'","",$edc_type));
									$sn_edc = strtoupper(str_replace("'","",$sn_edc));
									$provider = strtoupper(str_replace("'","",$provider));
									$sim_sno = strtoupper(str_replace("'","",$sim_sno));
									$conn_type = strtoupper(str_replace("'","",$conn_type));
									$AOM = strtoupper(str_replace("'","",$AOM));
									$sts_kunjungan = strtoupper(str_replace("'","",$sts_kunjungan));
									$tgl_kunjungan = strtoupper(str_replace("'","",$tgl_kunjungan));
									$kategori = strtoupper(str_replace("'","",$kategori));
									$sub_kategori = strtoupper(str_replace("'","",$sub_kategori));
									$remark = strtoupper(str_replace("'","",$remark));
									$pic_nama = strtoupper(str_replace("'","",$pic_nama));
									$pic_tlp = strtoupper(str_replace("'","",$pic_tlp));
									$test_trx = strtoupper(str_replace("'","",$test_trx));
									$tgl_test = strtoupper(str_replace("'","",$tgl_test));
									$paper_roll = strtoupper(str_replace("'","",$paper_roll));
									$edc_banklain = strtoupper(str_replace("'","",$edc_banklain));
									//$bln_pm = strtoupper(str_replace("'","",$bln_pm));
									$type = strtoupper(str_replace("'","",$type));

									
									// Check Duplication
									// if($type == "Project" || $type == "Non Project")
									// {
									// 	//Check kd_cabang
									// 	if(!empty($kd_cabang) || $kd_cabang <> "")
									// 	{
									// 		//Check Duplication
									// 		if($type == "Project")
									// 		{
									// 			$queryCD = "select idPm
									// 					from asset_mapping
									// 					where kd_cabang = '".$kd_cabang."' and tid = '".$tid."' and type in ('Project','Non Project')";
									// 			 //echo $queryCD."<br>";				
									// 		}
									// 		elseif($type == "Non Project")
									// 		{
									// 			$queryCD = "select idPm
									// 					from asset_mapping
									// 					where kd_cabang = '".$kd_cabang."' and type in ('Project','Non Project')";
									// 			 //echo $queryCD."<br>";				
									// 		}
											
											
									// 		$resultCD = mysql_query($queryCD);
									// 		$numrowCD = mysql_num_rows($resultCD);
											
									// 		if($numrowCD == 0)
									// 		{
									// 			$flagAllow = 1;
									// 		}
									// 		else
									// 		{
									// 			$flagAllow = 0;
									// 			$gagal++;
									// 			$messageError = $messageError."Failed Process on Row ".$indexRow." : Duplicate CaseID |";
									// 		}
									// 	}
									// 	else
									// 	{
									// 		$flagAllow = 0;
									// 		$gagal++;
									// 		$messageError = $messageError."Failed Process on Row ".$indexRow." : CaseID is blank |";
									// 	}
									// }
									// else
									// {
									// 	//Check Date WR
									// 	if(!empty($wr) || $wr <> "")
									// 	{
									// 		//Check Duplication
									// 		$queryCD = "select idPm
									// 					from asset_mapping
									// 					where wr = '".$wr."' and tid = '".$tid."' and type in ('New Mandiri','New Others')";
									// 		 //echo $queryCD."<br>";			
									// 		$resultCD = mysql_query($queryCD);
									// 		$numrowCD = mysql_num_rows($resultCD);
											
									// 		if($numrowCD == 0)
									// 		{
									// 			$flagAllow = 1;
									// 		}
									// 		else
									// 		{
									// 			$flagAllow = 0;
									// 			$gagal++;
									// 			$messageError = $messageError."Failed Process on Row ".$indexRow." : Duplicate Work Request ID |";
									// 		}
									// 	}
									// 	else
									// 	{
									// 		$flagAllow = 0;
									// 		$gagal++;
									// 		$messageError = $messageError."Failed Process on Row ".$indexRow." : Work request ID is blank |";
									// 	}
									// }
									
									if($flagAllow == 1)
									{
										//update table merchant
										$queryCM = "select idVendor from vendor where upper(vendor) = '".$vendor."'";
										$resultCM = mysql_query($queryCM);
										$numrowCM = mysql_num_rows($resultCM);
										// echo $queryCM."<br>";
													
										if($numrowCM == 0)
										{
											$queryIM = "insert into vendor
														(vendor,tidnamedetail)
														select '".$vendor."','".$vendor."'";
																		
											$resultIM = mysql_query($queryIM);
										}
													
										//Insert data
										$queryID = "insert into data_pm (uploadDT,UploadBy,MID,TID,idStatus,feature,mrchnt_name,mrchnt_official,mrchnt_addr,LOB,city,region,
										vendor,install_date,edc_status,mrchnt_type,mbr_bank,segment,edc_type,sn_edc,provider,sim_sno,conn_type,AOM,sts_kunjungan,
										tgl_kunjungan,kategori,sub_kategori,remark,pic_nama,pic_tlp,test_trx,tgl_test,paper_roll,edc_banklain,bln_pm,updateDT)
										select now(),'".$userID."','".$MID."','".$TID."',3,'".$feature."','".$mrchnt_name."','".$mrchnt_official."','".$mrchnt_addr."','".$LOB."','".$city."',
										'".$region."','".$vendor."','".$install_date."','".$edc_status."','".$mrchnt_type."','".$mbr_bank."','".$segment."','".$edc_type."','".$sn_edc."',
										'".$provider."','".$sim_sno."','".$conn_type."','".$AOM."','Belum Terkunjungi','".$tgl_kunjungan."','".$kategori."','".$sub_kategori."','".$remark."',
										'".$pic_nama."','".$pic_tlp."','".$test_trx."','".$tgl_test."','".$paper_roll."','".$edc_banklain."','".$_POST["bln_pm"]."',now()";

										//echo $queryID."<br>";
										$resultID = mysql_query($queryID) or die(mysql_error());
													
										$idPm = mysql_insert_id();
													
										if($resultID)
										{
											$queryLD = "insert into asset_log
														(idPm,idStatus,remarks,logDT,logDT2,logBy,sn_edc,sn_sam,sn_sim,
														provider_sim,produk_sam)
														select ".$idPm.",3,'Upload Data',now(),now(),".$userID.",'".$sn_edc."','".$sn_sam."','".$sn_sim."',
														'".$provider_sim."','".$produk_sam."'";
											$resultLD = mysql_query($queryLD);
										}
											
										// $queryGS = "select idStatus,type from asset_mapping where idPm = '".$idPm."'";
										// $resultGS = mysql_query($queryGS);
										// //echo $queryGS."<br>";
										// $rowGS = mysql_fetch_array($resultGS);
										// $idStatus = $rowGS['idStatus'];
																				
										// if($idStatus == 3){
										// 	if($username == "BNI" || $username =="bni"){
										// 		$idStatus = 11;
										// 	}else{
										// 		$idStatus = 10;
										// 	}
										// }else{
										// 	$idStatus = 8;
										// }
										
										// if($username == "BRI" || $username =="bri"){
										// 	$type = ($type == '')?$rowGS['type']:$type;
										
										// }else{
										// 	$type = ($type == '')?$rowGS['type']:$type;
										// }

										// $queryGS = "select status from asset_status where idStatus = '".$idStatus."'";
										
										
										// $resultGS = mysql_query($queryGS);
										// //echo $queryGS."<br>";
										// $rowGS = mysql_fetch_array($resultGS);
										// $statusAsset = $rowGS['status'];
												
										if($resultID)
										{
											$sukses++;
										}
										else
										{
											$gagal++;
											$messageError = $messageError."Failed Process on Row ".$indexRow." |";
										}
									}
									
									$indexRow++;
								}
							?>
							<div class="col100 textBold marginBottom20">Successfully upload Data : <?php echo $sukses ?> data</div>
							<div class="col100 textBold marginBottom20 colorRed">Failed upload Data : <?php echo $gagal ?> data</div>
							
							
						<?php
							$stringError = explode("|",$messageError);
							foreach($stringError as $echoError)
							{
							?>
								<div class="colorRed fontSize09 textBold"><?php echo $echoError ?></div>
								<div class="margine05"></div>
							<?php
							}
						?>
						</div>
					</div>
				<?php
				}
			?>
				
				<div class="col100 floatLeft padding10 marginRight20 borderGray minHeight400">
				
				<?php
					if(1 > 0)
					{
					?>
						<div class="col98 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Upload Data
						</div>
						
						<div class="col95 marginAuto padding2 borderColorGrey2 marginBottom20">
							<form name="form_1" action="uploadmaping.php" method="post" onsubmit="return validate_form1()" enctype="multipart/form-data">
							
								<div class="col20 floatLeft marginRight10 marginBottom10 marginTop5 textBold">Browse File</div>
								<div class="col40 floatLeft marginRight10 marginBottom10">
									<input type="file" name="fupload" class="textinputbasic fontSize09">
								</div>
								<div class="margine"></div>
								
								<div class="col20 floatLeft marginRight10 marginBottom10 marginTop5 textBold">Bulan Kunjungan</div>
								<div class="col20 floatLeft marginRight10 marginBottom10">
										<select name="bln_pm" id="bln_pm" class="selectinputbasic paddingTop5 paddingBottom5 fontSize085">
											<option value="Januari">Januari</option>
											<option value="Februari">Februari</option>
											<option value="Maret">Maret</option>
											<option value="April">April</option>
											<option value="Mei">Mei</option>
											<option value="Juni">Juni</option>
											<option value="Juli">Juli</option>
											<option value="Agustus">Agustus</option>
											<option value="September">September</option>
											<option value="Oktober">Oktober</option>
											<option value="November">November</option>
											<option value="Desember">Desember</option>
										</select>
								</div>
								<div class="margine"></div>
								
								<?php
									//$queryLV = "select idVendor,vendor from vendor order by vendor";
									//$resultLV = mysql_query($queryLV);
								?>
								
								<!--<div class="col20 floatLeft marginRight10 marginBottom10 marginTop5 textBold">Vendor</div>
								<div class="col20 floatLeft marginRight10 marginBottom10">
									<select name="idVendor" class="selectinputbasic paddingTop5 paddingBottom5 fontSize085">
									<?php
										while($rowLV = mysql_fetch_array($resultLV))
										{
										?>
											<option value="<?php echo $rowLV['idBank'] ?>"><?php echo $rowLV['Bank'] ?></option>
										<?php
										}
									?>
									</select>
								</div>
								
								<div class="margine"></div>-->
								
								<!--<div class="col20 floatLeft marginRight10 marginBottom10 marginTop5 textBold">Period</div>
								<div class="col20 floatLeft marginRight10 marginBottom10">
									<input type="text" name="date" id="date1" class="textinputbasic textCenter" value="<?php echo date("Y-m-d") ?>">
								</div>
								<div class="margine"></div>-->
								
								<div class="col100 floatLeft marginBottom10 marginTop20">
									<input type="submit" name="cmdUpload" value="Upload Data" class="styleButtonMiddle">
								</div>
								<div class="margine"></div>
							</form>
						</div>
						
					<?php
					}
				?>
				</div>
				
				<div class="margine"></div>
			</div>
			
			<div class="margine"></div>
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>