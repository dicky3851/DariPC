			
						
			<div class="header_nav" id="home">
				<nav class="navbar navbar-default chn-gd">
					<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
							</button>
						</div>
						
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav">
                                <li>
                                    <a href="index.php">Home</a>
                                </li>
								<li>
                                    <a href="#">Master</a>
									<ul>
									<?php
										if($usergroup == "Administrator")
										{
										?>
											<a href="vendor.php"><li>Vendor Management</li></a>
										<?php
										}
									?>
									</ul>
                                </li>
									<li>
										<a href="#">Data Management</a>
										<ul>
											<?php
												if($usergroup == "Administrator" || $usergroup == "Posko")
												{
												?>
													<a href="uploadmaping.php"><li>Upload Data PM</li></a>
												<?php
												}
											?>
											  
												<!-- <a href="memberbank.php"><li>Report Memberbank</li></a>
											    <a href="reportdaily.php"><li>Report Daily</li></a>
												 <a href="reportdailymapping.php"><li>Report Log Mapping</li></a>
												<a href="index1.php"><li>Dashboard Deployment</li></a>
												<a href="monitoring2.php"><li>Monitoring Deployment</li></a>
												<a href="monitoringMB.php"><li>Monitoring Memberbank</li></a> -->
											 
										</ul>
									</li>
							
								<li>
                                    <a href="#">Bucket List</a>
									<ul>
									<?php
										if($usergroup == "Administrator")
										{
											?>
												<a href="listdata.php"><li>Belum Terkunjungi</li></a>
												<a href="closecompleted.php"><li>Terkunjungi</li></a>
												<a href="alldata.php"><li>All Data</li></a>
											<?php
										}
										if($usergroup == "Vendor")
										{
										?>
											<a href="listdata.php"><li>Belum Terkunjungi</li></a>
											<a href="closecompleted.php"><li>Terkunjungi</li></a>
											<!-- <a href="closecompleted.php"><li>Terkunjungi</li></a> -->
											<!-- <a href="sendbackvendor.php"><li></li></a>
											<a href="readyremapping.php"><li>Re-Mapping</li></a> -->
										<?php
										}
										
										if($usergroup == "Posko")
										{
										?>
											<a href="listdata.php"><li>Belum Terkunjungi</li></a>
											<a href="closecompleted.php"><li>Terkunjungi</li></a>
											<!-- <a href="alldata.php"><li>All Data</li></a> -->
											<!-- <a href="readyremapping.php"><li>Re-Mapping</li></a> -->
										<?php
										}
										
										// if($usergroup == "Administrator" || $usergroup == "Posko" || $usergroup == "Vendor")
										// {
										// ?>
										<!-- // 	<a href="openschedule.php"><li>Open Schedule</li></a>
										// 	<a href="pendingcase.php"><li>Pending Customer</li></a> -->
										<!-- // <?php 
										// }
										
										// if($usergroup == "Administrator" || $usergroup == "Posko" || $usergroup == "Asset")
										// {
										// ?>
										<!-- // 	<a href="pendingvendor.php"><li>Pending Vendor</li></a>
										// 	<a href="cancelcase.php"><li>Cancel</li></a>
										// 	<a href="closecompleted.php"><li>Close Completed</li></a> -->
											
									 <!-- <?php 
										// }
									?>-->
									</ul>
                                </li>
                                <li>
                                    <a href="">User</a>
                                    <ul>
										<?php
											if($usergroup == "Administrator")
											{
											?>
												<a href="maintain_user.php"><li>User Management</li></a>
											<?php
											}
											if($usergroup == "Vendor")
											{
											?>
												<!-- <a href="maintain_user.php"><li>User Management</li></a> -->
											<?php
											}	
										?>
										<a href="change_password.php"><li>Change Password</li></a>
										<a href="logout.php"><li>Logout</li></a>
										
                                    </ul>
                                </li>
								<li><a href=""><? echo 'Hi, '.$_SESSION['username'] ?></a></li>
								    
                                <!--script-->
								<script type="text/javascript">
                                jQuery(document).ready(function($) {
                                $(".scroll").click(function(event){		
                                event.preventDefault();
                                $('html,body').animate({scrollTop:$(this.hash).offset().top},900);
                                });
                                });
                                </script>
                                <!--script-->
							</ul>
						</div><!-- /.navbar-collapse -->
						<div class="clearfix"></div>
					</div><!-- /.container-fluid -->
				</nav>
			</div>
			