<script type="text/javascript" src="https://www.chartjs.org/dist/2.9.3/Chart.min.js"></script>
<script>
	function showsaldo(saldo)
	{
		//document.getElementById("txtHint").innerHTML="";
		/*if(str == "" || str == "none")
		{
			document.getElementById("txtHint").innerHTML="Please select Policy Number";
			return;
		}*/
		if (window.XMLHttpRequest)
		{// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		}
		else
		{// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange=function()
		{
			if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
				document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
			}
		}
		
		xmlhttp.open("GET","viewsaldo.php?saldo="+saldo,true);
		xmlhttp.send();
	}
</script>

<div class="basicFrame backgroundGray">
	<div class="col100 backgroundWhite marginBottom20 paddingLeft1 paddingRight1 paddingTop2 paddingBottom2">
		
		<marquee  style="font-family:Fantasy; font-size:80px; color:#1E90FF;">Monitoring PM System</marquee>

		
	</div>
	<div id="containerMonth" style="position: relative;">
		<div id="container" style="width: 75%;">
			<canvas id="canvas"></canvas>
		</div>
		<div class="list-group" style="position: absolute;right: 0;top: 100px;width: 20%;margin: 0 auto;height: 195px;overflow-x: scroll;">
			<?php
			$getvendor = $_GET['vendor'];
			$query = "select * from vendor";
			$resultD = mysql_query($query);
			$aktif = "";
					//echo $query."<br>";
			if($getvendor == '0'){
				$getvendor = '';
				$aktif = "active";
			}
			echo "<a href='#' data-link='vendor=0' class='list-submit list-group-item list-group-item-action $aktif'>All Vendor</a>";
			while($rowD = mysql_fetch_array($resultD)){
				$aktif = "";
						// $monthName = date('F', mktime(0, 0, 0, $rowD['bulan'], 10));
				if($getvendor == $rowD['vendor']){
					$aktif = "active";
					
				}
				echo "<a href='#' data-link='vendor={$rowD['vendor']}' class='list-submit list-group-item list-group-item-action $aktif'>{$rowD['vendor']}</a>";
			}
			?>
		</div>
		<div style="position: absolute;right: 0;width: 20%;top: 0;"><?php
		$getdate1 = $_GET['start'];
		$getdate2 = $_GET['end'];
		?>
		<input type="text" name="date1" id="date1" placeholder="Start Date" class="textinputbasic textCenter form-control" value="<?php echo $getdate1 ?>">
		<input type="text" name="date2" id="date2" placeholder="End Date" class="textinputbasic textCenter form-control" value="<?php echo $getdate2 ?>">
	</div>
</div>



<div class="margine"></div>
</div>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
<script type="text/javascript">
	$('#date2').datepicker({
		format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date1').datepicker({
		format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').change(function(e){
		var str = new Date($('#date1').val());
		var end = new Date($('#date2').val());
		if( Date.parse(str) > Date.parse(end) ){
			alert('End date must be bigger than start date');
			$('#date2').val('');
		// $('#date2').focus();
	}
});
	$('#date2sla').datepicker({
		format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date1sla').datepicker({
		format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2sla').change(function(e){
		var str = new Date($('#date1sla').val());
		var end = new Date($('#date2sla').val());
		if( Date.parse(str) > Date.parse(end) ){
			alert('End date must be bigger than start date');
			$('#date2sla').val('');
		// $('#date2').focus();
	}
});
</script>
<script>
	const listSubmit = document.querySelectorAll('.list-submit');
	listSubmit.forEach(el => el.addEventListener('click', function(event) {
		event.preventDefault();
		var date1 = document.getElementById('date1').value;
		var date2 = document.getElementById('date2').value;
		var date1sla = document.getElementById('date1sla').value;
		var date2sla = document.getElementById('date2sla').value;
		var url = window.location.pathname;
		var link = event.target.dataset.link;
		var sla = el.classList.contains("sla");
		if (date1 != '' && date2 != '' && sla == false){
			window.location.replace(url + '?' + link + '&start=' + date1 + '&end=' + date2);
		}else if (date1sla != '' && date2sla != '' && sla == true){
			window.location.replace(url + '?' + link + '&startsla=' + date1sla + '&endsla=' + date2sla);
		}else{
			window.location.replace(url + '?' + link);
		}
	}));
	<?php
	$query = "select a.idStatus id , a.status from asset_status a order by a.urutanGraf";
	$resultD = mysql_query($query);
	$status = array();
	while($rowD = mysql_fetch_array($resultD)){
		$status[$rowD['id']] = array($rowD['status'], 0);
	}
	?>
/*
var data = [<?php
$whereMonth = "";
if ($getdate1 != '' && getdate2 != ''){
	$whereMonth = "and m.uploadDT between '$getdate1' and '$getdate2'";
}
$query = "select  s.idStatus , count(m.idStatus) total, month(m.uploadDT) bulan
from asset_status s
left join data_pm m on s.idStatus = m.idStatus
where m.uploadDT is not null and vendor like '%$getvendor%' $whereMonth
group by s.idStatus, m.uploadDT";
$resultD = mysql_query($query);
$resultRow = mysql_num_rows($resultD);
$data = array();

while($rowD = mysql_fetch_array($resultD)){
	$status[$rowD['idStatus']][1] += $rowD['total'];
}
function fnsdata ($val){
		return $val[1];
	};
echo implode(",", array_map( 'fnsdata', $status ) )
?>];
*/
var fd = new FormData();
<?php 
echo "fd.append('vendor','$getvendor');\n";
if ($getdate1 != '' && getdate2 != ''){
	echo "fd.append('start', '$getdate1');\n";
	echo "fd.append('end', '$getdate2');\n";
}
?>
// $.post( "grafik.php", fd, function( data ) {
  // console.log( data ); // John
  // // console.log( data.time ); // 2pte
// }, "json");
var data = [];

<?php echo "/* $query */\n" ?>
var MONTHS = [<?php
// 'done', 'pending', 'on process'
	function fns ($val){
		return $val[0];
	};
	echo "'".implode("', '", array_map( 'fns', $status ) )."'";
	?>];
	var color = Chart.helpers.color;
	var warna = 'rgb(0,191,255)';
	var barChartData = {
		labels: MONTHS,
		datasets: [{
			label: '',
			backgroundColor: color(warna).alpha(0.5).rgbString(),
			borderColor: warna,
			borderWidth: 1,
			data: data
		}]
	};
	var ctx = document.getElementById('canvas').getContext('2d');
	window.myBar = new Chart(ctx, {
		type: 'bar',
		data: barChartData,
		options: {
			scales: {
				yAxes: [{
					ticks: {
						beginAtZero: true
					}
				}]
			},
			responsive: true,
			legend: {
				position: 'top',
			},
			title: {
				display: true,
				text: 'DASHBOARD OF DEPLOYMENT PROCESSING'
			}
		}
	});

	function getData() {
		$.ajax({
			url: 'grafik.php',
			data: fd,
			processData: false,
			contentType: false,
			type: 'POST',
			success: function(datagraf){
				var index = 0;
	    //console.log(datagraf);
	    for (const [key, value] of Object.entries(datagraf)) {
		    //console.log(`key ${key} value ${value[1]}`);
		    data[index] = value[1];
		    index++;
		}
		//console.log(data);
		window.myBar.update();
	},
	dataType: 'json'
});
	}


getData();
setInterval(getData, 60000);
getDatasla();
</script>