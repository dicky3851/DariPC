<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Memberbank Info
						</div>
						<div class="col100 marginTop20 marginBottom2">
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant ID BRI</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mid_bri'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID BRI</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tid_bri'] ?>
								</div>
							</div>
							
							<div class="margine"></div>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant ID BTN</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mid_btn'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID BTN</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tid_btn'] ?>
								</div>
							</div>
							
							<div class="margine"></div>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant ID BNI</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mid_bni'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID BNI</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tid_bni'] ?>
								</div>
								</div>
							<div class="margine"></div>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant ID Danamon</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mid_danamon'] ?>
								</div>
							</div>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID Danamon</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tid_danamon'] ?>
									</div>
								</div>

								<div class="margine"></div>
								
								<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant ID Astrapay</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mid_astrapay'] ?>
								</div>
							</div>

							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID Astarpay</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tid_astrapay'] ?>
								</div>
							</div>

							<div class="margine"></div>
							
								<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant ID BSI</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mid_bsi'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">TID BSI</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tid_bsi'] ?>
								</div>
							</div>
							<div class="margine"></div>
							
						</div>