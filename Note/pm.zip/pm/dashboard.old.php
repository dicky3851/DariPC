<!doctype html>
<html>

<head>
	<title>Dashboard Mapping Processing</title>
	<script src="js/jquery.min.js"></script>
	<script src="src/dist/Chart.min.js"></script>
	<script src="src/utils.js"></script>
	
	<link href="css/style2.css" rel="stylesheet" type="text/css"/>
	<link href="css/style4.css" rel="stylesheet" type="text/css"/>
	
	<!--<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	
	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>-->
	
	<style>
	canvas {
		-moz-user-select: none;
		-webkit-user-select: none;
		-ms-user-select: none;
	}
	</style>
</head>

<script>
	function validate_form1()
	{	
		if(document.form_1.date1.value.length == 0)
		{
			alert('Plesase input Interval Periode 1');
			document.form_1.date1.focus();
			return false;
		}
		
		if(document.form_1.date2.value.length == 0)
		{
			alert('Plesase input Interval Periode 1');
			document.form_1.date2.focus();
			return false;
		}
		
		if(document.form_1.date3.value.length == 0)
		{
			alert('Plesase input Interval Periode 2');
			document.form_1.date3.focus();
			return false;
		}
		
		if(document.form_1.date4.value.length == 0)
		{
			alert('Plesase input Interval Periode 2');
			document.form_1.date4.focus();
			return false;
		}
        
        return true;
    }

</script>

<?php
	include("connect_db.php");
?>

<body>
	<div class="col90 marginAuto paddingTop20">
		<div class="col100 textCenter marginBottom20 fontSize12 textBold"><center>Dashboard of Mapping Processing</center></div>
		
		<div class="margine"></div>
		
		<div class="col100 backgroundWhite">
			<div class="col100 textBold marginBottom20">Mapping Status</div>
			
			<div class="col100 fontSize09">
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background1"></div>
					<div class="col80 floatLeft">Open Warehouse</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background2"></div>
					<div class="col80 floatLeft">Ready to Mapping</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background3"></div>
					<div class="col80 floatLeft">Open Schedule</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background4"></div>
					<div class="col80 floatLeft">Send Back to Vendor</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background5"></div>
					<div class="col80 floatLeft">Send Back to Asset</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background6"></div>
					<div class="col80 floatLeft">Pending Customer</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background7"></div>
					<div class="col80 floatLeft">Pending Vendor</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background8"></div>
					<div class="col80 floatLeft">Re-mapping</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background9"></div>
					<div class="col80 floatLeft">Cancel</div>
					<div class="margine"></div>
				</div>
				<div class="col15 floatLeft marginRight10 marginBottom10">
					<div class="col15 floatLeft marginRight5 background10"></div>
					<div class="col80 floatLeft">Close Completed</div>
					<div class="margine"></div>
				</div>
				
				<div class="margine"></div>
			</div>
				
			<div id="container" class="col100">
				<canvas id="canvas"></canvas>
			</div>
		</div>
				
		<div class="margine"></div>
				
		<?php
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Open Warehouse'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data1 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Ready to Mapping'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data2 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Open Schedule'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data3 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Send Back to Vendor'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data4 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Send Back to Asset'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data5 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Pending Customer'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data6 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Pending Vendor'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data7 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Re-mapping'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data8 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Cancel'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data9 = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Close Completed'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$data10 = floatval($rowD['jml']);
				
		?>
		
		<div class="margine"></div>
	</div>
		
		
	
<?php
	$labels = array();
?>

	<script>
	var data = [];
		var color = Chart.helpers.color;
		var barChartData = {
			labels: ['1','2','3','4','5','6','7','8','9','10'],
			
			datasets: [{
				label: '',
				backgroundColor: [
					'rgba(255,99,132,1)',
					'rgba(238,180,34,1)',
					'rgba(205,0,205,1)',
					'rgba(72,61,139,1)',
					'rgba(159,182,205,1)',
					'rgba(0,197,205,1)',
					'rgba(0,199,140,1)',
					'rgba(0,201,87,1)',
					'rgba(238,238,0,1)',
					'rgba(54,162,235,1)'
					],
				borderColor: [
					'rgba(255,99,132,1)',
					'rgba(238,180,34,1)',
					'rgba(205,0,205,1)',
					'rgba(72,61,139,1)',
					'rgba(159,182,205,1)',
					'rgba(0,197,205,1)',
					'rgba(0,199,140,1)',
					'rgba(0,201,87,1)',
					'rgba(238,238,0,1)',
					'rgba(54,162,235,1)'
					],
				borderWidth: 1,
				data: data,
				//data: [
					<?php
						//echo $data1.",".$data2.",".$data3.",".$data4.",".$data5.",".$data6.",".$data7.",".$data8.",".$data9.",".$data10;
					?>
				//	]
			}]

		};

		var ctx = document.getElementById('canvas').getContext('2d');
		window.myBar = new Chart(ctx, {
			type: 'bar',
			data: barChartData,
			options: {
				responsive: true,
				legend: {
					position: 'top',
				},
				title: {
					display: false,
					text: 'Chart.js Bar Chart'
				},
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}
			}
		});
		
		function getData() {
            $.ajax({
        	  url: 'grafikdashboard.php',
        	  //data: fd,
        	  processData: false,
        	  contentType: false,
        	  type: 'POST',
        	  success: function(datagraf){
        	    var index = 0;
        	    //console.log(datagraf);
        		for (const [key, value] of Object.entries(datagraf)) {
        		    //console.log(`key ${key} value ${value[1]}`);
        		  data[index] = value[1];
        		  index++;
        		}
        		//console.log(data);
        		window.myBar.update();
        	  },
        	  dataType: 'json'
        	});
        }
        getData();
        setInterval(getData, 60000);

	</script>
	
	<!--<script>
		var color = Chart.helpers.color;
		var barChartData = {
			labels: ['Periode 1','Periode 2'],
			
			datasets: [{
				label: '#Approved',
				backgroundColor: color(window.chartColors.red).alpha(1).rgbString(),
				borderColor: window.chartColors.red,
				borderWidth: 1,
				data: [
					<?php
						echo $data1a.",".$data2a;
					?>
					]
			}, {
				label: '#Rejected',
				backgroundColor: color(window.chartColors.blue).alpha(1).rgbString(),
				borderColor: window.chartColors.blue,
				borderWidth: 1,
				data: [
					<?php
						echo $data1b.",".$data2b;
					?>
					]
			}]

		};

		var ctx = document.getElementById('canvas2').getContext('2d');
		window.myBar = new Chart(ctx, {
			type: 'bar',
			data: barChartData,
			options: {
				responsive: true,
				legend: {
					position: 'top',
				},
				title: {
					display: false,
					text: 'Chart.js Bar Chart'
				},
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}
			}
		});

	</script>-->
	
	
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
</body>

</html>
