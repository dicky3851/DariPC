<?php
session_start();
if(!isset($_SESSION['userID']))
{
	header("Location:login.php");
}

include('connect_db.php');
$idVendorC = $_GET['idVendorC'];

if($idVendorC <> 0)
{
		//Get Nama Vendor
	$queryGV = "select vendor from vendor where idVendor = ".$idVendorC;
	$resultGV = mysql_query($queryGV);
	$rowGV = mysql_fetch_array($resultGV);
	$vendorName = $rowGV['vendor'];
}

$file_name = "Data_Upload_Open_Warehouse_Pending_Reason";

header("Content-type: application/octet-stream");
header('Content-Type: plain/text'); 
header("Content-Disposition: attachment; filename=".$file_name.".xls");
header("Pragma: no-cache");
header("Expires: 0");

?>
<table border="1">

	<?php
	$queryLC = "select idMapping,date_format(uploadDT,'%d/%m/%Y') as 'uploadDT',date_format(updateDT,'%d/%m/%Y') as 'updateDT',
	statusAsset,type,caseID,mid,tid,tidreplace,mid_bri,tid_bri,mid_btn,tid_btn,mid_bni,tid_bni,mid_danamon,tid_danamon,mid_astrapay,tid_astrapay,mid_bsi,tid_bsi,
	note,merchant,address,city,vendor,vendorupdate,sn_edc,sn_sam,sn_sim,wr,provider_sim,produk_sam,pendingreason,targetmaping,remarks,date_format(datewr,'%d/%m/%Y') as 'datewr',terminaltype,dongle,provider,
	CASE WHEN b.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
	WHEN b.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
	END AS 'sla',
	a.idRC,a.rc,c.username
	from asset_mapping a
	INNER JOIN asset_status b ON a.idStatus = b.idStatus
	inner join asset_login c on a.updateBy = c.userID
	where 1 > 0 and a.idStatus = 3";

	if($idVendorC <> 0)
	{
		$queryLC = $queryLC." and vendor = '".$vendorName."'";
	}

	$queryLC = $queryLC." order by idMapping";

	$resultLC = mysql_query($queryLC);
							//echo $queryLC."<br>";
	$totalRoll = 0;
	?>
	<tr>
		<th>ID Mapping</th>
		<th>Case ID</th>
		<th>WR</th>
		<th>MID</th>
		<th>TID</th>
		<th>TID Replace</th>
		<th>Note</th>
		<th>Merchant Name</th>
		<th>Address</th>
		<th>City</th>
		<th>Vendor</th>
		<th>Terminal Type</th>
		<th>Dongle</th>
		<th>Provider</th>
		<th>SN EDC</th>
		<th>SN SAM</th>
		<th>SN SIM</th>
		<th>Provider SIM</th>
		<th>Produk SAM</th>
		<th>Aging</th>
		<th style="background:#FFFF00;">Pending Reason</th>
		<th style="background:#FFFF00;">Target Mapping</th>
	</tr>
	<?php
	while($rowLC = mysql_fetch_array($resultLC))
	{
		?>
		<tr>
			<td><?php echo $rowLC['idMapping'] ?></td>
			<td><?php echo "'".$rowLC['caseID'] ?></td>
			<td><?php echo $rowLC['wr'] ?></td>
			<td><?php echo $rowLC['mid'] ?></td>
			<td><?php echo $rowLC['tid'] ?></td>
			<td><?php echo $rowLC['tidreplace'] ?></td>
			<td><?php echo $rowLC['note'] ?></td>
			<td><?php echo $rowLC['merchant'] ?></td>
			<td><?php echo $rowLC['address'] ?></td>
			<td><?php echo $rowLC['city'] ?></td>
			<td><?php echo $rowLC['vendor'] ?></td>
			<td><?php echo $rowLC['terminaltype'] ?></td>
			<td><?php echo $rowLC['dongle'] ?></td>
			<td><?php echo $rowLC['provider'] ?></td>
			<td><?php echo $rowLC['sn_edc'] ?></td>
			<td><?php echo $rowLC['sn_sim'] ?></td>
			<td><?php echo $rowLC['sn_sam'] ?></td>
			<td><?php echo $rowLC['provider_sim'] ?></td>
			<td><?php echo $rowLC['produk_sam'] ?></td>
			<td><?php echo $rowLC['sla']." Days" ?></td>
			<td style="background:#FFFF00;"><?php echo $rowLC['pendingreason']  ?></td>
			<td style="background:#FFFF00;"><?php echo $rowLC['targetmaping']?></td>
		</tr>
		<?php
	}
	?>


</table>

