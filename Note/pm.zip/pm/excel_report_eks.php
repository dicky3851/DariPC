<?php
	session_start();
	if(!isset($_SESSION['userID']))
	{
		header("Location:login.php");
	}
	
	include('connect_db.php');
	$idKurir = $_POST['idKurir'];
	$status = $_POST['status'];
	$bln = $_POST['bln'];
	$thn = $_POST['thn'];
	
	$file_name = "Report_Delivery".$bln."_".$thn;
	
	header("Content-type: application/octet-stream");
	header('Content-Type: plain/text'); 
	header("Content-Disposition: attachment; filename=".$file_name.".xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	
?>

						<table border="1">
							<tr>
								<th colspan="9"><h2>Delivery Report</h2></th>
							</tr>
							
						<?php
							$queryLC = "select a.idDelivery,a.idMerchant,a.mid,b.merchant,a.kurir,a.kota,a.jmlKirim,b.merchantAddr,
										date_format(kirimDT,'%m/%d/%Y') as 'kirimDT',date_format(pickupDT,'%m/%d/%Y') as 'pickupDT',
										date_format(terimaDT,'%m/%d/%Y') as 'terimaDT',
										a.status,a.penerima
										from thermal_delivery a
										left outer join merchant b on a.idMerchant = b.idMerchant
										where 1 > 0 and bln = ".$bln." and thn = ".$thn;
							
							if($status == "Done")
							{
								$queryLC = $queryLC." AND upper(a.status) in ('DONE')";
							}
							elseif($status == "Not")
							{
								$queryLC = $queryLC." AND upper(a.status) not in ('DONE')";
							}
							
							if($idKurir <> "All")
							{
								$queryLC = $queryLC." AND a.idKurir = ".$idKurir;
							}
							
							$queryLC = $queryLC." order by a.mid";
							
							$resultLC = mysql_query($queryLC);
							$totalRoll = 0;
						?>
							<tr>
								<th>MID</th>
								<th>Nama Merchant</th>
								<th>Alamat</th>
								<th>Kota</th>
								<th>Jumlah Roll</th>
								<th>Penerima</th>
								<th>Tanggal Terima</th>
								<th>Status</th>
								<th>Ekspedisi</th>
							</tr>
							<?php
								while($rowLC = mysql_fetch_array($resultLC))
								{
									$idDelivery = $rowLC['idDelivery'];
								?>
									<tr>
										<td><?php echo $rowLC['mid'] ?></td>
										<td><?php echo $rowLC['merchant'] ?></td>
										<td><?php echo $rowLC['merchantAddr'] ?></td>
										<td><?php echo $rowLC['kota'] ?></td>
										<td><?php echo $rowLC['jmlKirim'] ?></td>
										<td><?php echo $rowLC['penerima'] ?></td>
										<td><?php echo $rowLC['terimaDT'] ?></td>
										<td><?php echo $rowLC['status'] ?></td>
										<td><?php echo $rowLC['kurir'] ?></td>
									</tr>
							<?php
									$totalRoll = floatval($totalRoll) + floatval($rowLC['jmlKirim']);
								}
							?>
								<tr>
									<td colspan="4"><strong>TOTAL</strong></td>
									<td><strong><?php echo $totalRoll ?></strong></td>
									<td colspan="4"><strong>&nbsp;</strong></td>
								</tr>
						</table>
    
