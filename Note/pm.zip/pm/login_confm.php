<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Asset Management System</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	
	<!--<link rel="Shortcut icon" href="images/logo_url.png">-->
        
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
	<link href="css/style4.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>

  <body>
  
<?php
	include('connect_db.php');
?>

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->

	  <div id="login-page">
	  	<div class="container">
			
            <form class="form-login" action="login_proc.php" method="post" onsubmit="return cekPassword()">
                <input type="hidden" name="username" value="<?php echo $_SESSION['username']  ?>">
			    
				<div class="col100 textCenter">
					<img src="images/logo1.png" class="logoLogin">
				</div>
                <div class="margine"></div>
		        <div class="login-wrap">
                    <input type="text" disabled="disable" class="form-control" placeholder="Username" autofocus value="<?php echo $_SESSION['username'] ?>">
		            <br>
		            <input type="password" disabled="disable" id="oldPass" class="form-control" placeholder="Password" value="<?php echo $_SESSION['password'] ?>">
                    <!-- <small style="display:none" id="newOldPass" class="text-danger">Password tidak boleh sama</small><br> --><br>
					 
                    <input type="password" class="form-control" id="newPass" name="newPassword" placeholder="New Pasword" autofocus onBlur="newPassword(this)" onKeyUp="clearCheckPass()">
		            <!-- <small style="display:none" id="newCheckPass" class="text-danger">Password baru harus sama</small><br> --> <br>
		            
                    <input type="password" class="form-control" id="checkPass" name="confirmPassword" placeholder="Confirm Password" onKeyUp="samePass()" onFocus="focusPass()">
                    <!-- <input type="hidden" name="error" id="error"> -->
					<br>
                    
                    <div class="alert alert-danger alert-dismissable" id="notif" style="display:none">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong>Warning!</strong> <br>New Password same as Current Password
                    </div>
                    
                    <div class="alert alert-danger alert-dismissable" id="notif2" style="display:none">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong>Warning!</strong> <br>Confirm Password must be same as New Password
                    </div>
                    
                    <div class="alert alert-danger alert-dismissable" id="notif3" style="display:none">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong>Warning!</strong> <br>New Password must filled in
                    </div>

                    <div class="alert alert-danger alert-dismissable" id="notif4" style="display:none">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong>Warning!</strong> <br>Confirm Password must filled in
                    </div>
		            
                    <button class="btn btn-theme btn-block" href="index.php" type="submit" name="cmdFirstLogin"><i class="fa fa-lock"></i>Login</button>
		            
		        </div>
            </form>	  	
	  	
	  	</div>
	  </div>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script language="javascript">
    
    function cekPassword()
    {
		var e = document.getElementById("notif");
        var e2 = document.getElementById("notif2");
        var e3 = document.getElementById("notif3");
        var e4 = document.getElementById("notif4");
		var oldP = document.getElementById("oldPass").value;
        var newP = document.getElementById("newPass").value;
        var confNewP = document.getElementById("checkPass").value;
		
		if(newP == "")
        {
			e.style="display:none";
            e2.style="display:none";
            e3.style="display:block";
            e4.style="display:none";
            return false;
		}
        else if(oldP == newP)
        {
			e.style="display:block";
            e2.style="display:none";
            e3.style="display:none";
            e4.style="display:none";
            return false;
		}
        else if(confNewP == "")
        {
			e.style="display:none";
            e2.style="display:none";
            e3.style="display:none";
            e4.style="display:block";
            return false;
		}
        else if(confNewP != newP)
        {
			e.style="display:none";
            e2.style="display:block";
            e3.style="display:none";
            e4.style="display:none";
            return false;
		}
        
        return true;
	}
    
    function newPassword(newP){
		var e=document.getElementById("newOldPass");
		var oldP = document.getElementById("oldPass").value;	
		var saveError=document.getElementById("error");
		if(newP.value == oldP){
			e.style="display:block";
//			newP.focus();
			saveError.value="Password Sama";			
		}else{
			e.style="display:none";
			saveError.value="";
		}
	}
	
	function clearCheckPass(){
		document.getElementById("checkPass").value ="";	
	}
	
	function focusPass(){
		var saveError=document.getElementById("error").value;		
		if (saveError !=""){
			document.getElementById("newPass").focus();
		}
	}
	
	function samePass(){
		var newP = document.getElementById("newPass").value;		
		var checkP = document.getElementById("checkPass").value;	
		var e=document.getElementById("newCheckPass");	
		var saveError=document.getElementById("error");
		if(newP != checkP){
			e.style="display:block";
			checkP.focus();
			saveError.value="Confirm Password must be same as New Password";
		}else{
			e.style="display:none";
			saveError.value="";
		}
	}
    </script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
	
	<!--
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/login-bg.jpg", {speed: 500});
    </script>
	-->

  </body>
</html>
