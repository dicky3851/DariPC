<?php
session_start();
if(!isset($_SESSION['userID']))
{
	header("Location:login.php");
}

include('connect_db.php');
$date1 = $_GET['date1'];
$date2 = $_GET['date2'];
$type = $_GET['type'];
$field = $_GET['field'];
$idVendorC = $_GET['idVendorC'];

if($idVendorC <> 0)
{
		//Get Nama Vendor
	$queryGV = "select vendor from vendor where idVendor = ".$idVendorC;
	$resultGV = mysql_query($queryGV);
	$rowGV = mysql_fetch_array($resultGV);
	$vendorName = $rowGV['vendor'];
}

$file_name = "Report_PM_".$type."_".$date1."_".$date2;

header("Content-type: application/octet-stream");
header('Content-Type: plain/text'); 
header("Content-Disposition: attachment; filename=".$file_name.".xls");
header("Pragma: no-cache");
header("Expires: 0");

?>
Print date : <?php echo date("d/m/Y") ?><br>
<table border="1">
	<tr>
		<th colspan="16"><h2>Data PM - <?php echo $type ?></h2></th>
	</tr>

	<?php
	$queryLC = "select idPm,MID,TID,feature,mrchnt_name,mrchnt_official,mrchnt_addr,LOB,city,region,vendor,
	install_date,edc_status,mrchnt_type,mbr_bank,segment,sn_edc,provider,sim_sno,conn_type,aom,
	sts_kunjungan,tgl_kunjungan,kategori,sub_kategori,remark,pic_nama,pic_tlp,test_trx,tgl_test,
	paper_roll,edc_banklain,bln_pm
	from data_pm a
	INNER JOIN asset_status b ON a.idStatus = b.idStatus
	where 1 > 0 ";

	if($type <> "All")
	{
		$queryLC = $queryLC." and sts_kunjungan = '".$type."'";
	}

	if(!empty($date1) && $date1 <> "" && !empty($date2) && $date2 <> "")
	{
		$queryLC = $queryLC." and updateDT between '".$date1."' and '".$date2."'";
	}

	if($idVendorC <> 0)
	{
		$queryLC = $queryLC." and vendor = '".$vendorName."'";
	}

	if(!empty($field) || $field <> "")
	{
		$queryLC = $queryLC." and (mid like '%".$field."%' or tid like '%".$field."%' or caseID like '%".$field."%' or wr like '%".$field."%'
		or merchant like '%".$field."%')";
	}

	//$queryLC = $queryLC." order by uploadDT desc";
		//echo $queryLC."<br>";
	$resultLC = mysql_query($queryLC);
	$totalRoll = 0;
	?>
	<tr>
		<th>MID</th>
		<th>TID</th>
		<th>Feature</th>
		<th>Merchant Name</th>
		<th>Address</th>
		<th>City</th>
		<th>Vendor</th>
		<th>Status Kunjungan</th>
		<th>Bulan Kunjungan</th>
		<th>Tanggal Kunjungan</th>
		<th>Kategori</th>
		<th>Sub Kategori</th>
		<th>Remaks</th>
		<th>Nomor PIC</th>
		<th>Paper Roll</th>
		<th>EDC Bank Lain</th>


	</tr>
	<?php
	while($rowLC = mysql_fetch_array($resultLC))
	{
		?>
		<tr>
			<td><?php echo "'".$rowLC['MID'] ?></td>
			<td><?php echo "'".$rowLC['TID'] ?></td>
			<td><?php echo $rowLC['feature'] ?></td>
			<td><?php echo $rowLC['mrchnt_name'] ?></td>
			<td><?php echo $rowLC['mrchnt_addr'] ?></td>
			<td><?php echo $rowLC['city'] ?></td>
			<td><?php echo $rowLC['vendor'] ?></td>
			<td><?php echo $rowLC['sts_kunjungan'] ?></td>
			<td><?php echo $rowLC['bln_pm'] ?></td>
			<td><?php echo $rowLC['tgl_kunjungan'] ?></td>
			<td><?php echo $rowLC['kategori'] ?></td>
			<td><?php echo $rowLC['sub_kategori'] ?></td>
			<td><?php echo $rowLC['remark'] ?></td>
			<td><?php echo $rowLC['pic_tlp'] ?></td>
			<td><?php echo $rowLC['paper_roll'] ?></td>
			<td><?php echo $rowLC['edc_banklain'] ?></td>

		</tr>
		<?php
	}
	?>
</table>

