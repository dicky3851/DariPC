<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.idStatus.value == "0")
		{
			alert('Please select Case Status');
			document.form_1.idStatus.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
		
		<?php
			if(isset($_GET['idMapping']))
			{
				$idMapping = $_GET['idMapping'];
			}
			
			if(isset($_POST['idMapping']))
			{
				$idMapping = $_POST['idMapping'];
			}
		?>
        
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Overview Detail Mapping
			</div>
			
			<?php
				if(isset($_POST['cmdSubmit']))
				{
					$idMapping = $_POST['idMapping'];
					$idStatus = $_POST['idStatus'];
					$idRC = $_POST['idRC'];
					$remarks = $_POST['remarks'];
					$sn_edc = $_POST['sn_edc'];
					$sn_sam = $_POST['sn_sam'];
					$sn_sim = $_POST['sn_sim'];
					$provider_sim = $_POST['provider_sim'];
					$produk_sam = $_POST['produk_sam'];
					$remarks = str_replace("'","",$remarks);
					
					$queryGS = "select status from asset_status where idStatus = '".$idStatus."'";
					$resultGS = mysql_query($queryGS);
					//echo $queryGS."<br>";
					$rowGS = mysql_fetch_array($resultGS);
					$statusAsset = $rowGS['status'];
				?>
					<div class="col100 backgroundWhite padding15 marginBottom10">
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Result Process
						</div>
					<?php
						if($idStatus == 11)
						{
							$queryRC = "select rc from asset_rc where idRC = ".$idRC;
							$resultRC = mysql_query($queryRC);
							$rowRC = mysql_fetch_array($resultRC);
							$rc = $rowRC['rc'];
						}
						else
						{
							$idRC = 0;
							$rc = "";
						}
					     
							
						//Exce here
						$queryEM = "update asset_mapping
									set updateBy = ".$userID.",
									updateDT = now(),
									idStatus = ".$idStatus.",
									statusAsset = '".$statusAsset."',
									sn_edc = '".$sn_edc."',
									sn_sam = '".$sn_sam."',
									sn_sim = '".$sn_sim."',
									provider_sim = '".$provider_sim."',
									produk_sam = '".$produk_sam."',
									idRC = ".$idRC.",
									rc = '".$rc."',
									remarks = '".$remarks."'
									where idMapping = ".$idMapping;
						$resultEM = mysql_query($queryEM);
						//echo $queryEM."<br>";
						
						if($resultEM)
						{
							$queryUS = "insert into asset_log
										(idMapping,idStatus,remarks,logDT,logDT2,logBy,sn_edc,sn_sam,sn_sim,
										provider_sim,produk_sam)
										select ".$idMapping.",".$idStatus.",'".$remarks."',now(),now(),".$userID.",'".$sn_edc."','".$sn_sam."','".$sn_sim."',
										'".$provider_sim."','".$produk_sam."'";
							$resultUS = mysql_query($queryUS);
							//echo $queryUS."<br>";
						}
						
						if($resultEM)
						{
						?>
							<div class="col100 textBold">Update Data successfully completed</div>
						<?php
						}
						else
						{
						?>
							<div class="col100 textBold colorRed">Update Data failed completed</div>
						<?php
						}
					?>
					</div>
				<?php
				}
			?>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
			<?php
				if(isset($_GET['idMapping']) || isset($_POST['idMapping']))
				{
					$queryDD = "select date_format(uploadDT,'%d/%m/%Y') as 'uploadDT',
								statusAsset,type,a.idStatus,statusAsset,
								caseID,mid,tid,tidreplace,mid_bri,tid_bri,mid_btn,tid_btn,mid_bni,tid_bni,mid_danamon,tid_danamon,
								mid_astrapay,tid_astrapay,mid_bsi,tid_bsi,
								note,merchant,address,city,vendor,vendorupdate,
								sn_edc,sn_sam,sn_sim,wr,
								provider_sim,produk_sam,
								b.username,date_format(updateDT,'%d/%m/%Y') as 'updateDT',
								date_format(datewr,'%d/%m/%Y') as 'datewr',
								terminaltype,dongle,provider,
								CASE WHEN c.flagEnd = 0 THEN DATEDIFF(DATE_FORMAT(NOW(),'%Y-%m-%d'),datewr)
								WHEN c.flagEnd = 1 THEN DATEDIFF(updateDT,datewr)
								END AS 'sla',
								a.idRC,a.rc
								from asset_mapping a
								left outer join asset_login b on a.updateBy = b.userID
								INNER JOIN asset_status c ON a.idStatus = c.idStatus
								where idMapping = ".$idMapping;
								
					$resultDD = mysql_query($queryDD);
					//echo $queryDD."<br>";
					$rowDD = mysql_fetch_array($resultDD);
					$idStatus = $rowDD['idStatus'];
				?>
					<form name="form_1" action="datadetailready.php" method="post" onsubmit="return validate_form1()">
						<input type="hidden" name="idMapping" value="<?php echo $idMapping ?>">
						
						<?php
							include("caseinfo.php");
						?>
						
						<?php
							include("merchantinfo.php");
						?>
						
						<?php
							include("memberbankinfo.php");
						?>
						
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Vendor Info
						</div>
						<div class="col100 marginTop20 marginBottom20">
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Vendor Name</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['vendor'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Vendor Name Update</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['vendorupdate'] ?>
								</div>
							</div>
							<div class="margine"></div>
						</div>
						
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Hardware Info
						</div>
						<div class="col100 marginTop20 marginBottom20">
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Terminal Type</div>
								<div class="marginLeft20 marginBottom20 fontSize085">
									<?php echo $rowDD['terminaltype'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Dongle</div>
								<div class="marginLeft20 marginBottom20 fontSize085">
									<?php echo $rowDD['dongle'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Provider</div>
								<div class="marginLeft20 marginBottom20 fontSize085">
									<?php echo $rowDD['provider'] ?>
								</div>
							</div>
							<div class="margine"></div>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Serial Number EDC</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['sn_edc'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Serial Number SAM</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['sn_sam'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Serial Number SIM</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['sn_sim'] ?>
								</div>
							</div>
							<div class="margine"></div>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Provider SIM</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['provider_sim'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Product SAM</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['produk_sam'] ?>
								</div>
							</div>
							<div class="margine"></div>
						</div>
						
						<div class="col100 marginAuto textBold marginTop5 marginBottom20  borderBottomColorGrey2 textUpper paddingBottom5 col100 textBold colorRed">
							<marquee> Hardware Update ( Status is VALID, Dont Change Status!!! )</marquee>
						</div>
						<div class="col100 marginTop20 marginBottom20">
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold colorRed marginBottom5">Serial Number EDC</div>
								<div class="col80 marginLeft20 fontSize085">
									<input type="text" name="sn_edc" class="textinputbasic marginBottom20" value="<?php echo $rowDD['sn_edc'] ?>">
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold colorRed marginBottom5">Serial Number SAM</div>
								<div class="col80 marginLeft20 fontSize085">
									<input type="text" name="sn_sam" class="textinputbasic marginBottom20" value="<?php echo $rowDD['sn_sam'] ?>">
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold colorRed marginBottom5">Serial Number SIM</div>
								<div class="col80 marginLeft20 fontSize085">
									<input type="text" name="sn_sim" class="textinputbasic marginBottom20" value="<?php echo $rowDD['sn_sim'] ?>">
								</div>
							</div>
							<div class="margine"></div>
							
							<?php
								$queryLS = "select idSIM,sim from asset_sim where status = 'Active'";
								$resultLS = mysql_query($queryLS);
							?>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold colorRed marginBottom5">Provider SIM</div>
								<div class="col80 marginLeft20 fontSize085">
									<select name="provider_sim" class="selectinputbasic paddingBottom5 paddingTop5">
									<?php
										while($rowLS = mysql_fetch_array($resultLS))
										{
										?>
											<option value="<?php echo $rowLS['sim'] ?>" <?php echo $rowDD['provider_sim'] == $rowLS['sim']?"selected":"" ?>><?php echo $rowLS['sim'] ?></option>
										<?php
										}
									?>
									</select>
								</div>
							</div>
							
							<?php
								$queryLS = "select idSAM,sam from asset_sam where status = 'Active'";
								$resultLS = mysql_query($queryLS);
							?>
							
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold  colorRed marginBottom5">Product SAM</div>
								<div class="col80 marginLeft20 fontSize085">
									<select name="produk_sam" class="selectinputbasic paddingBottom5 paddingTop5">
									<?php
										while($rowLS = mysql_fetch_array($resultLS))
										{
										?>
											<option value="<?php echo $rowLS['sam'] ?>" <?php echo $rowDD['produk_sam'] == $rowLS['sam']?"selected":"" ?>><?php echo $rowLS['sam'] ?></option>
										<?php
										}
									?>
									</select>
								</div>
							</div>
							<div class="margine"></div>
						</div>
						
						
						
						<?php
							$queryLS = "select idStatus,status from asset_status where domain IN ('Asset','Asset,Posko,Vendor','Vendor','Asset,Vendor','Asset,Posko')";
							$resultLS = mysql_query($queryLS);
						?>
						
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Case Flow
						</div>
						<div class="col100 marginTop20 marginBottom20">
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Status</div>
								<div class="col80 marginLeft20 fontSize085">
									<select name="idStatus" class="selectinputbasic paddingBottom5 paddingTop5">
										<option value="0">--- Select Status ---</option>
									<?php
										while($rowLS = mysql_fetch_array($resultLS))
										{
										?>
											<option value="<?php echo $rowLS['idStatus'] ?>" <?php echo $idStatus == $rowLS['idStatus']?"selected":"" ?>><?php echo $rowLS['status'] ?></option>
										<?php
										}
									?>
									</select>
								</div>
							</div>
							<div class="margine"></div>
						</div>
						
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Remarks
						</div>
						
						
						<?php
							$queryRC = "select idRC,rc from asset_rc where idStatus = 11 and statusRC = 'Active' order by idRC";
							$resultRC = mysql_query($queryRC);
							//echo $queryRC."<br>";
						?>
						
						<div class="col100 marginTop20 marginBottom20">
							<div class="col40 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Pending Vendor Root Cause</div>
								<div class="col80 marginLeft20 fontSize085">
									<select name="idRC" class="selectinputbasic paddingTop5 paddingBottom5">
										<option value="0">--- Select Root Cause ---</option>
									<?php
										while($rowRC = mysql_fetch_array($resultRC))
										{
										?>
											<option value="<?php echo $rowRC['idRC'] ?>" <?php echo $rowDD['idRC'] == $rowRC['idRC']?"selected":"" ?>><?php echo $rowRC['rc'] ?></option>
										<?php
										}
									?>
									</select>
								</div>
							</div>
							
							<div class="col40 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Vendor Remarks</div>
								<div class="col80 marginLeft20 fontSize085">
									<textarea name="remarks" class="textareabasic"></textarea>
								</div>
							</div>
							<div class="margine"></div>
						</div>
						
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Action
						</div>
						<div class="col100 marginTop20 marginBottom20">
							<div class="col30 floatLeft padding10">
								<input type="submit" name="cmdSubmit" value="Submit Data" class="styleButton">
							</div>
							<div class="margine"></div>
						</div>
						
					</form>
				<?php
				}
			?>
			
			</div>
			
			<div class="margine"></div>
			
			<?php
				include("historical.php");
			?>
			
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date3').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date4').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date5').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date6').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>