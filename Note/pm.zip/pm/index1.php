<?php
    include('header.php');
?>
	<body>
		<div class="header" id="home">
		<?php
			include('menu.php');
		?>
		</div>
		
		<?php
			include_once("indexinternal1.php");
		?>
	        <? 
				$userID = $_SESSION['userID'];
			?>
			
		
	<?php
		include('footer.php');
	?>
	</body>
</html>