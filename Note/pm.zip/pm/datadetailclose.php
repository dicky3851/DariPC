<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.idStatus.value == "0")
		{
			alert('Please select Case Status');
			document.form_1.idStatus.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
		
		<?php
			if(isset($_GET['idPm']))
			{
				$idPm = $_GET['idPm'];
			}
			
			if(isset($_POST['idPm']))
			{
				$idPm = $_POST['idPm'];
			}
		?>
        
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				Overview Detail Mapping
			</div>
			
			<?php
				if(isset($_POST['cmdSubmit']))
				{
					$idPm = $_POST['idPm'];
					$idStatus = $_POST['idStatus'];
					$remarks = $_POST['remarks'];
					
					$remarks = str_replace("'","",$remarks);
					
					$queryGS = "select status from asset_status where idStatus = '".$idStatus."'";
					$resultGS = mysql_query($queryGS);
					//echo $queryGS."<br>";
					$rowGS = mysql_fetch_array($resultGS);
					$statusAsset = $rowGS['status'];
				?>
					<div class="col100 backgroundWhite padding15 marginBottom10">
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Result Process
						</div>
					<?php
						//Exce here
						$queryEM = "update asset_mapping
									set updateBy = ".$userID.",
									updateDT = now(),
									idStatus = ".$idStatus.",
									statusAsset = '".$statusAsset."',
									remarks = '".$remarks."'
									where idPm = ".$idPm;
						$resultEM = mysql_query($queryEM);
						//echo $queryEM."<br>";
						
						if($resultEM)
						{
							$queryUS = "insert into asset_log
										(idPm,idStatus,remarks,logDT,logDT2,logBy)
										select ".$idPm.",".$idStatus.",'".$remarks."',now(),now(),".$userID;
							$resultUS = mysql_query($queryUS);
						}
						
						if($resultEM)
						{
						?>
							<div class="col100 textBold">Update Data successfully completed</div>
						<?php
						}
						else
						{
						?>
							<div class="col100 textBold colorRed">Update Data failed completed</div>
						<?php
						}
					?>
					</div>
				<?php
				}
			?>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
			<?php
				if(isset($_GET['idPm']) || isset($_POST['idPm']))
				{
					$idPm2 = $_GET['idPm'];
					
					$queryDD = "select idPm,MID,TID,feature,mrchnt_name,mrchnt_official,mrchnt_addr,LOB,city,region,vendor,
								install_date,edc_status,mrchnt_type,mbr_bank,segment,sn_edc,provider,sim_sno,conn_type,aom,
								sts_kunjungan,tgl_kunjungan,kategori,sub_kategori,remark,pic_nama,pic_tlp,test_trx,tgl_test,
								paper_roll,edc_banklain,bln_pm,edc_type,bln_pm
								from data_pm a
								LEFT OUTER JOIN asset_login b on a.updateBy = b.userID
								INNER JOIN asset_status c ON a.idStatus = c.idStatus
								where idPm = ".$idPm2;
					$resultDD = mysql_query($queryDD) or die(mysql_error());
					//echo $queryDD."<br>";
					$rowDD = mysql_fetch_array($resultDD);
					$idPm = $rowDD['idPm'];
				?>
					<form name="form_1" action="datadetailschedule.php" method="post" onsubmit="return validate_form1()">
						<input type="hidden" name="idPm" value="<?php echo $idPm ?>">
						
						<?php
							include("caseinfo.php");
						?>
						
						
						<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
							Data Monitoring PM
						</div>
						<div class="col100 marginTop20 marginBottom20">
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Region</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['region'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Vendor</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['vendor'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Merchant Type</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mrchnt_type'] ?>
								</div>
							</div>
							<div class="margine"></div>
						</div>
						<div class="col100 marginTop20 marginBottom20">
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Member Bank</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['mbr_bank'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">EDC Type</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['edc_type'] ?>
								</div>
							</div>
							<div class="col30 floatLeft padding10">
								<div class="col100 textBold marginBottom5">Tanggal Kunjungan</div>
								<div class="marginLeft20 fontSize085">
									<?php echo $rowDD['tgl_kunjungan'] ?>
								</div>
							</div>
							<div class="margine"></div>
						</div>
						<div class="col100 marginTop20 marginBottom20">
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Bulan Kunjungan</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['bln_pm'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Nama PIC</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['pic_nama'] ?>
							</div>
						</div>
						<div class="col30 floatLeft padding10">
							<div class="col100 textBold marginBottom5">Telp PIC</div>
							<div class="marginLeft20 fontSize085">
								<?php echo $rowDD['pic_tlp'] ?>
							</div>
						</div>
						
						<div class="margine"></div>
					</div>
						
						
						
					</form>
				<?php
				}
			?>
			
			</div>
			
			<div class="margine"></div>
			
			<?php
				include("historical.php");
			?>
			
		</div>
	</div>
	
<script src="js/chosen.jquery.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/chosen.css" />
<link rel="stylesheet" href="css/bootstrap-datepicker.standalone.css" />
	
<script type="text/javascript">
	$('.chosen-select').chosen({allow_single_deselect:true});
    $('#date1').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date2').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date3').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date4').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date5').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
	$('#date6').datepicker({
			format: "yyyy-mm-dd",
			//endDate: "<?php echo date('d/m/Y') ?>",
			todayBtn: true,
			autoclose: true,
			todayHighlight: true
		});
</script>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>