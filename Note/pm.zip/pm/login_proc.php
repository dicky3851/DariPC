<?php
session_start();

include("connect_db.php");

$username = $_POST['username'];
$password = $_POST['password'];

$username = str_replace("'","",$username);
$username = str_replace(" or ","",$username);
$username = str_replace("=","",$username);
$username = str_replace(">","",$username);
$username = str_replace("<","",$username);

$password = str_replace("'","",$password);
$password = str_replace(" or ","",$password);
$password = str_replace("=","",$password);
$password = str_replace(">","",$password);
$password = str_replace("<","",$password);

$password = md5($password);

	if(isset($_POST['cmdLogin']))
	{
		//echo "test";
		$queryCek = "select userID,username,usergroup,status,flagFirst,idVendor
					from asset_login 
					where upper(username) = upper('".$username."') 
					and upper(password) = upper('".$password."')
					and status = 'Active'";
		$loginCek = mysql_query($queryCek) or die(mysql_error());
		//echo $queryCek."<br />";
		$rowcountCek = mysql_num_rows($loginCek);
		$rowCek = mysql_fetch_array($loginCek);
		//echo "UserID : ".$rowcountCek;
		//echo $rowCek['flagLogin'];
		if ($rowcountCek > 0)
		{
			if($rowCek['flagFirst'] == 1)
			{
				$userID = $rowCek['userID'];
				if($rowCek['status'] == 'Active')
				{	
					$_SESSION['userID'] = $userID;
					$_SESSION['username'] = $username;
					$_SESSION['usergroup'] = $rowCek['usergroup'];
					$_SESSION['idVendor'] = $rowCek['idVendor'];
					header("Location:index.php");
				}
				elseif($rowCek['status'] == 'Inactive')
				{
					header("Location:login.php?flag=inactive");		
				}
			}
			elseif($rowCek['flagFirst'] == 0)
			{
				$_SESSION['userID'] = $userID;
				$_SESSION['username'] = $username;
				$_SESSION['password'] = $password;
				$_SESSION['usergroup'] = $rowCek['usergroup'];
				$_SESSION['idVendor'] = $rowCek['idVendor'];
				header("Location:login_confm.php");
			}
		}
		elseif($rowcountCek == 0)
		{
			$queryCC = "select userID
					from asset_login 
					where upper(username) = upper('".$username."')";
			$resultCC = mysql_query($queryCC);
			$numrowCC = mysql_num_rows($resultCC);
			$rowCC = mysql_fetch_array($resultCC);
			if($numrowCC > 0)
			{
				$userID = $rowCC['userID'];
			}
            
			header("Location:login.php?flag=wrong");
		}
	}
	elseif(isset($_POST['cmdFirstLogin']))
	{
		$username = $_POST['username'];
		$newPassword = $_POST['newPassword'];
		$confirmPassword = $_POST['confirmPassword'];
		$queryCC = "select userID,usergroup,idVendor
					from asset_login 
					where upper(username) = upper('".$username."')
					and status = 'Active'";
		$resultCC = mysql_query($queryCC);
		$rowCC = mysql_fetch_array($resultCC);
		$userID = $rowCC['userID'];
		$usergroup = $rowCC['usergroup'];
		$idVendor = $rowCC['idVendor'];
		
		$password = md5($newPassword);
		
		//Update password and flagFirst
		$queryU = "update asset_login
					set password = '".$password."',
					flagFirst = 1
					where userID = ".$userID;
		$resultU = mysql_query($queryU);
		if($resultU)
		{
			$_SESSION['userID'] = $userID;
			$_SESSION['username'] = $username;
			$_SESSION['usergroup'] = $usergroup;
			$_SESSION['idVendor'] = $idVendor;
			header("Location:index.php");
		}
	}
?>
