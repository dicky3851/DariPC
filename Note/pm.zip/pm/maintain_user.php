<?php
    include('header.php');
?>

<link rel="stylesheet" type="text/css" href="css/MainDataTables.css"/>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>

<script type="text/javascript">
	jQuery(function($) {
		var listTable = 
			$('#employeeList')
				.dataTable({					
					"columnDefs": [
								{"orderable":false,"targets":[-1]},
								{"width":"20%","targets":[1,3]}
							],
					"language": {
								"lengthMenu": "Display _MENU_ records",
								 "info": "Showing _START_ to _END_ of _TOTAL_ records",
						  },
					});
	});
</script>

<script>
	function validate_form1()
	{	
		if(document.form_1.username.value.length == 0)
		{
			alert('Username is mandatory');
			document.form_1.username.focus();
			return false;
		}
		if(document.form_1.oriname.value.length == 0)
		{
			alert('Original Name is mandatory');
			document.form_1.oriname.focus();
			return false;
		}
		if(document.form_1.email.value.length == 0)
		{
			alert('Email Address is mandatory');
			document.form_1.email.focus();
			return false;
		}
		if(!isValidEmail(document.form_1.email.value))
		{
			alert('Invalid Email Address');
			document.form_1.email.focus();
			return false;
		}
        
        return true;
    }
    
    function IsNumeric(sText)
	{
		var ValidChars = "0123456789,.";
		var IsNumber = true;
		var Char;
		for(i=0;i<sText.length&&IsNumber==true;i++)
		{
			Char=sText.charAt(i);
			if(ValidChars.indexOf(Char) == -1)
			{
				IsNumber = false;
			}
		}
		return IsNumber;
	}
	
	function isValidEmail(strEmail)
	{
	  validRegExp = /^[^@]+@[^@]+.[a-z]{2,}$/i;
	  /*strEmail = document.form_1.email.value;*/
					
	   // search email text for regular exp matches
		if (strEmail.search(validRegExp) == -1) 
	   	{
		  return false;
		}
		else
		{ 
			return true;
		} 
	}
</script>

	<body>
		<div class="header" id="home">
            
			<?php
				include('menu.php');
			?>
			
		</div>
		
		<div class="basicFrame backgroundGray">
			<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5 fontSize11">
				User Management
			</div>
        
        <?php
            if(isset($_POST['cmdSubmit']))
            {
                $username_C = $_POST['username'];
                $usergroup_C = $_POST['usergroup'];
				$idVendor = $_POST['idVendor'];
                
                $username_C = strtoupper(str_replace("'","",$username_C));
				//$email_C = str_replace("'","",$email_C);
				
			?>
				<div class="col100 backgroundWhite padding15 marginBottom10">
					<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
						Process Result
					</div>
					
					<?php
						//Cek Duplicate
						$queryC = "select userID from asset_login where upper(username) = '".$username_C."'";
						$resultC = mysql_query($queryC);
						$numrowC = mysql_num_rows($resultC);
						
						if($numrowC == 0)
						{
							$password = md5("123");
							
							//Insert here
							$queryI = "insert into asset_login
										(username,password,usergroup,status,flagFirst,idVendor)
										select '".$username_C."','".$password."','".$usergroup_C."','Active',0,".$idVendor;
							$resultI = mysql_query($queryI);
							//echo $queryI."<br>";
							if($resultI)
							{
							?>
								<div class="col100 textBold marginBottom10">
									Input User successfully completed
								</div>
							<?php
							}
							else
							{
							?>
								<div class="col100 textBold marginBottom10 colorRed">
									Input User failed completed
								</div>
							<?php
							}
						}
						else
						{
						?>
							<div class="col100 textBold marginBottom10 colorRed">
								Duplicate Nama User, please check on table list user
							</div>
						<?php	
						}
					?>
				</div>
			<?php
            }
        ?>
        
        <?php
            if(isset($_POST['cmdEdit']))
            {
				$userID_C = $_POST['userID_C'];
                $username_C = $_POST['username'];
                $usergroup_C = $_POST['usergroup'];
				$status = $_POST['status'];
				$idVendor = $_POST['idVendor'];
                
                $username_C = strtoupper(str_replace("'","",$username_C));
				
			?>
				<div class="col100 backgroundWhite padding15 marginBottom10">
					<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
						Process Result
					</div>
					
					<?php
						//Cek Duplicate
						$queryC = "select userID from asset_login where upper(username) = '".$username_C."' AND userID <> ".$userID_C;
						$resultC = mysql_query($queryC);
						$numrowC = mysql_num_rows($resultC);
						
						if($numrowC == 0)
						{		
							//Insert here
							$queryI = "update asset_login
										set username = '".$username_C."',
										usergroup = '".$usergroup_C."',
										status = '".$status."',
										idVendor = ".$idVendor."
										where userID = ".$userID_C;
							$resultI = mysql_query($queryI);
							//echo $queryI."<br>";
							if($resultI)
							{
							?>
								<div class="col100 textBold marginBottom10">
									Edit User successfully completed
								</div>
							<?php
							}
							else
							{
							?>
								<div class="col100 textBold marginBottom10 colorRed">
									Edit User successfully completed
								</div>
							<?php
							}
						}
						else
						{
						?>
							<div class="col100 textBold marginBottom10 colorRed">
								Duplicate username, please check on table list user
							</div>
						<?php	
						}
					?>
				</div>
			<?php
            }
        ?>
		
		<?php
            if(isset($_POST['cmdReset']))
            {
                $userID_C = $_POST['userID_C'];
				
				$password = md5("123");
				
			?>
				<div class="col100 backgroundWhite padding15 marginBottom10">
					<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
						Process Result
					</div>
			<?php
				
				//Update here
				$queryI = "update asset_login
							set password = '".$password."',
							flagFirst = '0',
							status = 'Active'
							where userID = ".$userID_C;
				$resultI = mysql_query($queryI);
				//echo $queryI."<br>";
				if($resultI)
				{
				?>
					<div class="col100 textBold marginBottom10">
						Reset Password User successfully completed
					</div>
				<?php
				}
				else
				{
				?>
					<div class="col100 textBold marginBottom10 colorRed">
						Reset Password User failed completed
					</div>
				<?php
				}
			?>
				</div>
			<?php
            }
        ?>
        
        <?php
            if(isset($_GET['userID_C']))
            {
                $userID_C = $_GET['userID_C'];
                
                $queryP = "select userID,username,password,usergroup,status,idVendor
							from asset_login
							where userID = ".$userID_C;
                $resultP = mysql_query($queryP);
                $rowP = mysql_fetch_array($resultP);
				//echo $queryP."<br>";
				
				$username_C = $rowP['username'];
				$usergroup_C = $rowP['usergroup'];
				$status = $rowP['status'];
				$password_C = $rowP['password'];
				$idVendor = $rowP['idVendor'];
            }
			else
			{
				$username_C = "";
				$usergroup_C = "";
				$status = "";
				$idVendor = 0;
			}
        ?>
			
			<div class="col100 backgroundWhite padding15 marginBottom10">
				<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
					Manage
				</div>
				
				<div class="col100 marginTop20">
					<form name="form_1" action="maintain_user.php" method="post" onsubmit="return validate_form1()">
					<?php
						if(isset($_GET['userID_C']))
						{
						?>
							<input type="hidden" name="userID_C" value="<?php echo $userID_C ?>">
						<?php
						}
					?>
						<div class="col20 floatLeft textBold paddingTop5 marginBottom10">Username</div>
						<div class="col30 floatLeft paddingRight20">
							<input type="text" name="username" class="textinputbasic marginBottom10" value="<?php echo $username_C ?>">
						</div>
						<div class="margine"></div>
						
						<!--<div class="col20 floatLeft textBold paddingTop5 marginBottom10">Email Address</div>
						<div class="col30 floatLeft paddingRight20">
							<input type="text" name="email" class="textinputbasic marginBottom10" value="<?php echo $email ?>">
						</div>
						
						<div class="margine"></div>-->
						
						<?php
							//$queryUG = "select idgroup,usergroup from usergroup where 1 > 0 and usergroup not in ('Administrator') order by usergroup";
							//$resultUG = mysql_query($queryUG);
						?>
						
						<div class="col20 floatLeft textBold paddingTop5 marginBottom10">Usergroup</div>
						<div class="col30 floatLeft paddingRight20">
							<select name="usergroup" class="selectinputbasic paddingBottom5 paddingTop5 fontSize09">
								<option value="Administrator" <?php echo $usergroup_C == "Administrator"?"selected":"" ?>>Administrator</option>
								<option value="Asset" <?php echo $usergroup_C == "Asset"?"selected":"" ?>>Asset</option>
								<option value="Posko" <?php echo $usergroup_C == "Posko"?"selected":"" ?>>Posko</option>
								<option value="Vendor" <?php echo $usergroup_C == "Vendor"?"selected":"" ?>>Vendor</option>
								<option value="Bisnis" <?php echo $usergroup_C == "Bisnis"?"selected":"" ?>>Bisnis</option>
							</select>
						</div>
						<div class="margine"></div>
						
						<?php
							$queryAL = "select idVendor,vendor
										from vendor
										where 1 > 0
										order by idVendor";
							$resultAL = mysql_query($queryAL);
						?>
						
						<div class="col20 floatLeft marginBottom10 marginTop5 textBold">Vendor Name</div>
						<div class="col30 floatLeft paddingRight20">
							<select name="idVendor" class="selectinputbasic paddingBottom5 paddingTop5 fontSize09">
								<option value="0">--- Select Vendor ---</option>
							<?php
								while($rowAL = mysql_fetch_array($resultAL))
								{
								?>
									<option value="<?php echo $rowAL['idVendor'] ?>" <?php echo $idVendor == $rowAL['idVendor']?"selected":"" ?>><?php echo $rowAL['vendor'] ?></option>
								<?php
								}
							?>
							</select>
						</div>
						<div class="col30 floatLeft paddingRight20 paddingTop5 fontSize09">
							Just for usergroup Vendor
						</div>
						<div class="margine"></div>
						
						<?php
							if(isset($_GET['userID_C']))
							{
							?>
								<div class="col20 floatLeft textBold paddingTop5 marginBottom10">Status</div>
								<div class="col30 floatLeft paddingRight20">
									<select name="status" class="selectinputbasic paddingBottom5 paddingTop5 fontSize09">
										<option value="Active" <?php echo $status == "Active"?"selected":"" ?>>Active</option>
										<option value="Inactive" <?php echo $status == "Inactive"?"selected":"" ?>>Inactive</option>
									</select>
								</div>
								<div class="margine"></div>
							<?php
							}
						?>
						
						<div class="margine10b"></div>
						
						<div class="col100">
						<?php
							if(!isset($_GET['userID_C']))
							{
							?>
								<input type="submit" name="cmdSubmit" value="Submit User" class="styleButtonMiddle">
							<?php
							}
							elseif(isset($_GET['userID_C']))
							{
							?>
								<div class="col10 floatLeft marginRight1"><input type="submit" name="cmdEdit" class="styleButtonMiddle" value="Edit Data"></div>
								<div class="col15 floatLeft marginRight1"><input type="submit" name="cmdReset" class="styleButtonMiddle" value="Reset Password"></div>
								<div class="margine"></div>
							<?php
							}
						?>
						</div>
						
						<div class="margine2"></div>
					</form>
				</div>
			</div>
			
			<div class="col100 backgroundWhite padding15">
				<div class="col100 marginAuto textBold marginTop5 marginBottom20 colorBlue2 borderBottomColorGrey2 textUpper paddingBottom5">
					List User
				</div>
				
				<?php
					$queryD = "select a.userID,a.username,a.usergroup,a.status,b.vendor
								from asset_login a
								left join vendor b on a.idVendor = b.idVendor
								where a.username <> 'Chamber' order by a.username";
					$resultD = mysql_query($queryD);
					$no = 1;
				?>
				
				<table class="content">
					<tr>
						<th class="content textCenter fontSize09">No</th>
						<th class="content textCenter fontSize09">Username</th>
						<th class="content textCenter fontSize09">Usergroup</th>
						<th class="content textCenter fontSize09">Vendor</th>
						<th class="content textCenter fontSize09">Status</th>
					</tr>
					<?php
						while($rowD = mysql_fetch_array($resultD))
						{
							$userID_C = $rowD['userID'];
						?>
						<tr class="linkClick" onclick="window.location='maintain_user.php<?php echo "?userID_C=".$userID_C ?>'">
							<td class="viewData col5 textCenter fontSize09"><?php echo $no ?></td>
							<td class="viewData fontSize09"><?php echo $rowD['username'] ?></td>
							<td class="viewData fontSize09"><?php echo $rowD['usergroup'] ?></td>
							<td class="viewData fontSize09"><?php echo $rowD['vendor'] ?></td>
							<td class="viewData fontSize09"><?php echo $rowD['status'] ?></td>
						</tr>
						<?php
							$no++;
						}
						?>
				</table>
			</div>
			
			<div class="margine"></div>
		</div>
	</div>
	
	
	<?php
		include('footer.php');
	?>
	</body>
</html>