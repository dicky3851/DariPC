<!doctype html>
<html>




<?php
	include("connect_db.php");
?>

<body>

		
		<?php
			$queryLV = "select idvendor,vendor from vendor order by vendor";
			$resultLV = mysql_query($queryLV);
			
			while($rowLV = mysql_fetch_array($resultLV))
			{
				$vendor = $rowLV['vendor'];
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Open Schedule' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$OpenSchedule = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Pending Customer' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$PendingCustomer = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Send Back to Vendor' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$SendBacktoVendor = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Send Back to Asset' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$SendBacktoAsset = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Pending Vendor' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$PendingVendor = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Re-mapping' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$reMapping = floatval($rowD['jml']);
				
				$queryD = "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Close Completed' and vendor = '".$vendor."'";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$CloseCompleted = floatval($rowD['jml']);
				
				$queryD =  "SELECT COUNT(*) AS 'jml'
							FROM asset_mapping
							WHERE statusAsset = 'Close Completed' and vendor = '".$vendor."'
							and updateDT = date_format(now(),'%Y-%m-%d')";
				$resultD = mysql_query($queryD);
				//echo $queryD."<br><br>";
				$rowD = mysql_fetch_array($resultD);
				$CloseCompletedToday = floatval($rowD['jml']);
			?>
				
				<div class="mySlidesTop1 mySlidesTop2 w3-container w3-red">
					<div class="col80 marginAuto backgroundWhite borderColorGrey">
						<div class="col100 textBold marginBottom20 textCenter fontSize2 paddingTop1 paddingBottom1 backgroundBlue3 colorWhite textSpacing5">
							<center><?php echo $vendor ?></center>
						</div>
						<div class="margine"></div>
						
						<div class="col45 marginAuto floatLeft padding20 fontSize13 fontFamily13">
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Open Schedule</div>
								<div class="col35 floatLeft textRight"><?php echo $OpenSchedule ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Send Back to Vendor</div>
								<div class="col35 floatLeft textRight"><?php echo $SendBacktoVendor ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Send Back to Asset</div>
								<div class="col35 floatLeft textRight"><?php echo $SendBacktoAsset ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Pending Customer</div>
								<div class="col35 floatLeft textRight"><?php echo $PendingCustomer ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Pending Vendor</div>
								<div class="col35 floatLeft textRight"><?php echo $PendingVendor ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Re-mapping</div>
								<div class="col35 floatLeft textRight"><?php echo $reMapping ?></div>
								
								<div class="margine"></div>
							</div>
							
							<div class="col100 marginBottom20">
								<div class="col60 floatLeft">Total Close Completed</div>
								<div class="col35 floatLeft textRight"><?php echo $CloseCompleted ?></div>
								
								<div class="margine"></div>
							</div>
						</div>
						
						<div class="col45 marginAuto floatLeft padding20 textCenter">
							<div class="col100 marginBottom10">
								<div class="col100 marginBottom2 fontSize2 textBold colorBlue2 fontFamily13"><center>Today Close Completed
										<div class="margine"></div>
											
											   <?php
													$tanggal= mktime(date("m"),date("d"),date("Y"));
													echo " <b>".date("d-M-Y", $tanggal)."</b> ";
													date_default_timezone_set('Asia/Jakarta');
													$jam=date("H:i:s");
													echo "| <b>". $jam." "."WIB</b>";
													$a = date ("H");
													if (($a>=6) && ($a<=11)){
													}
													?> 
											
								</center></div>
								<?php
									if($CloseCompletedToday == 0)
										$styleColor = "colorRed";
									else
										$styleColor = "colorBlue";
								?>
								
								<div class="col100 fontSize8 textBold fontFamily3 marginBottom20 <?php echo $styleColor ?>"><center><?php echo $CloseCompletedToday ?></center></div>
								
								
							</div>
									
           
						</div>
						
						   
						
						<div class="margine"></div>
						
					</div>
							
					<div class="margine"></div>
				</div>
			<?php
			}
		?>
		
		<div class="margine"></div>
		
	</div>
	
	
	
</body>

</html>
