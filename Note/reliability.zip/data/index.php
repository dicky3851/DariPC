<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<?php
	include('../connect_db.php');
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Yokke : Reliability Monitoring</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Startup Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/style2.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=devanagari,latin-ext"
	 rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>
	<!-- main banner -->
	<div class="main-top" id="home">
		<!-- header -->
		<header>
			<div class="container-fluid">
				<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
					<!-- logo -->
					<div id="logo">
						<h1><a href="#"><span class="fa fa-linode mr-2"></span>YOKKE</a></h1>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu">
								<li><a href="../index.php" class="active">Home</a></li>
								<!--<li><a href="about.html">About Us</a></li>
								<li><a href="pricing.html">Pricing</a></li>
								<li>
									<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="#services" class="drop-text">Services</a></li>
										<li><a href="faq.html" class="drop-text">Faq's</a></li>
										<li><a href="404.html" class="drop-text">404</a></li>
										<li><a href="#stats" class="drop-text">Statistics</a></li>
										<li><a href="about.html" class="drop-text">Why Choose Us?</a></li>
										<li><a href="about.html" class="drop-text">Our Team</a></li>
										<li><a href="#partners" class="drop-text">Partners</a></li>
									</ul>
								</li>
								<li><a href="contact.html">Contact Us</a></li>-->
							</ul>
						</nav>
					</div>
					<!-- //nav -->
					<div class="d-flex mt-lg-1 mt-sm-2 mt-3 justify-content-center">
						<!-- search -->
						<!--<div class="search-w3layouts mr-3">
							<form action="#" method="post" class="search-bottom-wthree d-flex">
								<input class="search" type="search" placeholder="Merchant Parameter" required="">
								<button class="form-control btn" type="submit"><span class="fa fa-search"></span></button>
							</form>
						</div>-->
						<!-- //search -->
						<!-- download -->
						<!--<a class="dwn-w3ls btn" href="http://w3layouts.com/" target="_blank">
							<span class="fa fa-cloud-download"></span>
						</a>-->
						<!-- //download -->
					</div>
				</div>
			</div>
		</header>
		<!-- //header -->

		<!-- banner -->
		<!--<div class="banner_w3lspvt position-relative">
			<div class="container">
				<div class="d-md-flex">
					<div class="w3ls_banner_txt">
						<h3 class="w3ls_pvt-title">Business <br><span>Startup</span></h3>
						<p class="text-sty-banner">Sed ut perspiciatis unde omnis iste natus doloremque
							laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi.</p>
						<a href="about.html" class="btn button-style mt-md-5 mt-4">Read More</a>
					</div>
					<div class="banner-img">
						<img src="images/banner.png" alt="" class="img-fluid">
					</div>
				</div>
			</div>
			<div class="icon-effects-w3l">
				<img src="images/shape1.png" alt="" class="img-fluid shape-wthree shape-w3-one">
				<img src="images/shape2.png" alt="" class="img-fluid shape-wthree shape-w3-two">
				<img src="images/shape3.png" alt="" class="img-fluid shape-wthree shape-w3-three">
				<img src="images/shape5.png" alt="" class="img-fluid shape-wthree shape-w3-four">
				<img src="images/shape4.png" alt="" class="img-fluid shape-wthree shape-w3-five">
				<img src="images/shape6.png" alt="" class="img-fluid shape-wthree shape-w3-six">
			</div>
		</div>-->
		<!-- //banner -->
	</div>
	<!-- //main banner -->
	
	<!-- stats -->
	
	<?php
		if(isset($_GET['idResult']))
		{
			$idResult = $_GET['idResult'];
			
			//Query data
			$querySD = "select idResult,a.tid,a.mid,c.edctype,c.serial,c.acquirer,c.sla,c.vendor,c.connection,
						b.merchant,b.merchantAddr
						from mon_result a
						inner join mon_mid b on a.idMerchant = b.idMerchant
						inner join mon_tid c on a.idTID = c.idTID
						where 1 > 0
						and a.idResult = ".$idResult;
			$resultSD = mysql_query($querySD);
			//echo $querySD."<br>";
			$numrowSD = mysql_num_rows($resultSD);
			$rowSD = mysql_fetch_array($resultSD);
		?>
			<section class="bottom-count py-5" id="stats">
				<div class="frameBasic">
					<div class="title">Merchant Tracking</div>
					
				<?php
					if($numrowSD > 0)
					{
					?>
						<div class="frameResultData">
							<div class="frameData">
								<div class="titleData">TID Number</div>
								<div class="infoData"><?php echo $rowSD['tid'] ?></div>
							</div>
							
							<div class="frameData">
								<div class="titleData">MID Number</div>
								<div class="infoData"><?php echo $rowSD['mid'] ?></div>
							</div>
							
							<div class="frameData">
								<div class="titleData">EDC Type</div>
								<div class="infoData"><?php echo $rowSD['edctype'] ?></div>
							</div>
							
							<div class="frameData">
								<div class="titleData">Serial Number</div>
								<div class="infoData"><?php echo $rowSD['serial'] ?></div>
							</div>
							
							<div class="margine"></div>
							
							<div class="frameData">
								<div class="titleData">Merchant</div>
								<div class="infoData"><?php echo $rowSD['merchant'] ?></div>
							</div>
							
							<div class="frameData2">
								<div class="titleData">Address</div>
								<div class="infoData"><?php echo $rowSD['merchantAddr'] ?></div>
							</div>
							
							<div class="margine"></div>
							
							<div class="frameData">
								<div class="titleData">Acquirer</div>
								<div class="infoData"><?php echo $rowSD['acquirer'] ?></div>
							</div>
																			
							
							<div class="frameData">
								<div class="titleData">Connection</div>
								<div class="infoData"><?php echo $rowSD['connection'] ?></div>
							</div>
							
											
						<div class="frameData">
								<div class="titleData">JO</div>
								<div class="infoData"><?php echo $rowSD['vendor'] ?></div>
							</div>
							
							<div class="margine"></div>
						</div>
						
						<div class="frameResultData2">
							<div class="statusTitle">Status</div>
							
							<div class="statusResult colorRed">
								STATUS PEMASANGAN DONE
							</div>
							
							<div class="statusTitle">Action Tracking</div>
						<?php
							$queryLA = "select idDetail,date_format(actionDT,'%d/%m/%Y') as 'actionDT',detail,remarks
										from mon_result_detail
										where idResult = ".$idResult." and detailStatus = 1
										order by idDetail desc";
							$resultLA = mysql_query($queryLA);
							
							echo "<ul class='timeline'>";
							
							$class = "class='first'";
							while($rowLA = mysql_fetch_array($resultLA))
							{
							?>
								<li <?php echo $class ?>>
									<a href='#'><?php echo $rowLA['actionDT'] ?></a>
									<!-- <a href='#' class='float-right'>21 March, 2014</a> -->
									<p><?php echo $rowLA['detail'] ?></p>
									<p><?php echo $rowLA['remarks'] ?></p>
								</li>
								
								
							<?php
								$class = "";
							}
							echo "</ul>";
						
							while(1==0)
							{
							?>
								<div class="frameDataDetail">
									<div class="titleData"><?php echo $rowLA['actionDT'] ?></div>
									<div class="infoDataDetail">
										<?php echo $rowLA['detail'] ?>
										<div class="margine"></div>
										<?php echo $rowLA['remarks'] ?>
									</div>
								</div>
								
								<div class="margine"></div>
							<?php
							}
						?>
						</div>
					<?php
					}
					elseif($numrowSD == 0)
					{
					?>
						<div class="frameResultData2">
							<!--<div class="statusTitle">Status</div>-->
							
							<div class="statusResult colorRed">
								No Merchant data in system
							</div>
						</div>
					<?php
					}
				?>
					
					
				</div>
			</section>
		<?php
		}
	?>
	
	<?php
		if(isset($_POST['field']))
		{
			$field = $_POST['field'];
			
			$field = str_replace("'","",$field);
			
			//Search here
			$querySM = "select idResult,a.tid,a.mid,c.edctype,c.serial,c.acquirer,c.sla,c.vendor,c.connection,
						b.merchant,b.merchantAddr
						from mon_result a
						inner join mon_mid b on a.idMerchant = b.idMerchant
						inner join mon_tid c on a.idTID = c.idTID
						where 1 > 0
						and (b.merchant like '%".$field."%' or a.mid = '".$field."' or a.tid = '".$field."')
						and a.caseStatus in ('Open')";
			$resultSM = mysql_query($querySM);
			//echo $querySM."<br>";
		    $numrowSM = mysql_num_rows($resultSM);
			
		?>
			<section class="bottom-count py-5" id="stats">
				<div class="frameBasic">
					<div class="title">Merchant Tracking</div>
					
				<?php
					if($numrowSM > 0)
					{
					?>
						<div class="frameResultData2">
							<div class="statusTitle">List of TID Merchant</div>
						<?php
							while($rowSM = mysql_fetch_array($resultSM))
							{
								$idResult = $rowSM['idResult'];
							?>
								<div class="statusResult">
									<div class="linkClick" onclick="window.location='index.php<?php echo "?idResult=".$idResult ?>'"><?php echo "TID ".$rowSM['tid']." (".$rowSM['merchant'].")" ?></div>
								</div>
							<?php
							}
						?>
						</div>
					<?php
					}
					elseif($numrowSM == 0)
					{
					?>
						<div class="frameResultData2">
							<!--<div class="statusTitle">Status</div>-->
							
							<div class="statusResult colorRed">
								No Merchant data in system or no case open if this merchant in system
							</div>
						</div>
					<?php
					}
				?>
				
				</div>
			</section>
		<?php
		}
	?>
	
	<!-- //footer -->
	<!-- copyright bottom -->
	<div class="copy-bottom bg-li py-4 border-top">
		<div class="container-fluid">
			<div class="d-md-flex px-md-3 position-relative text-center">
				<!-- footer social icons -->
				
				<!-- copyright -->
				<div class="copy_right mx-md-auto mb-md-0 mb-3">
					<p>&copy; 2020 Designed and Developed by Enda_kytaro</p>
				</div>
				<!-- //copyright -->
				<!-- move top icon -->
				<a href="#home" class="move-top text-center">
					<span class="fa fa-level-up" aria-hidden="true"></span>
				</a>
				<!-- //move top icon -->
			</div>
		</div>
	</div>
	<!-- //copyright bottom -->

</body>

</html>