<?php
	//For localhost
	//$server = 'localhost';
	//mysql_connect($server,'root','hoshiko06',true,65536);
	//mysql_query('use chaz2513_yokkereability');
	
	//For Hosting
	mysql_connect($server,'opef1643_reliability','Hoshiko06');
	mysql_select_db('opef1643_reliability');
?>
