<?php

$host = 'localhost';
mysql_connect($host,'root','',true);
mysql_query('use protaps');

?>