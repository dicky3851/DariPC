<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <!-- CSS URL -->
    <link rel="stylesheet" href="../assets/css/main.css">
</head>
<body>
<?php    
// memanggil library FPDF
include '../koneksi.php'; 
?>
    <?php
        $idProtap = $_GET["idProtap"];
        $no = 1;
        $querySD = "select idProtap,merchant,alamat,mid_mti,tid_mti,alamat,provider,vendor,
                    type_edc,aom,hasil_pm,history_case,last_trx,sv_settle
                    from protap_data
                    where idProtap = ".$idProtap;

                    //echo $querySD ."<br/>";
        $resultSD = mysql_query($querySD) or die(mysql_error());

        while($d = mysql_fetch_array($resultSD))
        {
            ?>
               <img src="Yokke.png" alt="Logo">
                <div class="container">
                    <div class="row">
                        <h1 class="text-center fs-2">Laporan Data Protap</h1>
                        <p>Berikut hasil pengecekan data merchant : </p>
                        <hr/>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">MID_MTI</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['mid_mti'] ?></p>
                        </div>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">TID_MTI</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['tid_mti'] ?></p>
                        </div>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">Merchant</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['merchant'] ?></p>
                        </div>
                        <hr/>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">Alamat</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['alamat'] ?></p>
                        </div>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">Provider</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['provider'] ?></p>
                        </div>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">Vendor</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['vendor'] ?></p>
                        </div>
                        <hr/>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">Type EDC</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['type_edc'] ?></p>
                        </div>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">AOM</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['aom'] ?></p>
                        </div>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">Hasil PM</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['hasil_pm'] ?></p>
                        </div>
                        <hr/>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">History Case ID</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['history_case'] ?></p>
                        </div>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">Last Trx</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['last_trx'] ?></p>
                        </div>
                        <div class="col-12 col-md-3 col-sm-12">
                            <h4 class="ff-3 fs-4 fw-normal">SV Settle</h4>
                            <p class="ff-3 fs-6 fw-normal"><?php echo $d['sv_settle'] ?></p>
                        </div>

                    </div>
                </div>
            <?php
        }
    ?>
<script>
    window.print();
</script>
</body>
</html>

