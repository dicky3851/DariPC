<!-- 
    Author : Giri Diwa Adam
    Author URL : -
    License :Open Source
    Date : 15-03-2023 
 -->
<?php
  include('../koneksi.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Protap : Data Monitoring</title>
<!-- Bootstrap -->
<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
<!-- CSS URL -->
<link rel="stylesheet" href="../assets/css/main.css">
<!-- JS -->
<script type="application/x-javascript">
    addEventListener("load", function(){
        setTimeout(hiddenURLbar, 0);
    }, false);

    function hideURLbar(){
        window.scrollTo(0, 1);
    }
</script>
</head>
<body>
<header id="header-utama">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container-fluid">
        <a class="navbar-brand" href="../index.php"><img src="../assets/img/Yokke.png" class="img-fluids"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarColor01">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link active" href="../index.php"><i class="bi bi-house-door"></i> Home
                <span class="visually-hidden">(current)</span>
              </a>
            </li>
        </div>
      </div>
    </nav>
</header>
<?php
    if(isset($_GET['idProtap']))
    {
        $idProtap = $_GET['idProtap'];
        
        //Query Data
        $querySD = "select idProtap,merchant,alamat,mid_mti,tid_mti,provider,vendor,type_edc,aom,last_trx,
                    history_case,hasil_pm,sv_settle
                    from protap_data 
                    where 1 > 0
                    and idProtap = ".$idProtap;
        $resultSD = mysql_query($querySD) or die(mysql_error());
        //echo $querySD."<br>";
        $numrowSD = mysql_num_rows($resultSD);
        $rowSD = mysql_fetch_array($resultSD);
    ?>
        <div class="container">
            <div class="row">
                <p class="text-center fs-2 ff-3 fw-normal mb-4">Protap Tracking</p>
                <p class="text-left fs-5 ff-4 fw-normal pt-4">Berikut hasil pengecekan data merchant : </P>
            </div>
            <?php
                if($numrowSD > 0)
                {
                ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2"">MID MTI</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['mid_mti'] ?></p>
                            </div>
                            <div class="col-12 col-md-3 col-sm-12 mb-2"">
                                <div class="fw-normal ff-3 fs-4 mb-2"">TID MTI</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['tid_mti'] ?></p>
                            </div>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2">Merchant</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['merchant'] ?></p>
                            </div>
                            <hr/>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2"">Alamat</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['alamat'] ?></p>
                            </div>
                           
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2"">Provider</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['provider'] ?></p>
                            </div>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2"">Vendor</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['vendor'] ?></p>
                            </div>
                            <hr/>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2">Type EDC</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['type_edc'] ?></p>
                            </div>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2">AOM</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['aom'] ?></p>
                            </div>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2">Hasil PM</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['hasil_pm'] ?></p>
                            </div>
                            <hr/>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2">History Case ID</div>
                                <p class="fw-normal ff-3"><?php echo $rowSD['history_case'] ?></p>
                            </div>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2">Last TRX</div>
                                <?php
                                    $data = mysql_query("select idProtap,last_trx from protap_data WHERE idProtap =".$idProtap) or die(mysql_error());
                                    $no = 1;
                                    while($d = mysql_fetch_array($data))
                                    {
                                        ?>
                                            <ul class="list-group">
                                                <td><p class="ff-3 fs-6"><?php echo $rowSD['last_trx'] ?><br/> </p></td>
                                            </ul>
                                        <?php
                                    }
                                ?>
                            </div>
                            <div class="col-12 col-md-3 col-sm-12">
                                <div class="fw-normal ff-3 fs-4 mb-2"">SV Settle</div>
                                <?php
                                    $data = mysql_query("select idProtap,sv_settle from protap_data WHERE idProtap =".$idProtap) or die(mysql_error());
                                    $no = 1;
                                    while($d = mysql_fetch_array($data))
                                    {
                                        ?>
                                            <ul class="list-group"> 
                                                <td><p class="ff-3 fs-6"><?php echo $rowSD['sv_settle'] ?></p></td>
                                            </ul>
                                        <?php
                                    }
                                ?>
                            </div>
                        </div>
                        <hr/>
                        <p class="fw-bolder ff-3 fs-4">Export Data To : </p> <button onclick="window.open('excelreport.php<?php echo "?idProtap=".$idProtap ?>','_blank')" target="_blank" class="btn btn-success"> <i class="bi bi-printer-fill"></i> EXCEL</button> | <button type="button" onclick="window.open('pdfreport.php<?php echo "?idProtap=".$idProtap ?>','_blank')" class="btn btn-primary"><i class="bi bi-printer-fill"></i> PDF</button>
                    </div>
                <?php
                }
            ?>
        </div>
    <?php
    }
?>
<?php
    if(isset($_POST['field']))
    {
        $field = $_POST['field'];

        $field = str_replace("'","",$field);

        //Query Search
        $querySM = "select idProtap,merchant,alamat,mid_mti,tid_mti,provider,vendor,type_edc,
                    aom,hasil_pm,history_case,last_trx,sv_settle
                    from protap_data 
                    where 1 > 0
                    and (merchant like '%".$field."%' or mid_mti = '".$field."' or tid_mti = '".$field."')";
        $resultSM = mysql_query($querySM) or die(mysql_error());
        //echo $querySM."<br>";
        $numrowSM = mysql_num_rows($resultSM);
    ?>
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-sm-12">
                    <p class="text-center fw-normal ff-3 fs-3">Protap Search</p>
                </div>

                <?php
                    if($numrowSM > 0)
                    {
                        ?>
                          <div class="container">
                            <div class="row">
                                <div class="col-12 col-md-12 col-sm-12">
                                    <p class="text-center ff-4 fw-normal">List Of TID Protap</p>
                                    <?php
                                        while($rowSM = mysql_fetch_array($resultSM))
                                        {
                                            $idProtap = $rowSM['idProtap'];
                                        ?>
                                            <div class="row">
                                                <a class="fw-normal ff-3 alert alert-primary " role="alert" onclick="window.location='index.php<?php echo "?idProtap=".$idProtap?>'"><?php echo $rowSM['merchant']?> </a>
                                            </div>
                                        <?php
                                        }
                                    ?>
                                </div>
                            </div>
                          </div>
                        <?php
                    }
                    elseif($numrowSM == 0)
                    {
                    ?>
                    <div class="row justify-content-center">
                        <div class="col-12 col-md-5 col-sm-12">
                            <div class="alert alert-danger" role="alert">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-triangle-fill" viewBox="0 0 16 16">
                                    <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                                </svg> No Merchant Data !
                                    <br/>
                                    <a href="../index.php" class="btn btn-secondary">Back To Home</a>
                            </div>
                        </div>
                    </div>
                    <?php
                    }
                ?>
            </div>
        </div>

    <?php
    }
?>

<!-- Footer -->
<div class="container xxl-2">
    <div class="row justify-content-center">
        <div class="col-12 col-md-12 col-sm-12">
            <p class="text-center">&copy; Designed And Developed By Giri Diwa Adam</p>
        </div>
    </div>
</div>
<!-- JS -->
<script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>