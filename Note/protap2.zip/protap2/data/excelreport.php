<?php
 include ('../koneksi.php');
 //<!-- File Name -->
 header("Content-type: application/vnd-ms-excel");
 header("Content-Disposition: attachment; filename=Report_Protap.xls")

	
?>

<table border="1">
    <tr>
        <th>No</th>
        <th>Merchant</th>
        <th>Alamat</th>
        <th>MID MTI</th>
        <th>TID MTI</th>
        <th>Provider</th>
        <th>Vendor</th>
        <th>TYPE EDC</th>
        <th>AOM</th>
        <th>Last TRX</th>
        <th>History Case ID</th>
        <th>Hasil PM</th>
        <th>SV Settle</th>
    <tr>
    
    <?php
        $idProtap = $_GET['idProtap'];
        //menampilkan data di protap_data
        $queryMD ="select idProtap,merchant,alamat,mid_mti,tid_mti,provider,vendor,type_edc,
                   aom,last_trx,history_case,hasil_pm,sv_settle
                   from protap_data
                   where idProtap = ".$idProtap;
        //echo $queryMD ."<br/>";

        $resultMD = mysql_query($queryMD) or die(mysql_error());
        
        $no = 1;
        while($d = mysql_fetch_array($resultMD))
        {
        ?>
                <td><?php echo $no++ ?></td>
                <td><?php echo $d['merchant'];?></td>
                <td><?php echo $d['alamat'];?></td>
                <td><?php echo $d['mid_mti'];?></td>
                <td><?php echo $d['tid_mti'];?></td>
                <td><?php echo $d['provider'];?></td>
                <td><?php echo $d['vendor'];?></td>
                <td><?php echo $d['type_edc'];?></td>
                <td><?php echo $d['aom'];?></td>
                <td><?php echo $d['last_trx'];?></td>
                <td><?php echo $d['history_case'];?></td>
                <td><?php echo $d['hasil_pm'];?></td>
                <td><?php echo $d['sv_settle'];?></td>
        <?php
        }
    ?>
</table>
