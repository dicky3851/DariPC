<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Protap : Data Monitoring</title>
<!-- Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<!-- CSS URL -->
<link rel="stylesheet" href="assets/css/main.css">
<!-- JS -->
<script type="application/x-javascript">
    addEventListener("load", function(){
        setTimeout(hiddenURLbar, 0);
    }, false);

    function hideURLbar(){
        window.scrollTo(0, 1);
    }
</script>
</head>
<body>
<div id="layouts">
    <!-- Content -->
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-12 xxl-3">
                <h3 class="text-center ff-3">Protap Data Monitoring</h3>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-12 col-md-5 col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="text-center fs-5 ff-4 fw-normal mb-3">Search Protap Name Or MID/TID</h4>
                        <form name="form_1" action="data/index.php" method="post">
                            <div class="input-group mb-3">
                                <span class="input-group-text bg-primary text-white" id="inputGroup-sizing-default"><i class="bi bi-search"></i> </span>
                                <input placeholder="Protap Data Search" name="field" class="form-control" type="text" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Cari</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Content -->
</div>
<!-- Footer -->
<div class="container xxl-2">
    <div class="row justify-content-center">
        <div class="col-12 col-md-12 col-sm-12">
            <p class="text-center">&copy; Designed And Developed By Giri Diwa Adam</p>
        </div>
    </div>
</div>
<!-- JS -->
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>